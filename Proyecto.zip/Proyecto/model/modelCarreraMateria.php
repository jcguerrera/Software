<?php

class CarreraMateria {

	private $Materia_idMateria;
	private $Carrera_idCarrera;

	public function __GET($att)
	{
		return $this->$att;
	}

	public function __SET($att, $v)
	{
		$this->$att=$v;
	}
}

?>