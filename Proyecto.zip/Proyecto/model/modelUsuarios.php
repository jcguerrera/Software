<?php 

class Usuario
{
	private $Usuario;
	private $Clave;
	private $Tipo_Usuario;
	private $Nombre;
	private $Apellido;
	private $Correo;


	public function __GET($att)
	{
		return $this->$att;
	}

	public function __SET($att, $v)
	{
		$this->$att=$v;
	}
}
?>