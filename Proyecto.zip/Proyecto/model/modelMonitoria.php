<?php

class Monitoria {

	private $Fecha_Inicio;
	private $Fecha_Final;
	private $Materia_idMateria;
	private $Estado;
	private $Monitor_Usuario_Usuario;
	private $Docente_Usuario_Usuario;
	private $Estudiante_Usuario_Usuario;
	
	public function __GET($att)
	{
		return $this->$att;
	}

	public function __SET($att, $v)
	{
		$this->$att=$v;
	}
}

?>