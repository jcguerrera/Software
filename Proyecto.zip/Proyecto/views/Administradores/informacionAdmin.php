
<?php
require_once '../../model/modelUsuarios.php';
require_once '../../controller/UsuarioController.php';
include_once 'menu.php';
$controlUsuarios = new ControllerUsuario();
$usuario = new Usuario();
$idAdmin = $_GET['admin'];
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Editar Informacion</title>
	<link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
</head>
<body>
   <div class="agregarCarrera" style=" width: 70%; padding: 5%; height: 100%; float: right; margin-top: -25%; margin-right: 5%">
    <div class="modal-header headerModal">
			<h5 class="modal-title" id="titleLabel">Editar Administrador</h5>
		</div>

	<form action="#" method="POST">
		<div class="row tam">
		<?php
		foreach($controlUsuarios->Buscar($idAdmin) as $resultado):
			?>

			<div class="form-group col-md-6">
			  <label for="inputEmail4">Usuario</label>
			  <br>
			  <input type="text" class="form-control" placeholder="Usuario" required name="usuario" disabled value="<?php echo $resultado->__GET('Usuario');?>">
			</div>

            <div class="form-group col-md-6">
			  <label for="inputEmail4">Clave</label>
			  <br>
		 	  <input type="text"  class="form-control" placeholder="Clave" required name="clave" value="<?php echo $resultado->__GET('Clave');?>">
		 	</div>

          <div class="form-group col-md-6">
			  <label for="inputEmail4">Tipo Usuario</label>
			  <br>
			  <select name="tipoUsuario" class="form-control">
			  	<?php
			  	if($resultado->__GET('Tipo_Usuario') == 'DOCENTE'){
			  		?>
			  		<option value="DOCENTE" selected>DOCENTE</option>
			  		<option value="ESTUDIANTE">ESTUDIANTE</option>
			  		<option value="ADMINISTRADOR">ADMINISTRADOR</option>
			  		<option value="MONITOR">MONITOR</option>
			  		<?php
			  	}else if($resultado->__GET('Tipo_Usuario') == 'ESTUDIANTE'){
			  		?>
			  		<option value="DOCENTE">DOCENTE</option>
			  		<option value="ESTUDIANTE" selected>ESTUDIANTE</option>
			  		<option value="ADMINISTRADOR">ADMINISTRADOR</option>
			  		<option value="MONITOR">MONITOR</option>
			  		<?php
			  	}else if($resultado->__GET('Tipo_Usuario') == 'MONITOR'){
			  		?>
			  		<option value="DOCENTE">DOCENTE</option>
			  		<option value="ESTUDIANTE">ESTUDIANTE</option>
			  		<option value="MONITOR" selected>MONITOR</option>
			  		<option value="ADMINISTRADOR">ADMINISTRADOR</option>
			  		<?php
			  	}else if($resultado->__GET('Tipo_Usuario') == 'ADMINISTRADOR'){
			  		?>
			  		<option value="DOCENTE">DOCENTE</option>
			  		<option value="ESTUDIANTE">ESTUDIANTE</option>
			  		<option value="MONITOR">MONITOR</option>
			  		<option value="ADMINISTRADOR" selected>ADMINISTRADOR</option>
			  		<?php
			  	}
			  	?>
			  </select>
		 	</div>
		 	<div class="form-group col-md-6">
			  <label for="inputEmail4">Nombre</label>
			  <br>
		 	  <input type="text"  class="form-control" placeholder="Nombre" required name="nombre" value="<?php echo $resultado->__GET('Nombre');?>">
		 	</div>
		 	<div class="form-group col-md-6">
			  <label for="inputEmail4">Apellido</label>
			  <br>
		 	  <input type="text"  class="form-control" placeholder="Apellido" required name="apellido" value="<?php echo $resultado->__GET('Apellido');?>">
		 	</div>
		 	<div class="form-group col-md-6">
			  <label for="inputEmail4">Correo</label>
			  <br>
		 	  <input type="text"  class="form-control" placeholder="Correo" required name="correo" value="<?php echo $resultado->__GET('Correo');?>">
		 	</div>
			<?php
		endforeach;
		?>

        </div>
         <div class="modal-footer">	
				<button type="submit" class="btn btn-primary botonAgregarMateria" name="enviar">Guardar Cambios</button>
	    </div>
	</form>
	<?php 
    if (isset($_POST['enviar'])) {
    	$usuario->__SET('Usuario',$idAdmin);
        $usuario->__SET('Clave',$_POST['clave']);
        $usuario->__SET('Tipo_Usuario',$_POST['tipoUsuario']);
        //echo $_POST['departamento'];
        $usuario->__SET('Nombre',$_POST['nombre']);
        $usuario->__SET('Apellido',$_POST['apellido']);
        $usuario->__SET('Correo',$_POST['correo']);
        if(($controlUsuarios->actualizar($usuario)) != true){
            ?>
            <script language="JavaScript" type="text/javascript">
                alert("Error al modificar el Usuario");
            </script>
            <meta http-equiv="refresh" content="0; url=menu.php">
            <?php
        }else{
            ?>
            <script language="JavaScript" type="text/javascript">
                alert("El usuario fue modificada exitosamente");
            </script>
            <meta http-equiv="refresh" content="0; url=menu.php">
            <?php
        }
    } 
   ?>
   	<script src="../../js/jquery-3.4.1.min.js"></script>
	<script src="../../js/bootstrap.min.js"></script>
</div>
</body>
</html>


