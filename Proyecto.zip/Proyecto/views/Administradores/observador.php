<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = 2;                      // Enable verbose debug output
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = '261200.cg@gmail.com';                     // SMTP username
    $mail->Password   = 'qncKKG37*';                               // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` also accepted
    $mail->Port       = 587;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('261200.cg@gmail.com', 'Cesar');    // Add a recipient
    $mail->addAddress('261200.cg@gmail.com');   
    $mail->addAddress('cagarciap@eafit.edu.co');              // Name is optional

    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Saludo';
    $mail->Body    = 'Confirmacion Monitoria';

    $mail->send();
    echo 'El mensaje se envio correctamente';
} catch (Exception $e) {
    echo 'Error al enviar el mensaje:'.$mail->ErrorInfo;
}