<?php
	require_once '../../model/modelMateria.php';
	require_once '../../controller/MateriaController.php';

	$materia = new Materia();
	$control = new ControllerMateria();
	$materia->__SET('Nombre',$_POST['nombreCarrera']);
	$materia->__SET('Creditos',$_POST['creditos']);
	$materia->__SET('Departamento_idDepartamento',$_POST['departamento']);
	if($control->Insertar($materia) == true){
		?>
            <script language="JavaScript" type="text/javascript">
                alert("Tu registro fue exitoso");
            </script>
            <!--<meta http-equiv="refresh" content="0; url=menu.php">-->
            <?php
	}else{
		?>
            <script language="JavaScript" type="text/javascript">
                alert("Ocurrio un error en el registro");
            </script>
            <!--<meta http-equiv="refresh" content="0; url=menu.php">-->
            <?php
	}
?>