<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title>Agregar Departamento</title>
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../../css/manual.css">
</head>
<body>
<?php
	include_once 'menu.php';
	?>
	<form method="POST" action="registrarDepartamento.php">
		<input type="text" placeholder="Nombre Departamento" name="nombreDepartamento">
		<button type="submit">Agregar</button>
	</form>
	<script src="../../js/jquery-3.4.1.min.js"></script>
	<script src="../../js/bootstrap.min.js"></script>
</body>
</html>