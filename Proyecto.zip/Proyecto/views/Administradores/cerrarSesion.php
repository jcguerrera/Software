
<?php
session_start();
$usuario = $_SESSION['usuario'];
$tam = strlen($usuario);
if(($tam == 0) || ($tam == null)){
	header("Location:../inicio/paginaPrincipal.php");
	die();
}
session_destroy();
header("Location:../inicio/paginaPrincipal.php");
?>