<?php
session_start();
$usuario = $_SESSION['usuario'];
$tam = strlen($usuario);
if(($tam == 0) || ($tam == null)){
	header("Location:../inicio/paginaPrincipal.php");
	die();
}
$verificarMenu = False;
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title>Menu Administradores</title>
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
</head>
<body>
	<nav class="navbar navbar-expand-lg">
		<div class="container">
			<div>
				<a class="navbar-brand" href="index.php">
					<img src="../../imagenes/eafit.png" style="width: 120px; height: 50px">
				</a>
			</div>
		</div>
	</nav>
	<nav class="navbar navbar-expand-lg opciones" style="max-width:100%;height:auto;">
		<div class="container">
			<div class="collapse navbar-collapse" id="navbarResponsive">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<span class="glyphicon glyphicon-asterisk"></span>
						<a class="nav-link color_Blanco" href="http://www.eafit.edu.co/biblioteca/Paginas/inicio.aspx" target="_blank">Biblioteca</a>
					</li>
					<li class="nav-item">
						<a class="nav-link color_Blanco" href="https://app.eafit.edu.co/ulises/login.do" target="_blank">Ulises</a>
					</li>
					<li class="nav-item">
						<a class="nav-link color_Blanco" href="https://interactiva.eafit.edu.co/ei" target="_blank">Interactiva</a>
					</li>
					<li class="nav-item">
						<a class="nav-link color_Blanco" href="http://correo.eafit.edu.co/" target="_blank">Correo 365</a>
					</li>
					<li class="nav-item">
						<a class="nav-link color_Blanco" href="cerrarSesion.php">Salir</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>

	<div class="menu">
		<br>
		<div class="contenedorImagen">
			<div class="bloqueImagen" align="middle">
				<img class="imagen" src="../../imagenes/user.png">
			</div>
			<div class="usuario">
				<h1 class="text-white textUsuario">Bienvenido <?php echo $usuario?></h1>
			</div>
		</div>
		<ul class="nav flex-column">
			<li class="nav-item">
				<div id="carrera" class="opcionPrincipal">
					<a class="nav-link text-white" id="carreras">Carreras</a>
				</div>
				<div id="opcionesCarrera" class="opcionesCarreras">
					<ul class="nav flex-column">
						<li class="nav-item suboption">
							<a class="nav-link color_Blanco" href="agregarCarrera.php">Agregar Carrera</a>
						</li>
						<li class="nav-item suboption">
							<a class="nav-link color_Blanco" href="#">Eliminar Carrera</a>
						</li>
					</ul>
				</div>
			</li>
			<li class="nav-item">
				<div id="usuario" class="opcionPrincipal">
					<a class="nav-link text-white">Usuarios</a>
				</div>
				<div id="opcionesUsuario" class="opcionesUsuarios">
					<ul class="nav flex-column">
						<li class="nav-item suboption">
							<a class="nav-link color_Blanco" href="agregarDocente.php">Agregar Docente</a>
						</li>
						<li class="nav-item suboption">
							<a class="nav-link color_Blanco" href="agregarMonitor.php">Agregar Monitor</a>
						</li>
						<li class="nav-item suboption">
							<a class="nav-link color_Blanco" href="agregarEstudiante.php">Agregar Estudiante</a>
						</li>
						<li class="nav-item suboption">
							<a class="nav-link color_Blanco" href="buscarUsuario.php">Buscar Usuario</a>
						</li>
					</ul>
				</div>
			</li>
			<li class="nav-item">
				<div id="materia" class="opcionPrincipal">
					<a class="nav-link text-white">Materias</a>
				</div>
				<div id="opcionesMateria" class="opcionesMaterias">
					<ul class="nav flex-column">
						<li class="nav-item suboption">
							<a class="nav-link color_Blanco" href="agregarMateria.php">Agregar Materia</a>
						</li>
						<li class="nav-item suboption">
							<a class="nav-link color_Blanco" href="listarMateria.php">Actualizar Materia</a>
						</li>
					</ul>
				</div>
			</li>
			<li class="nav-item">
				<div id="configuracion" class="opcionPrincipal">
					<a class="nav-link text-white">Configuracion Cuenta</a>
				</div>
				<div id="opcionesConfiguracion" class="opcionesConfiguraciones">
					<ul class="nav flex-column">
						<li class="nav-item suboption">
							<a class="nav-link color_Blanco" href="cerrarSesion.php">Cerrar Sesion</a>
						</li>
						<li class="nav-item suboption">
							<a class="nav-link color_Blanco" href="informacionAdmin.php?admin=<?php echo $usuario;?>">Actualizar Datos</a>
						</li>
					</ul>
				</div>
			</li>
		</ul>
	</div>

	<script>
		document.getElementById("carrera").onclick = function() {ShowOpcionesCarrera()};
		document.getElementById("usuario").onclick = function() {ShowOpcionesUsuario()};
		document.getElementById("materia").onclick = function() {ShowOpcionesMateria()};
		document.getElementById("configuracion").onclick = function() {ShowOpcionesConfiguraciones()};

		function ShowOpcionesCarrera() {
			document.getElementById("opcionesCarrera").style.display = "block";
			document.getElementById("opcionesUsuario").style.display = "none";
			document.getElementById("opcionesMateria").style.display = "none";
			document.getElementById("opcionesConfiguracion").style.display = "none";
		}
		function ShowOpcionesUsuario() {
			document.getElementById("opcionesCarrera").style.display = "none";
			document.getElementById("opcionesMateria").style.display = "none";
			document.getElementById("opcionesConfiguracion").style.display = "none";
			document.getElementById("opcionesUsuario").style.display = "block";
		}
		function ShowOpcionesMateria() {
			document.getElementById("opcionesCarrera").style.display = "none";
			document.getElementById("opcionesUsuario").style.display = "none";
			document.getElementById("opcionesConfiguracion").style.display = "none";
			document.getElementById("opcionesMateria").style.display = "block";
		}
		function ShowOpcionesConfiguraciones() {
			document.getElementById("opcionesCarrera").style.display = "none";
			document.getElementById("opcionesUsuario").style.display = "none";
			document.getElementById("opcionesMateria").style.display = "none";
			document.getElementById("opcionesConfiguracion").style.display = "block";
		}

	</script>
	<script src="../../js/jquery-3.4.1.min.js"></script>
	<script src="../../js/bootstrap.min.js"></script>
</body>
</html>