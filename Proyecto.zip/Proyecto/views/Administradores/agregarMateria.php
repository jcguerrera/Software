<?php
require_once '../../model/modelDepartamento.php';
require_once '../../controller/DepartamentoController.php';

$control = new ControllerDepartamento();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Agregar Materia</title>
	<link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
</head>
<body>
<?php
	include_once 'menu.php';
	?>
	<div class="agregarCarrera" style=" width: 70%; padding: 5%; height: 100%; float: right; margin-top: -25%">
		<div class="modal-header headerModal">
			<h5 class="modal-title" id="titleLabel">Registro de Materia</h5>
		</div>
		<br><br>
	<form method="POST" action="registrarMateria.php">
		<div class="row">
		<div class="form-group col-md-6">
			<label for="inputEmail4">Nombre</label>
			<input type="text" class="form-control" placeholder="Nombre" required name="nombreCarrera">
		</div>
		<div class="form-group col-md-6">
			<label for="inputEmail4">Creditos</label>
			<input type="number" class="form-control" placeholder="Creditos" required name="creditos">
		</div>
		<div class="form-group col-md-12">
			<label for="inputEmail4" id="textoDepartamento">Selecciona el Departamento</label>
			<select id="departamento" class="form-control" required name="departamento">
				<option selected disabled>Selecciona una opcion</option>
				<?php
				foreach ($control->Listar() as $departamento):
					?>
				<option value="<?php echo $departamento->__GET('idDepartamento') ?>"><?php echo $departamento->__GET('Nombre')?></option>
				<?php
				endforeach;
				?>
			</select>
		</div>
		
	</div><div class="modal-footer">	
				<button type="submit" class="btn btn-primary botonIngresar">Agregar</button>
			</div>
	</form>
</div>
	<script src="../../js/jquery-3.4.1.min.js"></script>
	<script src="../../js/bootstrap.min.js"></script>
</body>
</html>