<?php
require_once "menu.php";
require_once '../../model/modelMateria.php';
require_once '../../controller/MateriaController.php';
require_once '../../model/modelDepartamento.php';
require_once '../../controller/DepartamentoController.php';

$controlMaterias = new ControllerMateria();
$controlDepartamento = new ControllerDepartamento();
$materia = new Materia();
$idMateria = $_GET['id'];

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Editar Informacion</title>
	<link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
</head>
<body>
	<div class="agregarCarrera" style=" width: 80%; padding: 5%; height: 100%; float: right; margin-top: -30%; margin-right: 5%">
		<div class="ingresoMateria">
			<div class="modal-header headerModal">
				<h5 class="modal-title" id="titleLabel">Esta funcion aún se está desarrollando</h5>
			</div>
			
		</div>
	</div>
	<script src="../../js/jquery-3.4.1.min.js"></script>
	<script src="../../js/bootstrap.min.js"></script>
</body>
</html>