<?php
session_start();
$usuario = $_SESSION['usuario'];
$tam = strlen($usuario);
if(($tam == 0) || ($tam == null)){
	header("Location:../inicio/paginaPrincipal.php");
	die();
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Pagina Principal</title>
	<link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
	
</head>
<body style="background: black">
	<div class="calendar">
		<div class="calendarioInformacion">
			<div class="calendarioPrevio" id="mesPrevio" style="padding: 5%">&#9664</div>
			<div class="calendarioMes" id="mes" style="padding: 5%"></div>
			<div class="calendarioAño" id="año" style="padding: 5%"></div>
			<div class="calendarioSiguiente" id="mesSiguiente" style="padding: 5%">&#9654</div>
		</div>

		<div class="semana">
			<div class="dia item">Lunes</div>
			<div class="dia item">Martes</div>
			<div class="dia item">Miercoles</div>
			<div class="dia item">Jueves</div>
			<div class="dia item">Viernes</div>
			<div class="dia item">Sabado</div>
			<div class="dia item">Domingo</div>
		</div>
		<div id="fechas" style="display: grid;
	grid-template-columns: repeat(7, 1fr);">
			
		</div>
	</div>


	<!--<div id="carrera" class="opcionPrincipal">
		<a class="nav-link text-white" id="carreras">Carreras</a>
	</div>
	<div id="opcionesCarrera" class="opcionesCarreras">
		<ul class="nav flex-column">
			<li class="nav-item suboption">
				<a class="nav-link color_Blanco" href="agregarCarrera.php" id="textoCambiante">Agregar Carrera</a>
			</li>
			<li class="nav-item suboption">
				<a class="nav-link color_Blanco" href="#">Eliminar Carrera</a>
			</li>
		</ul>
	</div>
	<div id="usuario" class="opcionPrincipal">
		<a class="nav-link text-white">Usuarios</a>
	</div>
	<div id="opcionesUsuario" class="opcionesUsuarios">
		<ul class="nav flex-column">
			<li class="nav-item suboption">
				<a class="nav-link color_Blanco" href="agregarDocente.php">Agregar Docente</a>
			</li>
			<li class="nav-item suboption">
				<a class="nav-link color_Blanco" href="agregarMonitor.php">Agregar Monitor</a>
			</li>
			<li class="nav-item suboption">
				<a class="nav-link color_Blanco" href="agregarEstudiante.php">Agregar Estudiante</a>
			</li>
			<li class="nav-item suboption">
				<a class="nav-link color_Blanco" href="buscarUsuario.php">Buscar Usuario</a>
			</li>
		</ul>
	</div>-->

	<script src="../../js/jquery-3.4.1.min.js"></script>
	<script src="../../js/bootstrap.min.js"></script>
	<script>
		var nombreMeses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

		var fechaOrdenador = new Date();
		var diaOrdenador = fechaOrdenador.getDate();
		var mesOrdenador = fechaOrdenador.getMonth();
		var añoOrdenador = fechaOrdenador.getFullYear();


		var mesText = nombreMeses[mesOrdenador];
		var añoText = añoOrdenador.toString();
		document.getElementById("mes").innerHTML = mesText;
		document.getElementById("año").innerHTML = añoText;
		//console.log(diaOrdenador + ' cap ' + mesOrdenador + ' ---- ' + añoOrdenador);

		var obtenerFechas = document.getElementById('fechas');
		var obtenerAño = document.getElementById('año');
		var obtenerMes = document.getElementById('mes');

		//console.log(obtenerMes + " mes");

		var obtenerPrevio = document.getElementById('mesPrevio');
		var obtenerSiguiente = document.getElementById('mesSiguiente');


		var mesText = nombreMeses[obtenerMes];
		var añoText = obtenerAño.toString();

		document.getElementById("mes").innerHTML = mesText;
		document.getElementById("año").innerHTML = añoText;

		document.getElementById("mesPrevio").onclick = function() {mesAnterior()};
		document.getElementById("mesSiguiente").onclick = function() {mesSiguiente()};

		//escribirMes(obtenerMes);

		function escribirMes(mes){
			for(let i = primerDiaSemana(); i>0; i--){
				fechas.innerHTML += ` <div class="dia item" style="background: green">${totalDias(mesOrdenador-1)-(i-1)}</div> `;
			}


			for(let i = 1; i <= totalDias(mes); i++){
				fechas.innerHTML += ` <div class="dia item">${i}</div> `;
			}



		}

		function totalDias(mes){
			if(mes === -1){
				mes = 11;
			}

			if((mes === 0) || (mes == 2) || (mes === 4) || (mes === 6) || (mes === 7) || (mes === 9) || (mes == 11)){
				return 31;
			}else if((mes === 3) || (mes === 5) || (mes === 8) || (mes === 10)){
				return 30;
			}else{
				if(Bisiesto()){
					return 29;
				}else{
					return 28;
				}
			}
		}

		function Bisiesto(){
			return ((añoOrdenador%100 !== 0) && (añoOrdenador%4 === 0) || (añoOrdenador%400 === 0));
		}

		function primerDiaSemana(){
			var inicio = new Date(añoOrdenador, mesOrdenador, 1);
			if((inicio.getDay()-1) === -1){
				return 6;
			}else{
				return inicio.getDay()-1;
			}
		}

		function mesAnterior(){
			if(mesOrdenador !== 0){
				mesOrdenador--;
			}else{
				mesOrdenador=11;
				añoOrdenador--;
			}

			setNewDate();
		}

		function mesSiguiente(){
			if(mesOrdenador !== 11){
				mesOrdenador++;
			}else{
				mesOrdenador = 0;
				añoOrdenador++;
			}

			setNewDate();
		}

		function setNewDate(){
			fechaOrdenador.setFullYear(añoOrdenador,mesOrdenador, diaOrdenador);
			mesText = nombreMeses[mesOrdenador];
			añoText = añoOrdenador.toString();
			document.getElementById("mes").innerHTML = mesText;
			document.getElementById("año").innerHTML = añoText;
			fechas.textContent = '';
			escribirMes(mesOrdenador);

		}

	</script>
</body>
</html>