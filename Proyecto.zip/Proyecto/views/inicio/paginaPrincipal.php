<?php
require_once '../../model/modelCarrera.php';
require_once '../../controller/CarreraController.php';

$control = new ControllerCarrera();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Pagina Principal</title>
	<link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
</head>
<body>
	<nav class="navbar navbar-expand-lg">
		<div class="container">
			<div>
				<a class="navbar-brand" href="index.php">
					<img src="../../imagenes/eafit.png" style="width: 120px; height: 50px">
				</a>
			</div>
		</div>
	</nav>
	<nav class="navbar navbar-expand-lg opciones" style="max-width:100%;height:auto;">
		<div class="container">
			<a class="navbar-brand titulo_Blanco" href="paginaPrincipal.php">EAFIT Sistema de Monitorias</a>
			<div class="collapse navbar-collapse" id="navbarResponsive">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<span class="glyphicon glyphicon-asterisk"></span>
						<a class="nav-link color_Blanco" href="http://www.eafit.edu.co/biblioteca/Paginas/inicio.aspx" target="_blank">Biblioteca</a>
					</li>
					<li class="nav-item">
						<a class="nav-link color_Blanco" href="https://app.eafit.edu.co/ulises/login.do" target="_blank">Ulises</a>
					</li>
					<li class="nav-item">
						<a class="nav-link color_Blanco" href="https://interactiva.eafit.edu.co/ei" target="_blank">Interactiva</a>
					</li>
					<li class="nav-item">
						<a class="nav-link color_Blanco" href="http://correo.eafit.edu.co/" target="_blank">Correo 365</a>
					</li>
					<li class="nav-item">
						<a class="nav-link color_Blanco" href="#inicioSesion" data-toggle="modal">Ingreso al Sistema</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>

	<!-- Modal -->
	<div class="modal fade" id="inicioSesion" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header headerModal">
					<h5 class="modal-title" id="titleLabel">Ingreso al sistema</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<form method="POST" action="inicioSesion.php" class="brand">
					<div class="modal-body">
						<label for="inputEmail4">Usuario</label>
						<input type="text" class="form-control" placeholder="Usuario" required name="usuario">
						<br>
						<label for="inputEmail4">Contraseña</label>
						<input type="password" class="form-control" placeholder="Contraseña" required name="contraseña">
					</div>
					<div class="modal-footer">
						<!--<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>-->
						<button type="submit" class="btn btn-primary botonIngresar">Ingresar</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<div class="registro" >
		<div class="modal-header headerModal">
			<h5 class="modal-title" id="titleLabel">Registro en el sistema</h5>
		</div>
		<br>
		<form method="POST" action="validarRegistroUsuario.php">
			<div class="modal-body">
				<div class="row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">Nombre</label>
						<input type="text" class="form-control" placeholder="Nombre" required name="nombre">
					</div>
					<div class="form-group col-md-6">
						<label for="inputEmail4">Apellido</label>
						<input type="text" class="form-control" placeholder="Apellido" required name="apellido">
					</div>
					<div class="form-group col-md-12">
						<label for="inputEmail4">Correo</label>
						<input type="email" class="form-control" placeholder="Correo" required name="correo">
					</div>
					<div class="form-group col-md-6">
						<label for="inputEmail4">Usuario</label>
						<input type="text" class="form-control" placeholder="Usuario" required name="usuario">
					</div>
					<div class="form-group col-md-6">
						<label for="inputEmail4">Contraseña</label>
						<input type="password" class="form-control" placeholder="Contraseña" required name="contraseña">
					</div>
					<div class="form-group col-md-12">
						<label for="inputEmail4">Selecciona tu carrera</label>
						<select id="carrera" class="form-control" required name="carrera">
							<option selected disabled>Selecciona una opcion</option>
							<?php
							foreach ($control->Listar() as $carrera):
								?>
							<option value="<?php echo $carrera->__GET('idCarrera') ?>"><?php echo $carrera->__GET('Nombre')?></option>
							<?php
							endforeach;
							?>
						</select>
					</div>
					
				</div>
			</div>
			<div class="modal-footer">	
				<button type="submit" class="btn btn-primary botonIngresar">Sign in</button>
			</div>
		</form>

	</div>
	<div class="consulta">
		<div class="modal-header headerModal">
			<h5 class="modal-title" id="titleLabel">Solicitar Monitoria</h5>
			<!--<a class="btn btn-primary" href="paginaPrincipal.php" role="button">Dar click</a>-->
			<a class="btn btn-primary" href="#inicioSesion" data-toggle="modal">Inicia sesión para solicitar una monitoria</a>
		</div>
		<br><br>
		<!--<div class="modal-header headerModal">
			<h5 class="modal-title" id="titleLabel">Buscar Horarios de Atencion de DOcentes y Monitores</h5>
		</div>
		<br><br>
		<form action="buscarDocente.php">
			<div class="row">
					<div class="form-group col-md-12">
						<label for="inputEmail4">Selecciona tu carrera</label>
						<select id="carrera" class="form-control" required name="carrera">
							<option selected disabled>Selecciona una opcion</option>
							<?php
							//foreach ($control->Listar() as $carrera):
								?>
							<option value="<?php //echo $carrera->__GET('idCarrera') ?>"><?php //echo $carrera->__GET('Nombre')?></option>
							<?php
							//endforeach;
							?>
						</select>
					</div>
					<div class="modal-footer col-md-12">	
				<button type="submit" class="btn btn-primary botonIngresar">Sign in</button>
			</div>
		</form>-->
	</div>


	<script src="../../js/jquery-3.4.1.min.js"></script>
	<script src="../../js/bootstrap.min.js"></script>
	<script>
		$('#inicioSesion').modal('show');
	</script>
</body>
</html>