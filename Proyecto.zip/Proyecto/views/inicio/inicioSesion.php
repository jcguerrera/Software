<?php
require_once '../../model/modelUsuarios.php';
require_once '../../controller/UsuarioController.php';

$usuario = $_POST['usuario'];
$contraseña = $_POST['contraseña'];
$control = new ControllerUsuario();
error_reporting(0);
if(count($control->Buscar($usuario)) != 1){
	?>
	<script language="JavaScript" type="text/javascript">
		alert("El usuario no está registrado en el sistema");
	</script>
	<meta http-equiv="refresh" content="0; url=paginaPrincipal.php">
	<?php
}else{
	foreach($control->Buscar($usuario) as $resultado):
		$usuarioSesion = $resultado->__GET('Usuario');
	$contraseñaSesion = $resultado->__GET('Clave');
	$nombre = $resultado->__GET('Nombre');
	$apellido = $resultado->__GET('Apellido');
	$tipoUsuario = $resultado->__GET('Tipo_Usuario');
	endforeach;
	if(($usuarioSesion == $usuario) && ($contraseñaSesion == $contraseña)){
		echo "tipoES: ".$Tipo_Usuario;
		if($tipoUsuario == "ADMINISTRADOR"){
			session_start();
			$_SESSION['usuario'] = $usuario;
			header("Location:../Administradores/menu.php");
		}else if($tipoUsuario == 'ESTUDIANTE'){
			session_start();
			$_SESSION['usuario'] = $usuario;
			header("Location:../Usuarios/menu.php");
		}else if($tipoUsuario == 'DOCENTE'){
			session_start();
			$_SESSION['usuario'] = $usuario;
			header("Location:../Docentes/menu.php");
		}
	}else{
		?>
		<script language="JavaScript" type="text/javascript">
		alert("Usuario y/o contraseña Erroneos");
		</script>
		<meta http-equiv="refresh" content="0; url=paginaPrincipal.php">
		<?php
	}
}

?>