<?php

session_start();
$usuario = $_SESSION['usuario'];
$tam = strlen($usuario);
if(($tam == 0) || ($tam == null)){
	header("Location:../inicio/paginaPrincipal.php");
	die();
}

require_once '../../model/modelMonitoria.php';
require_once '../../controller/MonitoriaController.php';
require_once '../../model/modelUsuarios.php';
require_once '../../controller/UsuarioController.php';

$controlMonitoria = new ControllerMonitoria();
$controlUsuarios = new ControllerUsuario();
$nombreEstudiante = $_GET['nombreEstudiante'];
$nombreMateria = $_GET['nombreMateria'];
$idMateria = $_GET['idMateria'];
$idEstudiante = $_GET['idEstudiante'];
$fechaInicio = $_GET['fechaInicio'];
$fechaFinal = $_GET['fechaFinal'];
$nombreDocente = null;
$correoEstudiante = null;
$correoDocente = null;
foreach($controlUsuarios->Buscar($usuario) as $user):
	$nombreDocente = $user->__GET('Nombre');
	$correoDocente = $user->__GET('Correo');
endforeach;
foreach($controlUsuarios->Buscar($idEstudiante) as $user):
	$correoEstudiante = $user->__GET('Correo');
endforeach;

//$correoDocente = "261200.cg@gmail.com";
$correoEstudiante = "261200.cg@gmail.com";

$monitoria = new Monitoria();

$monitoria->__SET('Fecha_Inicio',$fechaInicio);
$monitoria->__SET('Fecha_Final',$fechaFinal);
$monitoria->__SET('Materia_idMateria',$idMateria);
$monitoria->__SET('Estado',"PENDIENTE");
$monitoria->__SET('Monitor_Usuario_Usuario',null);
$monitoria->__SET('Docente_Usuario_Usuario',$usuario);
$monitoria->__SET('Estudiante_Usuario_Usuario',$idEstudiante);


if($controlMonitoria->Eliminar($monitoria) == true){
	?>
	<script language="JavaScript" type="text/javascript">
		alert("Rechasate la Monitoria");
	</script>
	<meta http-equiv="refresh" content="0; url=enviarRechazo.php?nombreMateria=<?php echo $nombreMateria?>&nombreDocente=<?php echo $nombreDocente?>&nombreEstudiante=<?php echo $nombreEstudiante?>&correoEstudiante=<?php echo $correoEstudiante?>&correoDocente=<?php echo $correoDocente?>&fecha=<?php echo $fechaInicio?>">
	<?php
}else{
	echo "error";
}
//echo "nom es: ".$nombreEstudiante." id es: ".$idEstudiante." mat: ".$nombreMateria." id mate: ".$idMateria." fecha ini: ".$fechaInicio." fecha fina: ".$fechaFinal;
?>