<?php
error_reporting(0);
session_start();
$usuario = $_SESSION['usuario'];
$tam = strlen($usuario);
if(($tam == 0) || ($tam == null)){
	header("Location:../inicio/paginaPrincipal.php");
	die();
}
require_once '../../model/modelMonitoria.php';
require_once '../../controller/MonitoriaController.php';
require_once '../../model/modelUsuarios.php';
require_once '../../controller/UsuarioController.php';
require_once "menu.php";

$idMateria = $_GET['materia'];
//echo "idMateria: ".$idMateria;
$idDocente = $_POST['docenteMonitoria'];
$controlUsuarios = new ControllerUsuario();
$nombreDocente = null;
$apellidoDocente = null;
$correoDocente = null;
foreach($controlUsuarios->Buscar($idDocente) as $docente):
	$nombreDocente = $docente->__GET('Nombre');
	$apellidoDocente = $docente->__GET('Apellido');
	$correoDocente = $docente->__GET('Correo');
endforeach;
//echo " correo: ".$correoDocente;
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Pagina Principal</title>
	<link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
	
</head>
<body>
	<div class="agregarCarrera" style=" width: 70%; padding: 5%; height: 100%; float: right; margin-top: -25%; margin-right: 5%">
		<div class="modal-header headerModal">
			<h5 class="modal-title" id="titleLabel" style="text-transform: uppercase;">Solicitud de Monitoria a <?php echo $nombreDocente." ".$apellidoDocente; ?></h5>
		</div>
		<div class="calendar" style="background: none">
			<div class="calendarioInformacion">
				<div class="calendarioPrevio" id="mesPrevio" style="padding: 5%; color: #45C7D5">&#9664</div>
				<div class="calendarioMes" id="mes" style="padding: 5%"></div>
				<div class="calendarioAño" id="año" style="padding: 5%"></div>
				<div class="calendarioSiguiente" id="mesSiguiente" style="padding: 5%; color: #45C7D5">&#9654</div>
			</div>

			<div class="semana">
				<div class="dia item" style="background: #45C7D5; border-radius: 7%; margin: 2%">Lunes</div>
				<div class="dia item" style="background: #45C7D5; border-radius: 7%; margin: 2%">Martes</div>
				<div class="dia item" style="background: #45C7D5; border-radius: 7%; margin: 2%">Miercoles</div>
				<div class="dia item" style="background: #45C7D5; border-radius: 7%; margin: 2%">Jueves</div>
				<div class="dia item" style="background: #45C7D5; border-radius: 7%; margin: 2%">Viernes</div>
				<div class="dia item" style="background: #45C7D5; border-radius: 7%; margin: 2%">Sabado</div>
				<div class="dia item" style="background: #45C7D5; border-radius: 7%; margin: 2%">Domingo</div>
			</div>
			<div id="fechas" style="display: grid;
			grid-template-columns: repeat(7, 1fr);">
			
		</div>
	</div>
</div>


	<!--<div id="carrera" class="opcionPrincipal">
		<a class="nav-link text-white" id="carreras">Carreras</a>
	</div>
	<div id="opcionesCarrera" class="opcionesCarreras">
		<ul class="nav flex-column">
			<li class="nav-item suboption">
				<a class="nav-link color_Blanco" href="agregarCarrera.php" id="textoCambiante">Agregar Carrera</a>
			</li>
			<li class="nav-item suboption">
				<a class="nav-link color_Blanco" href="#">Eliminar Carrera</a>
			</li>
		</ul>
	</div>
	<div id="usuario" class="opcionPrincipal">
		<a class="nav-link text-white">Usuarios</a>
	</div>
	<div id="opcionesUsuario" class="opcionesUsuarios">
		<ul class="nav flex-column">
			<li class="nav-item suboption">
				<a class="nav-link color_Blanco" href="agregarDocente.php">Agregar Docente</a>
			</li>
			<li class="nav-item suboption">
				<a class="nav-link color_Blanco" href="agregarMonitor.php">Agregar Monitor</a>
			</li>
			<li class="nav-item suboption">
				<a class="nav-link color_Blanco" href="agregarEstudiante.php">Agregar Estudiante</a>
			</li>
			<li class="nav-item suboption">
				<a class="nav-link color_Blanco" href="buscarUsuario.php">Buscar Usuario</a>
			</li>
		</ul>
	</div>-->

	<script src="../../js/jquery-3.4.1.min.js"></script>
	<script src="../../js/bootstrap.min.js"></script>
	<script>
		var nombreMeses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

		var fechaOrdenador = new Date();
		var diaOrdenador = fechaOrdenador.getDate();
		var mesOrdenador = fechaOrdenador.getMonth();
		var añoOrdenador = fechaOrdenador.getFullYear();


		var mesText = nombreMeses[mesOrdenador];
		var añoText = añoOrdenador.toString();
		document.getElementById("mes").innerHTML = mesText;
		document.getElementById("año").innerHTML = añoText;
		//console.log(diaOrdenador + ' cap ' + mesOrdenador + ' ---- ' + añoOrdenador);

		var obtenerFechas = document.getElementById('fechas');
		var obtenerAño = document.getElementById('año');
		var obtenerMes = document.getElementById('mes');

		//console.log(obtenerMes + " mes");

		var obtenerPrevio = document.getElementById('mesPrevio');
		var obtenerSiguiente = document.getElementById('mesSiguiente');


		var mesText = nombreMeses[obtenerMes];
		var añoText = obtenerAño.toString();

		document.getElementById("mes").innerHTML = mesText;
		document.getElementById("año").innerHTML = añoText;

		document.getElementById("mesPrevio").onclick = function() {mesAnterior()};
		document.getElementById("mesSiguiente").onclick = function() {mesSiguiente()};

		//escribirMes(obtenerMes);

		function escribirMes(mes){
			for(let i = primerDiaSemana(); i>0; i--){
				fechas.innerHTML += ` <div class="dia item"><a href="#" class="btn btn-secondary btn-lg disabled" tabindex="-1" role="button" aria-disabled="true" style="width: 50px; height: 50px; border-radius: 80%; margin: 2%" >${totalDias(mesOrdenador-1)-(i-1)}</a></div>`;
			}


			for(let i = 1; i <= totalDias(mes); i++){
				//fechas.innerHTML += ` <div class="dia item">${i}</div> `;

				fechas.innerHTML += ` <div class="dia item"><a href="agendarMonitoria.php?nombreDocente=<?php echo $nombreDocente?>&apellidoDocente=<?php echo $apellidoDocente?>&idDocente=<?php echo $idDocente?>&correoDocente=<?php echo $correoDocente?>&dia=${i}&mes=${mes+1}&año=${añoOrdenador}&materia=<?php echo $idMateria?>" class="btn btn-primary btn-lg active" role="button" aria-pressed="true" style="width: 50px; height: 50px; border-radius: 80%; margin: 2%;">${i}</a></div>`;
			}



		}

		function totalDias(mes){
			if(mes === -1){
				mes = 11;
			}

			if((mes === 0) || (mes == 2) || (mes === 4) || (mes === 6) || (mes === 7) || (mes === 9) || (mes == 11)){
				return 31;
			}else if((mes === 3) || (mes === 5) || (mes === 8) || (mes === 10)){
				return 30;
			}else{
				if(Bisiesto()){
					return 29;
				}else{
					return 28;
				}
			}
		}

		function Bisiesto(){
			return ((añoOrdenador%100 !== 0) && (añoOrdenador%4 === 0) || (añoOrdenador%400 === 0));
		}

		function primerDiaSemana(){
			var inicio = new Date(añoOrdenador, mesOrdenador, 1);
			if((inicio.getDay()-1) === -1){
				return 6;
			}else{
				return inicio.getDay()-1;
			}
		}

		function mesAnterior(){
			if(mesOrdenador !== 0){
				mesOrdenador--;
			}else{
				mesOrdenador=11;
				añoOrdenador--;
			}

			setNewDate();
		}

		function mesSiguiente(){
			if(mesOrdenador !== 11){
				mesOrdenador++;
			}else{
				mesOrdenador = 0;
				añoOrdenador++;
			}

			setNewDate();
		}

		function setNewDate(){
			fechaOrdenador.setFullYear(añoOrdenador,mesOrdenador, diaOrdenador);
			mesText = nombreMeses[mesOrdenador];
			añoText = añoOrdenador.toString();
			document.getElementById("mes").innerHTML = mesText;
			document.getElementById("año").innerHTML = añoText;
			fechas.textContent = '';
			escribirMes(mesOrdenador);

		}

	</script>
</body>
</html>