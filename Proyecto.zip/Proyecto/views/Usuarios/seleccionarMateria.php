<?php
$idUsuario = $_GET['user'];
require_once '../../model/modelEstudiante.php';
require_once '../../controller/EstudianteController.php';
require_once '../../model/modelMateria.php';
require_once '../../controller/MateriaController.php';
require_once '../../controller/CarreraMateriaController.php';
require_once '../../controller/DocenteController.php';
require_once '../../controller/UsuarioController.php';
require_once "menu.php";
error_reporting(0);
$controlEstudiante = new ControllerEstudiante();
$controlMateria = new ControllerMateria(); 
$controlCarreraMateria = new ControllerCarreraMateria();
$controlDocente = new ControllerDocente();
$controlUsuario = new ControllerUsuario();

$idCarrera = null;
$materias = array();
$departamento = null;

foreach($controlEstudiante->Buscar($idUsuario) as $estudiante):
	$idCarrera = $estudiante->__GET('Carrera_idCarrera');
endforeach;

$idCarrera = 12;
//echo "carrera: ".strval($idCarrera);

if($controlCarreraMateria->Contador($idCarrera) == null){
	echo "Error";
}else{
	$paginas = ceil((count($controlCarreraMateria->Contador($idCarrera)))/3);
	$inicio = 0;
	?>
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Solicitar Monitoria</title>
		<link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
		<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
	</head>
	<body>

		<div id="cuadro" class="agregarCarrera" style=" width: 70%; padding: 5%; height: 100%; float: right; margin-top: -25%; margin-right: 5%; display: block;">

			<div class="modal-header headerModal">
				<h5 class="modal-title" id="titleLabel">Seleccione la carrera en la que desea recibir una monitoria</h5>
			</div>
			<form method="POST">
				<div class="modal-body">
					<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
						<ol class="carousel-indicators">
							<?php
							for($i = 0; $i < $paginas; $i++){
								if($i == 0){
									?>
									<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
									<?php
								}else{
									?>
									<li data-target="#carouselExampleIndicators" data-slide-to="<?php echo "$i"; ?>"></li>
									<?php
								}
							}
							?>

						</ol>
						<div class="carousel-inner">
							<?php
							for($i = 0; $i < $paginas; $i++){
								if($i == 0){
									?>
									<div class="carousel-item active" style="background: #7FADEF">
										<div style="margin: 5%; padding: 5%">
											<table class="table table-striped" style="text-align: center;">
												<thead>
													<tr style="background: #86E6F0; color: white;">
														<th>Nombre Materia</th>
														<th>Buscar Docente</th>

													</tr>
												</thead>
											</table>
											<?php
											foreach($controlCarreraMateria->BuscarMaterias($idCarrera,$inicio) as $carreraMateria):
												?>
											<table class="table table-striped" style="text-align: center;">
												<thead>
													<tr>
														<th style="color: #7FADEF">Nombre Materia</th>
														<th style="color: #7FADEF">Buscar Docente</th>

													</tr>
												</thead>
												<?php
												foreach($controlMateria->Buscar($carreraMateria->__GET('Materia_idMateria')) as $materia):
													?>

												<tbody style="background: white">
													<tr>
														<th scope="col"><?php echo $materia->__GET('Nombre'); ?></th>
														<th scope="col">
															<div class="form-check">
																<?php
																array_push($materias,$materia->__GET('idMateria'));
																?>
																<input class="form-check-input" type="radio" name="<?php echo $materia->__GET('idMateria'); ?>" id="<?php echo $materia->__GET('idMateria'); ?>" value="<?php echo $materia->__GET('idMateria'); ?>">
																<label class="form-check-label" for="exampleRadios2">
																	Buscar Monitoria con Docente
																</label>
															</div>
														</th>
													</tr>
												</tbody>
											</table>
											<?php
											endforeach;
											endforeach;
											$inicio = $inicio+3;
											?>
										</div>
									</div>
									<?php
								}else{
									?>
									<div class="carousel-item" style="background: #7FADEF">
										<div style="margin: 5%; padding: 5%">
											<table class="table table-striped" style="text-align: center;">
												<thead>
													<tr style="background: #86E6F0; color: white;">
														<th>Nombre Materia</th>
														<th>Buscar Docente</th>

													</tr>
												</thead>
											</table>
											<?php
											foreach($controlCarreraMateria->BuscarMaterias($idCarrera,$inicio) as $carreraMateria):
												?>
											<table class="table table-striped" style="text-align: center;">
												<thead>
													<tr>
														<th scope="col" style="color: #7FADEF">Nombre Materia</th>
														<th scope="col" style="color: #7FADEF">Buscar Docente</th>

													</tr>
												</thead>
												<?php
												foreach($controlMateria->Buscar($carreraMateria->__GET('Materia_idMateria')) as $materia):
													?>
												<tbody style="background: white">
													<tr>
														<th scope="col"><?php echo $materia->__GET('Nombre'); ?></th>
														<th scope="col">
															<div class="form-check">
																<?php
																array_push($materias,$materia->__GET('idMateria'));
																?>
																<input class="form-check-input" type="radio" name="<?php echo $materia->__GET('idMateria'); ?>" id="<?php echo $materia->__GET('idMateria'); ?>" value="<?php echo $materia->__GET('idMateria'); ?>">
																<label class="form-check-label" for="exampleRadios2">
																	Buscar Monitoria con Docente
																</label>
															</div>
														</th>
													</tr>
												</tbody>
											</table>
											<?php
											endforeach;
											endforeach;
											$inicio = $inicio+3;
											?>
										</div>
									</div>
									<?php
								}
							}
							?>
						</div>
					</div>
				</div>

				<div class="modal-footer col-md-12">	
					<button type="submit" class="btn btn-primary botonIngresar" id="enviarFormulario" name="enviar">Buscar Docente</button>
				</div>
			</form>
			<?php
			if (isset($_POST['enviar'])) {

				for($i = 0; $i < sizeof($materias); $i++){
					$id = $materias[$i];
					if(!$_POST[$id]){
					}else{
						foreach($controlMateria->Buscar($id) as $materia):
							$departamento = $materia->__GET('Departamento_idDepartamento');
						endforeach;
						?>
						<br><br>
						<div style="height: 250px; width: 100%px">
							<div class="modal-header headerModal">
								<h5 class="modal-title" id="titleLabel">Selecciona el Docente que deseas</h5>
							</div>
							<form method="POST" action="calendario.php?materia=<?php echo $id ?>">
								<div class="modal-body" style="width: 50%; height: 100%; margin-left: 25%">
									<div class="row">
										<label for="inputEmail4">Selecciona unicamente un docente</label>
										<select id="docente" class="form-control col-md-12" required name="docenteMonitoria">
											<option selected disabled>Selecciona una opcion</option>
											<?php
											foreach($controlDocente->Listar($departamento) as $docente):
												foreach($controlUsuario->Buscar($docente->__GET('Usuario_Usuario')) as $informacionDocente):
													?>
												<option value="<?php echo $informacionDocente->__GET('Usuario'); ?>"><?php echo $informacionDocente->__GET('Nombre'); ?></option>
												<?php
												endforeach;
												endforeach;
												?>
											</select>
											<div class="modal-footer col-md-12">	
											<button type="submit" class="btn btn-primary botonIngresar" id="enviarFormulario" name="enviarInfo">Buscar Docente</button>
											</div>
										</div>
									</div>
								</form>
							</div>
							<?php
						}
					}
				}
				?>


			</div>
			<script src="../../js/jquery-3.4.1.min.js"></script>
			<script src="../../js/bootstrap.min.js"></script>
		</body>
		</html>




		<?php
	}
	?>