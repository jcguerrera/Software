<?php

session_start();
$usuario = $_SESSION['usuario'];
$tam = strlen($usuario);
if(($tam == 0) || ($tam == null)){
	header("Location:../inicio/paginaPrincipal.php");
	die();
}
require_once "menu.php";
require_once '../../model/modelUsuarios.php';
require_once '../../controller/UsuarioController.php';
require_once '../../model/modelMateria.php';
require_once '../../controller/MateriaController.php';
$controlUsuarios = new ControllerUsuario();
$nombreEstudiante = null;
$correoEstudiante = null;
$controlMaterias = new ControllerMateria();
$nombreMateria = null;
foreach($controlUsuarios->Buscar($usuario) as $user):
	$nombreEstudiante = $user->__GET('Nombre');
	$correoEstudiante = $user->__GET('Correo');
endforeach;

$nombreDocente = strtoupper($_GET['nombreDocente']);
$apellidoDocente = strtoupper($_GET['apellidoDocente']);
$idDocente = $_GET['idDocente'];
$correoDocente = $_GET['correoDocente'];
$diaMonitoria = $_GET['dia'];
$mesMonitoria = $_GET['mes'];
$añoMonitoria = $_GET['año'];
$materia = $_GET['materia'];
foreach($controlMaterias->Buscar($materia) as $materiaInfo):
	$nombreMateria = $materiaInfo->__GET('Nombre');
endforeach;
$fecha = $añoMonitoria."-".$mesMonitoria."-".$diaMonitoria;
//echo "Nombre: ".$nombreDocente." apellido: ".$apellidoDocente." id: ".$idDocente." correo: ".$correoDocente." dia Monitoria: ".$diaMonitoria." mes Monitoria: ".$mesMonitoria." año Monitoria: ".$añoMonitoria." Materia: ".$materia;

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Agregar Monitoria</title>
	<link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
</head>
<body>
	<div class="agregarCarrera" style=" width: 70%; padding: 5%; height: 100%; float: right; margin-top: -25%; margin-right: 5%">
		<div class="modal-header headerModal">
			<h5 class="modal-title" id="titleLabel">Ultimos detalles de la monitoria</h5>
		</div>
		<br>
		<form method="POST" action="registrarMonitoria.php?idDocente=<?php echo $idDocente ?>&idMateria=<?php echo $materia?>&fecha=<?php echo $fecha?>&nombreEstudiante=<?php echo $nombreEstudiante?>&nombreDocente=<?php echo $nombreDocente?>&nombreMateria=<?php echo $nombreMateria?>&correoDocente=<?php echo $correoDocente?>&correoEstudiante=<?php echo $correoEstudiante?>">
			<div class="modal-body">
				<div class="row">
					<div class="form-group col-md-12" style="display: none;">
						<label for="inputEmail4">Id Docente</label>
						<input type="text" class="form-control" placeholder="<?php echo $idDocente ?>" required name="id" disabled>
					</div>
					<div class="form-group col-md-6">
						<label for="inputEmail4">Nombre del Docente</label>
						<input type="text" class="form-control" placeholder="<?php echo $nombreDocente ?>" required name="nombre" disabled>
					</div>
					<div class="form-group col-md-6">
						<label for="inputEmail4">Apellido del Docente</label>
						<input type="text" class="form-control" placeholder="<?php echo $apellidoDocente ?>" required name="apellido" disabled>
					</div>
					<div class="form-group col-md-6">
						<label for="inputEmail4">Correo del Docente</label>
						<label for="inputEmail4">... Anotalo por si algo</label>
						<input type="email" class="form-control" placeholder="<?php echo $correoDocente ?>" required name="correo" disabled>
					</div>
					<div class="form-group col-md-6">
						<label for="inputEmail4">Fecha de la Monitoria</label>
						<input type="text" class="form-control" placeholder="<?php echo $fecha;?>" required name="fecha" disabled>
					</div>
					<div class="form-group col-md-6" style="display: none;">
						<label for="inputEmail4">Materia de la Monitoria</label>
						<input type="text" class="form-control" placeholder="<?php echo $materia;?>" required name="idMateria" disabled>
					</div>
					<div class="form-group col-md-6">
						<label for="inputEmail4">Materia de la Monitoria</label>
						<input type="text" class="form-control" placeholder="<?php echo $nombreMateria;?>" required name="materia" disabled>
					</div>
					<div class="form-group col-md-6">
						<label for="inputEmail4">Nombre del Estudiante</label>
						<input type="text" class="form-control" placeholder="<?php echo $nombreEstudiante ?>" required name="nombreEstudiante" disabled>
					</div>
					<div class="form-group col-md-6" style="display: none;">
						<label for="inputEmail4">Id del Estudiante</label>
						<input type="text" class="form-control" placeholder="<?php echo $usuario ?>" required name="idEstudiante" disabled>
					</div>
					<div class="form-group col-md-6">
						<label for="inputEmail4">Hora de Inicio (Formato 24:00 Horas)</label>
						<input type="text" class="form-control" placeholder="Escribe la hora de inicio de la Monitoria" required name="horaInicio" min="6:00" max="20:30">
					</div>
					<div class="form-group col-md-6">
						<label for="inputEmail4">¿Por cuanto tiempo será tu monitoria? (minutos)</label>
						<input type="text" class="form-control" placeholder="Digita el tiempo de duracion" required name="tiempo">
					</div>
				</div>
			</div>
			<div class="modal-footer">	
				<button type="submit" class="btn btn-primary botonIngresar" name="enviar">Registrar Monitoria</button>
			</div>
		</form>

	</div>

</body>
</html>