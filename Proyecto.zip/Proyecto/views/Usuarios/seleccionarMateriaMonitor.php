<?php
require_once "menu.php";

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Solicitar Monitoria</title>
	<link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
</head>
<body>

	<div id="cuadro" class="agregarCarrera" style=" width: 70%; padding: 5%; height: 100%; float: right; margin-top: -25%; margin-right: 5%; display: block;">

		<div class="modal-header headerModal">
			<h5 class="modal-title" id="titleLabel">Esta Funcionalida aún está en desarrollo</h5>
		</div>


	</div>
	<script src="../../js/jquery-3.4.1.min.js"></script>
	<script src="../../js/bootstrap.min.js"></script>
</body>
</html>
