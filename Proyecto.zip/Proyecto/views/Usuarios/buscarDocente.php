<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Buscar un Docente</title>
	<link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
</head>
<body>
	<?php
	//error_reporting(0);
	require_once '../../model/modelDocente.php';
	require_once '../../controller/DocenteController.php';
	require_once '../../model/modelCarrera.php';
	require_once '../../controller/CarreraController.php';
	require_once '../../model/modelCarreraMateria.php';
	require_once '../../controller/CarreraMateriaController.php';
	require_once "menu.php";

	$docente = new Docente();
	$carreraMateria = new CarreraMateria();
	$controlCarreraMateria = new ControllerCarreraMateria();
	$controlCarrera = new ControllerCarrera();
	$controlMaterias = new ControllerMateria();
	$paginas = ceil((count($controlMaterias->contador()))/3);
	$inicio = 0;
	$materias = array();
	$verificarEstado = False;
	//$inicio = ($_GET['pagina']-1)*3;
	?>
	<div class="agregarCarrera" style=" width: 70%; padding: 5%; height: 100%; float: right; margin-top: -25%; margin-right: 5%">
		<div class="modal-header headerModal">
			<h5 class="modal-title" id="titleLabel">Agregar Carrera</h5>
		</div>
		<br>
		<form method="POST" >
			<div class="modal-body">
				<div class="row">
					<div class="form-group col-md-12">
						<label for="inputEmail4">Nombre Carrera</label>
						<input type="text" class="form-control" placeholder="Nombre Carrera" required name="nombreCarrera">
					</div>
				</div>
			</div>
			<br>
			<div class="modal-body">
				<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
					<ol class="carousel-indicators">
						<?php
						for($i = 0; $i < $paginas; $i++){
							if($i == 0){
								?>
								<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
								<?php
							}else{
								?>
								<li data-target="#carouselExampleIndicators" data-slide-to="<?php echo "$i"; ?>"></li>
								<?php
							}
						}
						?>

					</ol>
					<div class="carousel-inner">
						<?php
						for($i = 0; $i < $paginas; $i++){
							if($i == 0){
								?>
								<div class="carousel-item active" style="background: #7FADEF">
									<div style="margin: 10% 5%; padding: 5%">
										<table class="table table-striped" style="text-align: center;">
											<thead>
												<tr style="background: #86E6F0; color: white;">
													<th scope="col">Nombre Materia</th>
													<th scope="col">Seleccionar</th>

												</tr>
											</thead>
											<tbody style="background: white">
												<?php

													foreach($controlMaterias->ListarSlide($inicio,3) as $materia):
														?>
													<tr>
														<th scope="col"><?php echo $materia->__GET('Nombre'); ?></th>
														<th scope="col">
															<div class="form-check form-check">
															<?php
															array_push($materias, $materia->__GET('idMateria'));
															?>
																<input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="<?php echo strval($materia->__GET('idMateria')) ?>" name="<?php echo strval($materia->__GET('idMateria')) ?>">
															</div>
														</th>
													</tr>
													<?php
													endforeach;
													$inicio = $inicio+3;
													?>
											</tbody>
										</table>
									</div>
								</div>
								<?php
							}else{
								?>
								<div class="carousel-item" style="background: #7FADEF">
									<div style="margin: 10% 5%; padding: 5%">
									<table class="table table-striped" style="text-align: center;">
											<thead>
												<tr style="background: #86E6F0; color: white;">
													<th scope="col">Nombre Materia</th>
													<th scope="col">Seleccionar</th>

												</tr>
											</thead>
											<tbody style="background: white">
												<?php

													foreach($controlMaterias->ListarSlide($inicio,3) as $materia):
														?>
													<tr>
														<th scope="col"><?php echo $materia->__GET('Nombre'); ?></th>
														<th scope="col">
															<div class="form-check form-check">
																<?php
																array_push($materias, $materia->__GET('idMateria'));
																?>

																<input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="<?php echo strval($materia->__GET('idMateria')) ?>" name="<?php echo strval($materia->__GET('idMateria')) ?>">
															</div>
														</th>
													</tr>
													<?php
													endforeach;
													$inicio = $inicio+3;
													?>
											</tbody>
										</table>
										</div>
								</div>
								<?php
							}
						}
						?>
						</div>
					</div>
					<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
						<span class="carousel-control-prev-icon" aria-hidden="true"></span>
						<span class="sr-only">Previous</span>
					</a>
					<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
						<span class="carousel-control-next-icon" aria-hidden="true"></span>
						<span class="sr-only">Next</span>
					</a>
				</div>

				<div class="modal-footer col-md-12">	
					<button type="submit" class="btn btn-primary botonIngresar" name="enviar">Agregar</button>
				</div>
			</div>
	<?php
	if (isset($_POST['enviar'])) {
		$carrera->__SET('Nombre',$_POST['nombreCarrera']);
		if($controlCarrera->Insertar($carrera) == true){
			for($i = 0; $i < sizeof($materias); $i++){
				$id = $materias[$i];
				if(!$_POST[$id]){
					
				}else{
					foreach($controlCarrera->BuscarXNombre($_POST['nombreCarrera']) as $carrera):
						$idCarrera = $carrera->__GET('idCarrera');
						$carreraMateria->__SET('Materia_idMateria',$id);
						$carreraMateria->__SET('Carrera_idCarrera',$idCarrera);
						if($controlCarreraMateria->Insertar($carreraMateria) == true){
							$verificarEstado = True;
						}else{
							$verificarEstado = False;
						}
					endforeach;
				}
			}
		}else{
			echo "Error";
		}
		if($verificarEstado == true){
			?>
			<script language="JavaScript" type="text/javascript">
				alert("El registro de la carrera fue exitoso");
			</script>
			<meta http-equiv="refresh" content="0; url=menu.php">
			<?php
		}else{
			?>
			<script language="JavaScript" type="text/javascript">
				alert("Hubo un error al registrar la carrera");
			</script>
			<meta http-equiv="refresh" content="0; url=menu.php">
			<?php
		}
		
	}
	?>
</form>
</div>
<script src="../../js/jquery-3.4.1.min.js"></script>
<script src="../../js/bootstrap.min.js"></script>
</body>
</html>