<?php
session_start();
$usuario = $_SESSION['usuario'];
$tam = strlen($usuario);
if(($tam == 0) || ($tam == null)){
	header("Location:../inicio/paginaPrincipal.php");
	die();
}
$verificarMenu = False;

if(!$_GET){
	header('Location:listarMonitorias.php?pagina=1');
}

require_once '../../model/modelMonitoria.php';
require_once '../../controller/MonitoriaController.php';
require_once '../../model/modelMateria.php';
require_once '../../controller/MateriaController.php';
require_once '../../model/modelUsuarios.php';
require_once '../../controller/UsuarioController.php';

$nombreMateria = null;
$nombreEstudiante = null;

$controlMonitoria = new ControllerMonitoria();
$controlMateria = new ControllerMateria();
$controlUsuarios = new ControllerUsuario();
$paginas = ceil((count($controlMonitoria->contadorEstudiante($usuario)))/3);
$inicio = ($_GET['pagina']-1)*3;

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Listar Monitorias</title>
	<link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
</head>
<body>
	<nav class="navbar navbar-expand-lg">
		<div class="container">
			<div>
				<a class="navbar-brand" href="index.php">
					<img src="../../imagenes/eafit.png" style="width: 120px; height: 50px">
				</a>
			</div>
		</div>
	</nav>
	<nav class="navbar navbar-expand-lg opciones" style="max-width:100%;height:auto;">
		<div class="container">
			<div class="collapse navbar-collapse" id="navbarResponsive">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<span class="glyphicon glyphicon-asterisk"></span>
						<a class="nav-link color_Blanco" href="http://www.eafit.edu.co/biblioteca/Paginas/inicio.aspx" target="_blank">Biblioteca</a>
					</li>
					<li class="nav-item">
						<a class="nav-link color_Blanco" href="https://app.eafit.edu.co/ulises/login.do" target="_blank">Ulises</a>
					</li>
					<li class="nav-item">
						<a class="nav-link color_Blanco" href="https://interactiva.eafit.edu.co/ei" target="_blank">Interactiva</a>
					</li>
					<li class="nav-item">
						<a class="nav-link color_Blanco" href="http://correo.eafit.edu.co/" target="_blank">Correo 365</a>
					</li>
					<li class="nav-item">
						<a class="nav-link color_Blanco" href="cerrarSesion.php">Salir</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	<div class="menu">
		<br>
		<div class="contenedorImagen">
			<div class="bloqueImagen" align="middle">
				<img class="imagen" src="../../imagenes/user.png">
			</div>
			<div class="usuario">
				<h1 class="text-white textUsuario">Bienvenido <?php echo $usuario?></h1>
			</div>
		</div>
		<ul class="nav flex-column">
			<li class="nav-item">
				<div id="monitoria" class="opcionPrincipal">
					<a class="nav-link text-white">Monitorias</a>
				</div>
				<div id="opcionesMonitoria" style="display: none;">
					<ul class="nav flex-column">
						<li class="nav-item suboption">
							<a class="nav-link color_Blanco" href="listarMonitorias.php">Solicitudes de Monitorias</a>
						</li>
						
					</ul>
				</div>
			</li>
			<li class="nav-item">
				<div id="configuracion" class="opcionPrincipal">
					<a class="nav-link text-white">Configuracion Cuenta</a>
				</div>
				<div id="opcionesConfiguracion" class="opcionesConfiguraciones">
					<ul class="nav flex-column">
						<li class="nav-item suboption">
							<a class="nav-link color_Blanco" href="cerrarSesion.php">Cerrar Sesion</a>
						</li>
						<li class="nav-item suboption">
							<a class="nav-link color_Blanco" href="informacionUser.php?user=<?php echo $usuario;?>">Actualizar Datos</a>
						</li>
					</ul>
				</div>
			</li>

		</ul>
	</div>

	<br><br>
	<div class="agregarCarrera" style=" width: 70%; padding: 5%; height: 100%; float: right; margin-top: -25%; margin-right: 5%">
		<div class="modal-header headerModal">
			<h5 class="modal-title" id="titleLabel">Monitorias Solicitadas</h5>
		</div>
		<br><br>
		<table class="table table-striped" style="text-align: center;">
			<thead>
				<tr class="titulosTabla">
					<th scope="col">Nombre Estudiante</th>
					<th scope="col">Materia</th>
					<th scope="col">Fecha Inicial</th>
					<th scope="col">Fecha Final</th>
					<th scope="col">Estado</th>

				</tr>
			</thead>
			<tbody>
				<?php

				foreach($controlMonitoria->ListarMonitoriasEstudiante($usuario,$inicio) as $monitoria):
					?>
				<tr>
					<?php
					foreach($controlUsuarios->Buscar($monitoria->__GET('Estudiante_Usuario_Usuario')) as $user):
						$nombreEstudiante = $user->__GET('Nombre');
					endforeach;
					?>
					<?php
					foreach($controlMateria->Buscar($monitoria->__GET('Materia_idMateria')) as $materia):
						$nombreMateria = $materia->__GET('Nombre');
					endforeach;
					?>
					<th scope="col"><?php echo $nombreEstudiante; ?></th>
					<th scope="col"><?php echo $nombreMateria; ?></th>
					<th scope="col"><?php echo $monitoria->__GET('Fecha_Inicio'); ?></th>
					<th scope="col"><?php echo $monitoria->__GET('Fecha_Final'); ?></th>
					<th scope="col"><?php echo $monitoria->__GET('Estado'); ?></th>
				</tr>
				<?php
				endforeach;
				?>
			</tbody>
		</table>
	</div>

	<br><br>
	<div class="paginacion" style="margin-top: 0%;  float: right; margin-right: 32%">
		<nav aria-label="Page navigation example">
			<ul class="pagination justify-content-center">
				<li class="page-item <?php echo $_GET['pagina']==1 ? 'disabled' : ''?>">
					<a class="page-link" href="listarMonitorias.php?pagina=<?php echo $_GET['pagina']-1?>" tabindex="-1">Anterior</a>
				</li>

				<?php
				for($i = 0; $i < $paginas; $i++){
					?>
					<li class="page-item <?php echo $_GET['pagina']==$i+1 ? 'active' : ''?>"><a class="page-link" href="listarMonitorias.php?pagina=<?php echo $i+1;?>"><?php echo $i+1; ?></a></li>
					<?php
				}
				?>
				<li class="page-item <?php echo $_GET['pagina']==$paginas ? 'disabled' : ''?>">
					<a class="page-link" href="listarMonitorias.php?pagina=<?php echo $_GET['pagina']+1?>">Siguiente</a>
				</li>
			</ul>
		</nav>
	</div>

	<script>
		document.getElementById("monitoria").onclick = function() {ShowOpcionesMonitorias()};
		document.getElementById("configuracion").onclick = function() {ShowOpcionesConfiguraciones()};

		function ShowOpcionesConfiguraciones() {
			document.getElementById("opcionesConfiguracion").style.display = "block";
			document.getElementById("opcionesMonitoria").style.display = "none";
		}

		function ShowOpcionesMonitorias() {
			document.getElementById("opcionesConfiguracion").style.display = "none";
			document.getElementById("opcionesMonitoria").style.display = "block";
		}

	</script>
	<script src="../../js/jquery-3.4.1.min.js"></script>
	<script src="../../js/bootstrap.min.js"></script>
</body>
</html>