<?php

session_start();
$usuario = $_SESSION['usuario'];
$tam = strlen($usuario);
if(($tam == 0) || ($tam == null)){
    header("Location:../inicio/paginaPrincipal.php");
    die();
}
require_once '../../model/modelMonitoria.php';
require_once '../../controller/MonitoriaController.php';
//error_reporting(0);
$controlMonitoria = new ControllerMonitoria();
$monitoria = new Monitoria();


$idDocente = $_GET['idDocente'];
$idMateria = $_GET['idMateria'];
$fecha = $_GET['fecha'];
$nombreEstudiante = strtoupper($_GET['nombreEstudiante']);
$nombreDocente = strtoupper($_GET['nombreDocente']);
$nombreMateria = strtoupper($_GET['nombreMateria']);
$cantidad = $_POST['tiempo'];

//$correoDocente = $_GET['correoDocente'];
//$correoEstudiante = $_GET['correoEstudiante'];

$correoDocente = "261200.cg@gmail.com";
$correoEstudiante = "261200.cg@gmail.com";

$hora = $_POST['horaInicio'];
$fechaInicial = $fecha." ".$hora.":00.000000";
$fechaFinal = $fecha." ".$hora.":00.000000";

$monitoria->__SET('Fecha_Inicio',$fechaInicial);
$monitoria->__SET('Fecha_Final',$fechaFinal);
$monitoria->__SET('Materia_idMateria',$idMateria);
$monitoria->__SET('Estado',"SOLICITANDO");
$monitoria->__SET('Monitor_Usuario_Usuario',null);
$monitoria->__SET('Docente_Usuario_Usuario',$idDocente);
$monitoria->__SET('Estudiante_Usuario_Usuario',$usuario);

if($controlMonitoria->Insertar($monitoria) == true){
    ?>
    <script language="JavaScript" type="text/javascript">
        alert("La monitoria fue Solicitada correctamente");
    </script>
    <meta http-equiv="refresh" content="0; url=enviarConfirmacion.php?nombreMateria=<?php echo $nombreMateria?>&nombreDocente=<?php echo $nombreDocente?>&nombreEstudiante=<?php echo $nombreEstudiante?>&correoEstudiante=<?php echo $correoEstudiante?>&correoDocente=<?php echo $correoDocente?>&fecha=<?php echo $fechaInicial?>&cantidad=<?php echo $cantidad?>">
    <?php
}else{
    ?>
    <script language="JavaScript" type="text/javascript">
    alert("Ocurrio un error en tu solicitud");
    </script>
    <meta http-equiv="refresh" content="0; url=menu.php">
    <?php
}


?>