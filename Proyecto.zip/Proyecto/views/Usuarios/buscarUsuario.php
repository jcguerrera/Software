<?php
require_once '../../model/modelUsuarios.php';
require_once '../../controller/UsuarioController.php';
$control = new ControllerUsuario();

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Buscar Usuario</title>
	<link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
</head>
<body>
	<div>
		<form  action="#" method="POST">
			<input type="text" name="busqueda" class="form-control">
			<button name="enviar" class="btn btn-secondary">Buscar</button>
			<!--<input type="submit" name="enviar" placeholder="enviar">-->
		</form>
	</div>
	<div>
		<?php
		if(isset($_POST['enviar'])){
			$nombre = $_POST['busqueda'];
			if($control->BuscarActualizar($nombre)){
				?>
				<table class="table table-striped">
			<thead>
				<tr class="titulosTabla">
					<th scope="col">Usuario</th>
					<th scope="col">Tipo de Usuario</th>
					<th scope="col">Nombre</th>
					<th scope="col">Apellido</th>
					<th scope="col">Correo</th>
					<th scope="col">Opcion</th>

				</tr>
			</thead>
			<tbody>
				<?php

					foreach($control->BuscarActualizar($nombre) as $usuario):
						?>
					<tr>
						<th scope="col"><?php echo $usuario->__GET('Usuario'); ?></th>
						<th scope="col"><?php echo $usuario->__GET('Tipo_Usuario'); ?></th>
						<th scope="col"><?php echo $usuario->__GET('Nombre'); ?></th>
						<th scope="col"><?php echo $usuario->__GET('Apellido'); ?></th>
						<th scope="col"><?php echo $usuario->__GET('Correo'); ?></th>
						<th scope="col"><a href="editarInformacionUsuario.php?id=<?php echo $usuario->__GET('Usuario'); ?>"><img src="../../imagenes/editar.png" style="width: 25px; height: 25px"></a></th>
					<!--<th scope="col"><button type="button" class="btn btn-danger" data-toggle="modal" data-target="#confirmacionEliminacion">
						<img src="../../imagenes/cerrar.png" style="width: 25px; height: 25px">
					</button></th>-->
				</tr>
				<?php
				endforeach;
			?>
		</tbody>
	</table>
				<?php
			}else{
				echo "No se encontraron datos";
			}
			
		}
		?>
	</div>

</body>
</html>