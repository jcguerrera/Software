<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Agregar Monitoria</title>
    <link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
    <link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
</head>
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
$mail = new PHPMailer(true);

$correoDocente = $_GET['correoDocente'];
$correoEstudiante = $_GET['correoEstudiante'];
$nombreEstudiante = $_GET['nombreEstudiante'];
$nombreDocente = $_GET['nombreDocente'];
$nombreMateria = $_GET['nombreMateria'];
$cantidad = $_GET['cantidad'];
$fecha = $_GET['fecha'];

//echo "doce: ".$nombreDocente." correo Do: ".$correoDocente." est: ".$nombreEstudiante." correo estu: ".$correoEstudiante." materia: ".$nombreMateria." fecha: ".$fecha." cantidad: ".$cantidad;


try {
    //Server settings
    $mail->SMTPDebug = 2;                      // Enable verbose debug output
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = '261200.cg@gmail.com';                     // SMTP username
    $mail->Password   = 'qncKKG37*';                               // SMTP password
    $mail->SMTPSecure = 'tls';         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` also accepted
    $mail->Port       = 587;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('261200.cg@gmail.com', 'Cesar');    // Add a recipient
    $mail->addAddress($correoDocente);   
    //$mail->addAddress('cagarciap@eafit.edu.co');              // Name is optional

    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Nueva Solicitud de Monitoria';
    $mail->Body    = 'Tiene una nueva Solicitud de Monitoria, <br> Con el estudiante: '.$nombreEstudiante.' el dia: '.$fecha.' con una duracion de: '.$cantidad.' minutos correspondiente a la materia: '.$nombreMateria.' <br> Por Favor verifica tu cuenta en el sistema de Monitorias Eafit <br> <a class="nav-link" href="http://localhost/Proyecto/views/inicio/paginaPrincipal.php" target="_blank">Monitorias</a>';

    $mail->send();
    ?>
    <script language="JavaScript" type="text/javascript">
        alert("Se envio una solicitud al correo del Docente");
    </script>
    <meta http-equiv="refresh" content="0; url=menu.php">
    <?php
} catch (Exception $e) {
    echo 'Error al enviar el mensaje:'.$mail->ErrorInfo;
}

?>