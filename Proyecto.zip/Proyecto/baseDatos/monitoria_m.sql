-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 12-11-2019 a las 08:27:33
-- Versión del servidor: 5.7.24
-- Versión de PHP: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `monitoria_m`
--
CREATE DATABASE monitoria_m;
USE monitoria_m;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carrera`
--

DROP TABLE IF EXISTS `carrera`;
CREATE TABLE IF NOT EXISTS `carrera` (
  `idCarrera` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`idCarrera`),
  UNIQUE KEY `idCarrera_UNIQUE` (`idCarrera`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `carrera`
--

INSERT INTO `carrera` (`idCarrera`, `Nombre`) VALUES
(1, 'sistemas'),
(2, 'matematica'),
(3, 'fffff'),
(4, 'agronomica'),
(5, 'finanzas'),
(6, 'biologia'),
(7, 'producto'),
(11, 'derecho'),
(12, 'administracion'),
(13, 'penal'),
(14, 'administraciones');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamento`
--

DROP TABLE IF EXISTS `departamento`;
CREATE TABLE IF NOT EXISTS `departamento` (
  `idDepartamento` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`idDepartamento`),
  UNIQUE KEY `idCarrera_UNIQUE` (`idDepartamento`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `departamento`
--

INSERT INTO `departamento` (`idDepartamento`, `Nombre`) VALUES
(1, 'basicas'),
(2, 'admin'),
(3, 'ciencias'),
(4, 'politica');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `docente`
--

DROP TABLE IF EXISTS `docente`;
CREATE TABLE IF NOT EXISTS `docente` (
  `Usuario_Usuario` varchar(45) NOT NULL,
  `Departamento_idDepartamento` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`Usuario_Usuario`),
  KEY `fk_Docente_Departamento1_idx` (`Departamento_idDepartamento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `docente`
--

INSERT INTO `docente` (`Usuario_Usuario`, `Departamento_idDepartamento`) VALUES
('edis', 3),
('edw', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiante`
--

DROP TABLE IF EXISTS `estudiante`;
CREATE TABLE IF NOT EXISTS `estudiante` (
  `Carrera_idCarrera` int(10) UNSIGNED NOT NULL,
  `Usuario_Usuario` varchar(45) NOT NULL,
  PRIMARY KEY (`Usuario_Usuario`),
  KEY `fk_Estudiante_Carrera1_idx` (`Carrera_idCarrera`),
  KEY `fk_Estudiante_Usuario1_idx` (`Usuario_Usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `estudiante`
--

INSERT INTO `estudiante` (`Carrera_idCarrera`, `Usuario_Usuario`) VALUES
(1, 'cagarciap'),
(1, 'dgarcia'),
(1, 'dgarciag'),
(2, 'fdgfhgjfrawrd'),
(3, 'dfdfd'),
(7, 'sanchez'),
(11, 'cris');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materia`
--

DROP TABLE IF EXISTS `materia`;
CREATE TABLE IF NOT EXISTS `materia` (
  `idMateria` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(45) NOT NULL,
  `Creditos` smallint(5) NOT NULL,
  `Departamento_idDepartamento` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`idMateria`),
  UNIQUE KEY `idMateria_UNIQUE` (`idMateria`),
  KEY `fk_Materia_Departamento1_idx` (`Departamento_idDepartamento`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `materia`
--

INSERT INTO `materia` (`idMateria`, `Nombre`, `Creditos`, `Departamento_idDepartamento`) VALUES
(2, 'ca', 1, 1),
(3, 'complicadores', 100, 3),
(4, 'bases', 12, 2),
(5, 'kjhgd', 5, 3),
(6, 'qewwe', 45, 1),
(7, 'hgjhjkh', 4, 4),
(8, 'hfhgjghi', 54, 1),
(9, 'ultima', 70, 1),
(10, 'jhhkj', 4, 3),
(11, 'kmhjmh', 12, 1),
(12, 'nbvgbv', 4, 2),
(13, 'integrador', 4, 2),
(14, 'matlab', 2, 1),
(15, 'fisica', 20, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materia_has_carrera`
--

DROP TABLE IF EXISTS `materia_has_carrera`;
CREATE TABLE IF NOT EXISTS `materia_has_carrera` (
  `Materia_idMateria` int(10) UNSIGNED NOT NULL,
  `Carrera_idCarrera` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`Materia_idMateria`,`Carrera_idCarrera`),
  KEY `fk_Materia_has_Carrera_Carrera1_idx` (`Carrera_idCarrera`),
  KEY `fk_Materia_has_Carrera_Materia1_idx` (`Materia_idMateria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `materia_has_carrera`
--

INSERT INTO `materia_has_carrera` (`Materia_idMateria`, `Carrera_idCarrera`) VALUES
(2, 11),
(3, 11),
(4, 11),
(2, 12),
(3, 12),
(4, 12),
(6, 12),
(9, 12),
(13, 12),
(14, 12),
(2, 14),
(13, 14),
(14, 14);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `monitor`
--

DROP TABLE IF EXISTS `monitor`;
CREATE TABLE IF NOT EXISTS `monitor` (
  `Usuario_Usuario` varchar(45) NOT NULL,
  `Numero_Contacto` mediumint(10) UNSIGNED NOT NULL,
  `Horas_Semanales` smallint(5) UNSIGNED NOT NULL,
  `Departamento_idDepartamento` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`Usuario_Usuario`),
  KEY `fk_Monitor_Departamento1_idx` (`Departamento_idDepartamento`),
  KEY `fk_Monitor_Usuario1_idx` (`Usuario_Usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `monitor`
--

INSERT INTO `monitor` (`Usuario_Usuario`, `Numero_Contacto`, `Horas_Semanales`, `Departamento_idDepartamento`) VALUES
('jperezs', 123, 10, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `monitoria`
--

DROP TABLE IF EXISTS `monitoria`;
CREATE TABLE IF NOT EXISTS `monitoria` (
  `Fecha_Inicio` datetime(6) NOT NULL,
  `Fecha_Final` datetime(6) NOT NULL,
  `Materia_idMateria` int(10) UNSIGNED NOT NULL,
  `Estado` enum('PENDIENTE','EN CURSO','FINALIZADO','SOLICITANDO') NOT NULL,
  `Monitor_Usuario_Usuario` varchar(45) DEFAULT NULL,
  `Docente_Usuario_Usuario` varchar(45) DEFAULT NULL,
  `Estudiante_Usuario_Usuario` varchar(45) NOT NULL,
  KEY `fk_Monitoria_Materia1_idx` (`Materia_idMateria`),
  KEY `fk_Monitoria_Monitor1_idx` (`Monitor_Usuario_Usuario`),
  KEY `fk_Monitoria_Docente1_idx` (`Docente_Usuario_Usuario`),
  KEY `fk_Monitoria_Estudiante1_idx` (`Estudiante_Usuario_Usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `monitoria`
--

INSERT INTO `monitoria` (`Fecha_Inicio`, `Fecha_Final`, `Materia_idMateria`, `Estado`, `Monitor_Usuario_Usuario`, `Docente_Usuario_Usuario`, `Estudiante_Usuario_Usuario`) VALUES
('2019-06-02 00:00:00.000000', '2019-06-04 00:00:00.000000', 3, 'SOLICITANDO', 'jperezs', NULL, 'sanchez'),
('2019-07-02 00:00:00.000000', '2019-07-04 00:00:00.000000', 3, 'PENDIENTE', NULL, 'edw', 'sanchez'),
('2019-11-07 09:00:00.000000', '2019-11-07 09:00:00.000000', 3, 'PENDIENTE', NULL, 'edw', 'sanchez'),
('2019-11-08 09:00:00.000000', '2019-11-08 09:00:00.000000', 3, 'PENDIENTE', NULL, 'edis', 'sanchez'),
('2019-11-20 09:00:00.000000', '2019-11-20 09:00:00.000000', 3, 'SOLICITANDO', NULL, 'edis', 'sanchez'),
('2019-11-20 09:00:00.000000', '2019-11-20 09:00:00.000000', 3, 'SOLICITANDO', NULL, 'edis', 'sanchez'),
('2019-11-20 12:00:00.000000', '2019-11-20 12:00:00.000000', 3, 'SOLICITANDO', NULL, 'edis', 'sanchez'),
('2019-11-23 11:00:00.000000', '2019-11-23 11:00:00.000000', 3, 'PENDIENTE', NULL, 'edw', 'sanchez');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `Usuario` varchar(45) NOT NULL,
  `Clave` varchar(100) NOT NULL,
  `Tipo_Usuario` enum('DOCENTE','MONITOR','ESTUDIANTE','ADMINISTRADOR') NOT NULL,
  `Nombre` varchar(45) NOT NULL,
  `Apellido` varchar(45) NOT NULL,
  `Correo` varchar(45) NOT NULL,
  PRIMARY KEY (`Usuario`),
  UNIQUE KEY `Usuario_UNIQUE` (`Usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`Usuario`, `Clave`, `Tipo_Usuario`, `Nombre`, `Apellido`, `Correo`) VALUES
('a', 'a', 'DOCENTE', 'a', 'a', 'a@a'),
('cagarciap', '154', 'ADMINISTRADOR', 'ce', 'garcia', 'cagarcia@eafit.edu.co'),
('cris', '154', 'ESTUDIANTE', 'cristian', 'alvarez', 'cristian@gmail.com'),
('dfdfd', 'fdfdfd', 'ESTUDIANTE', 'fgdfd', 'fdfd', 'fdfdf@fvdfdfdfd'),
('dgarcia', '159', 'ESTUDIANTE', 'daniel', 'garcia', 'dgarciag@eafit.edu.co'),
('dgarciag', 'zfdsf', 'ESTUDIANTE', 'daniel', 'garcia', 'dgarciag@eafit.edu.co'),
('edis', '789', 'DOCENTE', 'edison', 'valencia', 'ed@eafi.du.co'),
('edw', '123', 'DOCENTE', 'edwin', 'comm', 'ed@eafit.edu.co'),
('eli', '159', 'DOCENTE', 'elizabeth', 'suescun', 'eli@eafit.edu.co'),
('fdfdfd', 'fdfdfd', 'DOCENTE', 'fdfdfdf', 'dfdfd', 'fdfdf@fdfdfdf'),
('fdgfhgjfrawrd', 'hgfhghfrd', 'ESTUDIANTE', 'dasdt', 'fdfdgfd', 'faedgfgdg@fxfdfd'),
('jperezs', '123', 'MONITOR', 'sebas', 'perez', 'sebas@eafit.edu.co'),
('sanchez', '123', 'ESTUDIANTE', 'sofia', 'sanchez', 'sanchez@gmail.com');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `docente`
--
ALTER TABLE `docente`
  ADD CONSTRAINT `fk_Docente_Departamento1` FOREIGN KEY (`Departamento_idDepartamento`) REFERENCES `departamento` (`idDepartamento`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Docente_Usuario1` FOREIGN KEY (`Usuario_Usuario`) REFERENCES `usuario` (`Usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `estudiante`
--
ALTER TABLE `estudiante`
  ADD CONSTRAINT `fk_Estudiante_Carrera1` FOREIGN KEY (`Carrera_idCarrera`) REFERENCES `carrera` (`idCarrera`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Estudiante_Usuario1` FOREIGN KEY (`Usuario_Usuario`) REFERENCES `usuario` (`Usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `materia`
--
ALTER TABLE `materia`
  ADD CONSTRAINT `fk_Materia_Departamento1` FOREIGN KEY (`Departamento_idDepartamento`) REFERENCES `departamento` (`idDepartamento`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `materia_has_carrera`
--
ALTER TABLE `materia_has_carrera`
  ADD CONSTRAINT `fk_Materia_has_Carrera_Carrera1` FOREIGN KEY (`Carrera_idCarrera`) REFERENCES `carrera` (`idCarrera`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Materia_has_Carrera_Materia1` FOREIGN KEY (`Materia_idMateria`) REFERENCES `materia` (`idMateria`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `monitor`
--
ALTER TABLE `monitor`
  ADD CONSTRAINT `fk_Monitor_Departamento1` FOREIGN KEY (`Departamento_idDepartamento`) REFERENCES `departamento` (`idDepartamento`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Monitor_Usuario1` FOREIGN KEY (`Usuario_Usuario`) REFERENCES `usuario` (`Usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `monitoria`
--
ALTER TABLE `monitoria`
  ADD CONSTRAINT `fk_Monitoria_Docente1` FOREIGN KEY (`Docente_Usuario_Usuario`) REFERENCES `docente` (`Usuario_Usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Monitoria_Estudiante1` FOREIGN KEY (`Estudiante_Usuario_Usuario`) REFERENCES `estudiante` (`Usuario_Usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Monitoria_Materia1` FOREIGN KEY (`Materia_idMateria`) REFERENCES `materia` (`idMateria`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Monitoria_Monitor1` FOREIGN KEY (`Monitor_Usuario_Usuario`) REFERENCES `monitor` (`Usuario_Usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
