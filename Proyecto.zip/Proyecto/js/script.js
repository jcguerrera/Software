let nombreMeses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

let fechaOrdenador = new Date();
let diaOrdenador = fechaOrdenador.getDate();
let mesOrdenador = fechaOrdenador.getMonth();
let añoOrdenador = fechaOrdenador.getFullYear();

console.log(diaOrdenador + ' cap ' + mesOrdenador + ' ---- ' + añoOrdenador);

let capturafechas = document.getElementById('fechas');
let capturaMes = document.getElementById('mes');
let capturaAño = document.getElementById('año');

let capturaMesPrevio = document.getElementById('mesPrevio');
let capturaMesSiguiente = document.getElementById('mesSiguiente');

document.getElementById("mesPrevio").onclick = function() {ShowOpcionesMateria()};
function ShowOpcionesMateria() {
			document.getElementById("mes").style.background = "blue";
}



document.getElementById('mes').innerHTML = "Esto es un nuevo texto";


//capturaMes.textContent = nombreMeses[mesOrdenador];

//console.log(capturafechas+' -- ' + capturaMes+ ' --- ' + capturaAño);
