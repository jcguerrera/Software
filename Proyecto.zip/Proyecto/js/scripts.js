let nombreMeses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

let fechaOrdenador = new Date();
let diaOrdenador = fechaOrdenador.getDate();
let mesOrdenador = fechaOrdenador.getMonth();
let añoOrdenador = fechaOrdenador.getFullYear();

console.log(diaSemana + ' cap ' + mes + ' ---- ' + año);

let capturafechas = document.getElementById('fechas');
let capturaMes = document.getElementById('mes');
let capturaAño = document.getElementById('año');

console.log(capturafechas + ' captura ' + capturaMes + ' -- ' + capturaAño);

let capturaMesPrevio = document.getElementById('mesPrevio');
let capturaMesSiguiente = document.getElementById('mesSiguiente');

document.getElementById("mes").textContent = "Hola";


