<?php
include_once '../../model/conexion.php';
include_once '../../model/modelCarreraMateria.php';

class ControllerCarreraMateria extends Conexion{


	public function Insertar(CarreraMateria $carreraMateria){
		$insertar = "INSERT INTO materia_has_carrera (Materia_idMateria,Carrera_idCarrera) VALUES (?,?)";
		try{
			$this->conexion->prepare($insertar)->execute(array(
				$carreraMateria->__GET('Materia_idMateria'),
				$carreraMateria->__GET('Carrera_idCarrera')
				));
			return true;
		}catch(Exception $e){
			echo "Error ".$e;
		}

	}

	public function Listar(){
		$dato = array();
		$listar = "SELECT * FROM carrera ORDER BY Nombre";
		try{
			$resultado = $this->conexion->prepare($listar);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$carrera = new Carrera();
				$carrera->__SET('idCarrera',$dato->idCarrera);
				$carrera->__SET('Nombre',$dato->Nombre);
				$datos[]=$carrera;
			}
			return $datos;
		}catch(Exception $e){
			echo "Error ".$e;
		}
	}

	public function Contador($idCarrera){
		$dato = array();
		$datos = array();
		$buscar = "SELECT * FROM materia_has_carrera WHERE Carrera_idCarrera='$idCarrera'";
		try{
			$resultado = $this->conexion->prepare($buscar);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$carreraMateria = new CarreraMateria();
				$carreraMateria->__SET('Materia_idMateria',$dato->Materia_idMateria);
				$carreraMateria->__SET('Carrera_idCarrera',$dato->Carrera_idCarrera);
				$datos[]=$carreraMateria;
			}
			return $datos;
		}catch(Exception $e){
			echo "Error ".$e;
		}
	}
	

	public function BuscarMaterias($idCarrera, $inicio){
		$dato = array();
		$datos = array();
		$buscar = "SELECT * FROM materia_has_carrera WHERE Carrera_idCarrera='$idCarrera' LIMIT $inicio,3";
		try{
			$resultado = $this->conexion->prepare($buscar);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$carreraMateria = new CarreraMateria();
				$carreraMateria->__SET('Materia_idMateria',$dato->Materia_idMateria);
				$carreraMateria->__SET('Carrera_idCarrera',$dato->Carrera_idCarrera);
				$datos[]=$carreraMateria;
			}
			return $datos;
		}catch(Exception $e){
			echo "Error ".$e;
		}
	}







	public function BuscarXNombre($id){
		$dato=array();
		$datos=null;
		$consulta="SELECT * FROM Carrera WHERE idCarrera='$id'";
		try {
			$resultado=$this->conexion->prepare($consulta);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$carrera = new Carrera();
				$carrera->__SET('idCarrera',$dato->idCarrera);
				$carrera->__SET('Nombre',$dato->Nombre);
				$datos[]=$carrera;
			}
			return $datos;
		} catch (Exception $exception) {
			die($exception->getMessage());
		}
	}

	public function Actualizar(Carrera $carrera){
		$actualizar="UPDATE Carrera SET  Nombre=? where idCarrera=?";
		try {
			$this->conexion->prepare($actualizar)->execute(array(
				$carrera->__GET('Nombre'),
				));
			return true;
		} catch (Exception $exception) {
			echo "Error al actualizar datos ".$exception->getMessage();
		}
	}
}
?>