<?php
include_once "../../model/conexion.php";
include_once "../../model/modelDocente.php";

class ControllerDocente extends Conexion{


	public function Insertar(Docente $docente){
		$insertar = "INSERT INTO docente (Usuario_Usuario,Departamento_idDepartamento) VALUES (?,?)";
		try{
			$this->conexion->prepare($insertar)->execute(array(
				$docente->__GET('Usuario_Usuario'),
				$docente->__GET('Departamento_idDepartamento')
			));
			return true;
		}catch(Exception $e){
			echo "Error ".$e;
		}

	}

	public function Listar($departamento){
		$datos = null;
		$listar = "SELECT * FROM docente WHERE Departamento_idDepartamento = '$departamento'";
		try{
			$resultado = $this->conexion->prepare($listar);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$docente = new Docente();
				$docente->__SET('Usuario_Usuario',$dato->Usuario_Usuario);
				$docente->__SET('Departamento_idDepartamento',$dato->Departamento_idDepartamento);
				$datos[]=$docente;
			}
			return $datos;
		}catch(Exception $e){
			echo "Error ".$e;
		}
	}

	public function Buscar($id){
		$dato=array();
		$datos=null;
		$consulta="SELECT * FROM Docente WHERE idDocente='$id'";
		try {
			$resultado=$this->conexion->prepare($consulta);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$docente = new Docente();
				$docente->__SET('idDocente',$dato->idDocente);
				$docente->__SET('Nombre',$dato->Nombre);
				$docente->__SET('Correo',$dato->Correo);
				$datos[]=$docente;
			}
			return $datos;
		} catch (Exception $exception) {
			die($exception->getMessage());
		}
	}

	public function Actualizar(Docente $docente){
		$actualizar="UPDATE Docente SET  Nombre=?,Correo=? where idDocente=?";
		try {
			$this->conexion->prepare($actualizar)->execute(array(
				$docente->__GET('Nombre'),
				$docente->__GET('Correo'),
			));
			return true;
		} catch (Exception $exception) {
			echo "Error al actualizar datos ".$exception->getMessage();
		}
	}

}

?>