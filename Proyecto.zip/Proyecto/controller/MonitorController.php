<?php
include_once "../../model/conexion.php";
include_once "../../model/modelMonitor.php";

class ControllerMonitor extends Conexion{
    public function Insertar(Monitor $monitor){
		$insertar = "INSERT INTO monitor (Usuario_Usuario,Numero_Contacto,Horas_Semanales,Departamento_idDepartamento) VALUES (?,?,?,?)";
		try{
			$this->conexion->prepare($insertar)->execute(array(
                $monitor->__GET('Usuario_Usuario'),
                $monitor->__GET('Numero_Contacto'),
                $monitor->__GET('Horas_Semanales'),
                $monitor->__GET('Departamento_idDepartamento'),
			));
			return true;
		}catch(Exception $e){
			echo "Error ".$e;
		}

    }
    
    public function Listar(){
		$datos = null;
		$listar = "SELECT * FROM Monitor ORDER BY Nombre";
		try{
			$resultado = $this->$conexion->prepare($listar);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$monitor = new Monitor();
				$monitor->__SET('idMonitor',$dato->idMonitor);
                $monitor->__SET('Nombre',$dato->Nombre);
                $monitor->__SET('Correo',$dato->Correo);
                $monitor->__SET('Numero_Contacto',$dato->Numero_Contacto);
                $monitor->__SET('Horas_Semanales',$dato->Horas_Semanales);
                $monitor->__SET('Departamento_idDepartamento',$dato->Departamento_idDepartamento);
				$datos[]=$monitor;
			}
			return $datos;
		}catch(Exception $e){
			echo "Error ".$e;
		}
	}

	public function Buscar($id){
		$dato=array();
		$datos=null;
		$consulta="SELECT * FROM Monitor WHERE idMonitor='$id'";
		try {
			$resultado=$this->conexion->prepare($consulta);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$monitor = new Monitor();
				$monitor->__SET('idMonitor',$dato->idMonitor);
                $monitor->__SET('Nombre',$dato->Nombre);
                $monitor->__SET('Correo',$dato->Correo);
                $monitor->__SET('Numero_Contacto',$dato->Numero_Contacto);
                $monitor->__SET('Horas_Semanales',$dato->Horas_Semanales);
                $monitor->__SET('Departamento_idDepartamento',$dato->Departamento_idDepartamento);
				$datos[]=$monitor;
			}
			return $datos;
		} catch (Exception $exception) {
			die($exception->getMessage());
		}
	}

	public function Actualizar(Monitor $monitor){
		$actualizar="UPDATE Monitor SET  Nombre=?,Correo=?,Numero_Contacto=?,Horas_Semanales=?,Departamento_idDepartamento=? where idMonitor=?";
		try {
			$this->conexion->prepare($actualizar)->execute(array(
 				$monitor->__GET('Nombre'),
                $monitor->__GET('Correo'),
                $monitor->__GET('Numero_Contacto'),
                $monitor->__GET('Horas_Semanales'),
                $monitor->__GET('Departamento_idDepartamento'),
			));
			return true;
		} catch (Exception $exception) {
			echo "Error al actualizar datos ".$exception->getMessage();
		}
	}
}
?>