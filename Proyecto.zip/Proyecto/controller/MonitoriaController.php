<?php
include_once '../../model/conexion.php';
include_once '../../model/modelMonitoria.php';

class ControllerMonitoria extends Conexion{


	 public function Insertar(Monitoria $monitoria){
		$insertar = "INSERT INTO monitoria (Fecha_Inicio,Fecha_Final,Materia_idMateria,Estado,Monitor_Usuario_Usuario,Docente_Usuario_Usuario,Estudiante_Usuario_Usuario) VALUES (?,?,?,?,?,?,?)";
		try{
			$this->conexion->prepare($insertar)->execute(array(
				$monitoria->__GET('Fecha_Inicio'),
				$monitoria->__GET('Fecha_Final'),
				$monitoria->__GET('Materia_idMateria'),
				$monitoria->__GET('Estado'),
				$monitoria->__GET('Monitor_Usuario_Usuario'),
				$monitoria->__GET('Docente_Usuario_Usuario'),
				$monitoria->__GET('Estudiante_Usuario_Usuario'),
			));
			return true;
		}catch(Exception $e){
			echo "Error ".$e;
		}

    }


    public function ListarMonitoriasSolicitadas($idDocente,$inicio){
		$dato = array();
		$listar = "SELECT * FROM monitoria WHERE Docente_Usuario_Usuario='$idDocente' AND Estado='SOLICITANDO' LIMIT $inicio,3";
		try{
			$resultado = $this->conexion->prepare($listar);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$monitoria = new Monitoria();
				$monitoria->__SET('Fecha_Inicio',$dato->Fecha_Inicio);
				$monitoria->__SET('Fecha_Final',$dato->Fecha_Final);
				$monitoria->__SET('Materia_idMateria',$dato->Materia_idMateria);
				$monitoria->__SET('Estado',$dato->Estado);
				$monitoria->__SET('Monitor_Usuario_Usuario',$dato->Monitor_Usuario_Usuario);
				$monitoria->__SET('Docente_Usuario_Usuario',$dato->Docente_Usuario_Usuario);
				$monitoria->__SET('Estudiante_Usuario_Usuario',$dato->Estudiante_Usuario_Usuario);
				$datos[]=$monitoria;
			}
			return $datos;
		}catch(Exception $e){
			echo "Error ".$e;
		}
	}

	public function contador($idDocente){
		$dato = array();
		$listar = "SELECT * FROM monitoria WHERE Docente_Usuario_Usuario='$idDocente' AND Estado='SOLICITANDO'";
		try{
			$resultado = $this->conexion->prepare($listar);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$monitoria = new Monitoria();
				$monitoria->__SET('Fecha_Inicio',$dato->Fecha_Inicio);
				$monitoria->__SET('Fecha_Final',$dato->Fecha_Final);
				$monitoria->__SET('Materia_idMateria',$dato->Materia_idMateria);
				$monitoria->__SET('Estado',$dato->Estado);
				$monitoria->__SET('Monitor_Usuario_Usuario',$dato->Monitor_Usuario_Usuario);
				$monitoria->__SET('Docente_Usuario_Usuario',$dato->Docente_Usuario_Usuario);
				$monitoria->__SET('Estudiante_Usuario_Usuario',$dato->Estudiante_Usuario_Usuario);
				$datos[]=$monitoria;
			}
			return $datos;
		}catch(Exception $e){
			echo "Error ".$e;
		}
	}

	public function ListarMonitoriasEstudiante($idEstudiante,$inicio){
		$dato = array();
		$listar = "SELECT * FROM monitoria WHERE Estudiante_Usuario_Usuario='$idEstudiante' LIMIT $inicio,3";
		try{
			$resultado = $this->conexion->prepare($listar);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$monitoria = new Monitoria();
				$monitoria->__SET('Fecha_Inicio',$dato->Fecha_Inicio);
				$monitoria->__SET('Fecha_Final',$dato->Fecha_Final);
				$monitoria->__SET('Materia_idMateria',$dato->Materia_idMateria);
				$monitoria->__SET('Estado',$dato->Estado);
				$monitoria->__SET('Monitor_Usuario_Usuario',$dato->Monitor_Usuario_Usuario);
				$monitoria->__SET('Docente_Usuario_Usuario',$dato->Docente_Usuario_Usuario);
				$monitoria->__SET('Estudiante_Usuario_Usuario',$dato->Estudiante_Usuario_Usuario);
				$datos[]=$monitoria;
			}
			return $datos;
		}catch(Exception $e){
			echo "Error ".$e;
		}
	}

	public function contadorEstudiante($idEstudiante){
		$dato = array();
		$listar = "SELECT * FROM monitoria WHERE Estudiante_Usuario_Usuario='$idEstudiante'";
		try{
			$resultado = $this->conexion->prepare($listar);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$monitoria = new Monitoria();
				$monitoria->__SET('Fecha_Inicio',$dato->Fecha_Inicio);
				$monitoria->__SET('Fecha_Final',$dato->Fecha_Final);
				$monitoria->__SET('Materia_idMateria',$dato->Materia_idMateria);
				$monitoria->__SET('Estado',$dato->Estado);
				$monitoria->__SET('Monitor_Usuario_Usuario',$dato->Monitor_Usuario_Usuario);
				$monitoria->__SET('Docente_Usuario_Usuario',$dato->Docente_Usuario_Usuario);
				$monitoria->__SET('Estudiante_Usuario_Usuario',$dato->Estudiante_Usuario_Usuario);
				$datos[]=$monitoria;
			}
			return $datos;
		}catch(Exception $e){
			echo "Error ".$e;
		}
	}


	public function Actualizar(Monitoria $monitoria){
		$actualizar="UPDATE monitoria SET Estado=? where Fecha_Inicio=? AND Fecha_Final=? AND Materia_idMateria=? AND Docente_Usuario_Usuario=? AND Estudiante_Usuario_Usuario=?";
	    try {
		    	$this->conexion->prepare($actualizar)->execute(array(
                    $monitoria->__GET('Estado'),
                    $monitoria->__GET('Fecha_Inicio'),
                    $monitoria->__GET('Fecha_Final'),
                    $monitoria->__GET('Materia_idMateria'),
                    $monitoria->__GET('Docente_Usuario_Usuario'),
                    $monitoria->__GET('Estudiante_Usuario_Usuario'),
                 ));
			    return true;
		    } catch (Exception $exception) {
			    echo "Error al actualizar datos ".$exception->getMessage();
		    }
	}

	public function Eliminar(Monitoria $monitoria){
		$eliminar="DELETE FROM monitoria WHERE Fecha_Inicio=? AND Fecha_Final=? AND Materia_idMateria=? AND Docente_Usuario_Usuario=? AND Estudiante_Usuario_Usuario=?";
	    try {
		    	$this->conexion->prepare($eliminar)->execute(array(
                    $monitoria->__GET('Fecha_Inicio'),
                    $monitoria->__GET('Fecha_Final'),
                    $monitoria->__GET('Materia_idMateria'),
                    $monitoria->__GET('Docente_Usuario_Usuario'),
                    $monitoria->__GET('Estudiante_Usuario_Usuario'),
                 ));
			    return true;
		    } catch (Exception $exception) {
			    echo "Error al eliminar la monitoria ".$exception->getMessage();
		    }
	}
}