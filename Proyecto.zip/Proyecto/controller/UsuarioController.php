<?php
include_once '../../model/conexion.php';
include_once '../../model/modelUsuarios.php';

class ControllerUsuario extends Conexion{

    public function Insertar(Usuario $usuario){
		$insertar = "INSERT INTO usuario (Usuario,Clave,Tipo_Usuario,Nombre,Apellido,Correo) VALUES (?,?,?,?,?,?)";
		try{
			$this->conexion->prepare($insertar)->execute(array(
				$usuario->__GET('Usuario'),
                $usuario->__GET('Clave'),
                $usuario->__GET('Tipo_Usuario'),
                $usuario->__GET('Nombre'),
                $usuario->__GET('Apellido'),
                $usuario->__GET('Correo'),
			));
			return true;
		}catch(Exception $e){
			echo "Error ".$e;
		}

    }
    
    public function Listar(){
		$datos = null;
		$listar = "SELECT * FROM Usuario";
		try{
			$resultado = $this->conexion->prepare($listar);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$usuario = new Usuario();
				$usuario->__SET('Usuario',$dato->Usuario);
                $usuario->__SET('Clave',$dato->Clave);
                $usuario->__SET('Tipo_Usuario',$dato->Tipo_Usuario);
                $usuario->__SET('Monitor_idMonitor',$dato->Monitor_idMonitor);
                $usuario->__SET('Docente_idDocente',$dato->Docente_idDocente);
                $usuario->__SET('Estudiante_idEstudiante',$dato->Estudiante_idEstudiante);
				$datos[]=$usuario;
			}
			return $datos;
		}catch(Exception $e){
			echo "Error ".$e;
		}
	}

	public function Buscar($id){
		$dato=array();
		$datos=null;
		$consulta="SELECT * FROM usuario WHERE Usuario='$id'";
		try {
			$resultado=$this->conexion->prepare($consulta);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$usuario = new Usuario();
				$usuario->__SET('Usuario',$dato->Usuario);
				$usuario->__SET('Clave',$dato->Clave);
				$usuario->__SET('Tipo_Usuario',$dato->Tipo_Usuario);
				$usuario->__SET('Nombre',$dato->Nombre);
				$usuario->__SET('Apellido',$dato->Apellido);
				$usuario->__SET('Correo',$dato->Correo);
				$datos[]=$usuario;
			}
			return $datos;
		} catch (Exception $exception) {
			die($exception->getMessage());
		}
	}


	public function BuscarActualizar($nombre){
		$dato=array();
		$datos=null;
		$consulta="SELECT * FROM usuario WHERE Nombre LIKE '$nombre%'";
		try {
			$resultado=$this->conexion->prepare($consulta);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$usuario = new Usuario();
				$usuario->__SET('Usuario',$dato->Usuario);
				$usuario->__SET('Clave',$dato->Clave);
				$usuario->__SET('Tipo_Usuario',$dato->Tipo_Usuario);
				$usuario->__SET('Nombre',$dato->Nombre);
				$usuario->__SET('Apellido',$dato->Apellido);
				$usuario->__SET('Correo',$dato->Correo);
				$datos[]=$usuario;
			}
			return $datos;
		} catch (Exception $exception) {
			die($exception->getMessage());
		}
	}

	public function Actualizar(Usuario $usuario){
		$actualizar="UPDATE usuario SET Clave=?,Tipo_Usuario=?,Nombre=?,Apellido=?,Correo=? where Usuario=?";
	    try {
		    	$this->conexion->prepare($actualizar)->execute(array(
                    $usuario->__GET('Clave'),
                    $usuario->__GET('Tipo_Usuario'),
                    $usuario->__GET('Nombre'),
                    $usuario->__GET('Apellido'),
                    $usuario->__GET('Correo'),
                    $usuario->__GET('Usuario'),
                 ));
			    return true;
		    } catch (Exception $exception) {
			    echo "Error al actualizar datos ".$exception->getMessage();
		    }
	}
}
?>