<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title>Pagina Principal</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
	<div class="container">
	<h1>Ingresa o Registrate</h1>

	<a href="inicio.php">Registrate</a>
	<a href="inicioSesion.php">Login</a>
</body>
</html>