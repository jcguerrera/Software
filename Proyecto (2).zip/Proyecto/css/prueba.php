<!DOCTYPE html>
<html>
<head>
	<title>Prueba</title>
</head>
<body>
<p>esto es una prueba</p>
</body>
</html>