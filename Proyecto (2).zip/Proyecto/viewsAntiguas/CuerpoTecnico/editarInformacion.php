<?php 
if (!isset($_SESSION['usuario'])) {
    session_start();
}   
if (isset($_SESSION['usuario'])) {
    require_once 'editarInformacion.php';
} else {
    header('Location: ../../login/login.php');
}
?>
<?php 
require_once '../../controller/equipos_controller.php';
require_once '../../controller/Cuerpos_Tecnicos_controller.php';
require_once '../../model/model_Equipos.php';
require_once '../../model/model_Cuerpo_Tecnico.php';
include 'headerCuerpoTecnico.php';

$control = new Cuerpo_Tecnico_Controller();
$controlEquipos = new equipos_controller();
$cuerpoTecnico = new Cuerpo_Tecnico();
$identificacion = $_GET['id'];
//$identificacion = $_GET['id'];

?>
<!DOCTYPE html>
<html>
<head>
    <title>Update Cuerpo tecnico</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="../../css/materialize.css"/>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../../css/materialize.min.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript" src="../../js/materialize.min.js"></script>
    <script src="../../js/sweetalert2.min.js"></script>
    <script src="../../js/sweetalert2.js"></script>
    <link rel="stylesheet" href="../../css/sweetalert2.min.css">
    <link rel="stylesheet" href="../../css/sweetalert2.css">
    <script src="../../js/materialize.js"></script>
    <script src="../../js/materialize.min.js"></script>
    <script scr="funciones.js"></script>
    <script src="validar.js"></script>
</head>

<body>
<div class="row" style="width: 500px">
    <form class="col s12" action="#" method="POST">
        <div class="row" style="margin-top: 20px;">
            <?php 
                foreach ($control->buscar($identificacion) as $cuerpoTecnico):
            ?>
                    <div class="input-field col s12" id="idCuerpo_Tecnico">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="number" disabled class="validate" name="idCuerpo_Tecnico" value="<?php echo $cuerpoTecnico->__GET('idCuerpo_Tecnico');?>">
                        <label for="icon_prefix">Id Cuerpo Tecnico</label>
                    </div>
                    <div class="input-field col s12" id="Nombre_CT">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="text" class="validate" name="Nombre_CT" value="<?php echo $cuerpoTecnico->__GET('Nombre_CT');?>">
                        <label for="icon_prefix">Nombre integrante cuerpo tecnico</label>
                    </div>
                    <div class="input-field col s12" id="Cargo">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="text" class="validate" name="Cargo" value="<?php echo $cuerpoTecnico->__GET('Cargo');?>">
                        <label for="icon_prefix">Cargo</label>
                    </div>
                    <div class="input-field col s12">
                        <label style="margin-top: -40px; margin-left: 45px; font-size: 12px" id="Equipo_idEquipo">Selecciona un equipo</label>
                        <select name="Equipo_idEquipoSelect" id="Equipo_idEquipoSelect" required style="padding: 15px; margin-top: 15px; margin-left: 5%; height: 100%; display: block;">
                            <?php 
                            foreach ($controlEquipos->buscar($cuerpoTecnico->__GET('Equipo_idEquipo')) as $equipo):
                            ?>
                            <option selected value="<?php echo $equipo->__GET('idEquipo'); ?>">
                            <?php 
                                echo $equipo->__GET('Nombre_Equipo'); 
                            ?>
                            </option>
                            <?php 
                            endforeach; 
                            ?>

                            <?php 
                            foreach ($controlEquipos->listarDiferente($cuerpoTecnico->__GET('Equipo_idEquipo')) as $equipo):
                            ?>
                            <option value="<?php echo $equipo->__GET('idEquipo'); ?>">
                            <?php 
                                echo $equipo->__GET('Nombre_Equipo'); 
                            ?>
                            </option>
                            <?php 
                            endforeach; 
                            ?>
                        </select>
                    </div>

            <?php 
                endforeach; 
            ?>
        </div>
        <input type="submit" value="GUARDAR" id="btn_formulario" name="enviar" style="margin-top:3%">
    </form>
     <?php 
    if (isset($_POST['enviar'])) {
        $cuerpoTecnico->__SET('idCuerpo_Tecnico',$identificacion);
        $cuerpoTecnico->__SET('Nombre_CT',$_POST['Nombre_CT']);
        $cuerpoTecnico->__SET('Cargo',$_POST['Cargo']);
        $cuerpoTecnico->__SET('Equipo_idEquipo',$_POST['Equipo_idEquipoSelect']);
        if(($control->actualizar($cuerpoTecnico)) != true){
            ?>
            <script language="JavaScript" type="text/javascript">
                alert("Error al ingresar los datos");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
        }else{
            ?>
            <script language="JavaScript" type="text/javascript">
                alert("Datos modificados modificado exitosamente");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
        }
    } 
?>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>
