<?php 
if (!isset($_SESSION['usuario'])) {
    session_start();
}   
if (isset($_SESSION['usuario'])) {
    require_once 'registro.php';
} else {
    header('Location: ../../login/login.php');
}
?>
<?php 
    require_once '../../controller/Cuerpos_Tecnicos_controller.php';
    require_once '../../model/model_Cuerpo_Tecnico.php';

    $cuerpoTecnico = new Cuerpo_Tecnico();
    $control = new Cuerpo_Tecnico_Controller();
    $cuerpoTecnico->__SET('Nombre_CT',$_POST['Nombre_CT']);
    $cuerpoTecnico->__SET('Cargo',$_POST['Cargo']);
    $cuerpoTecnico->__SET('Equipo_idEquipo',$_POST['Equipo_idEquipoSelect']);
    if($control->Insertar($cuerpoTecnico) != true){
      ?>
            <script language="JavaScript" type="text/javascript">
                alert("Error al ingresar los datos del cuerpoTecnico");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
    }else{
      ?>
            <script language="JavaScript" type="text/javascript">
                alert("Cuerpo Tecnico ingresado correctamente");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
    }
    //$nombre = $_POST['nombre'];

?>

