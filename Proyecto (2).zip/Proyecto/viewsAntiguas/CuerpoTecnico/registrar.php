<?php 
if (!isset($_SESSION['usuario'])) {
    session_start();
}   
if (isset($_SESSION['usuario'])) {
    require_once 'registrar.php';
} else {
    header('Location: ../../login/login.php');
}
?>
<?php 
    require_once '../../model/model_Equipos.php';
    require_once '../../controller/equipos_controller.php';
    require_once 'headerCuerpoTecnico.php';

    $controlEquipo = new Equipos_controller();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registrar</title>
    <!--<script src="https://code.jquery.com/jquery-3.4.0.js" integrity="sha256-DYZMCC8HTC+QDr5QNaIcfR7VSPtcISykd+6eSmBW5qo=" crossorigin="anonymous"></script>-->
</head>
<body>
<div class="row" style="width: 500px">
<form class="col s12" method="POST" action="registro.php">
  <div class="row">
      <div class="input-field col s12" id="Nombre_CT">
        <i class="material-icons prefix">account_circle</i>
        <input id="icon_prefix nombre" type="text" class="validate" name="Nombre_CT" required>
        <label for="icon_prefix">Nombre integrante Cuerpo Tecnico</label>
      </div>
      <div class="input-field col s12" id="Cargo" style="display: none;">
        <i class="material-icons prefix">account_circle</i>
        <input id="icon_prefix nombre" type="text" class="validate" name="Cargo" required>
        <label for="icon_prefix">Cargo</label>
      </div>
      <!--<div class="input-field col s12">
        <label style="display: none; margin-top: -40px; margin-left: 45px; font-size: 12px" id="CargoIII">Selecciona un Cargo</label>
        <select name="CargoII" id="CargoII" required style="display: none; padding: 15px; width: 106.5%; margin-top: 15px; margin-left: 5%; width: 100%; height: 100%">
          <option value="" disabled selected>Seleccione un Cargo</option>
          <option>DEF</option>
          <option>DEL</option>
          <option>POR</option>
          <option>MED</option>
        </select>
      </div>-->
      <div class="input-field col s12">
        <label style="display: none; margin-top: -40px; margin-left: 45px; font-size: 12px" id="Equipo_idEquipo">Selecciona un Equipo</label>
        <select name="Equipo_idEquipoSelect" id="Equipo_idEquipoSelect" required style="padding: 15px; width: 106.5%; margin-top: 15px; margin-left: 5%; width: 100%; height: 100%">
          <option value="" disabled selected>Seleccione un Equipo</option>
            <?php 
            foreach ($controlEquipo->listar() as $equipo):
            ?>
              <option value="<?php echo $equipo->__GET('idEquipo'); ?>">
              <?php 
                echo $equipo->__GET('Nombre_Equipo'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
        </select>
      </div>

  </div>
  <script>
        document.getElementById("Nombre_CT").onclick = function() {ShowCargo()};
        document.getElementById("Cargo").onclick = function() {ShowEquipo()};

        function ShowCargo() {
            document.getElementById("Cargo").style.display = "block";
        }
        function ShowEquipo() {
            document.getElementById("Equipo_idEquipo").style.display = "block";
            document.getElementById("Equipo_idEquipoSelect").style.display = "block";
        }
        </script>
  <input type="submit" name="Enviar">
</form>
</div>
</body>
</html>
