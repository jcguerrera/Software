<?php 
if (!isset($_SESSION['usuario'])) {
    session_start();
}   
if (isset($_SESSION['usuario'])) {
    require_once 'listarCuerposTecnicos.php';
} else {
    header('Location: ../../login/login.php');
}
?>
<?php 

require_once '../../controller/Cuerpos_Tecnicos_controller.php';
require_once '../../model/model_Cuerpo_Tecnico.php';
require_once '../../model/model_Equipos.php';
require_once '../../controller/equipos_controller.php';
require_once 'headerCuerpoTecnico.php';

$control = new Cuerpo_Tecnico_Controller();
$controlEquipo = new Equipos_controller();

?>
<!DOCTYPE html>
<html>
<head>
    <title>Cuerpos Tecnicos de la liga de la liga</title>

</head>
<body>
<div style="width: 500px; margin-left: 30%">
    <form method="POST">
        <p style="font-size: 18px; font-family:  cursive;">Equipo para ver Cuerpo Tecnico</p>
      <div class="input-field col s12">
        <div class="input-field col s12 m5 l5">
          <select name="Equipo_idEquipoLocalSelect" id="Equipo_idEquipoLocalSelect" required style="padding: 15px; width: 106.0%; margin-top: 5%; margin-left: 0%; width: 100%; height: 100%; display: block;">
            <option value="" disabled selected>Seleccione un Equipo</option>
            <?php 
            foreach ($controlEquipo->listar() as $equipo):
            ?>
              <option value="<?php echo $equipo->__GET('idEquipo'); ?>">
              <?php 
                echo $equipo->__GET('Nombre_Equipo'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
          </select>
        </div>
        <div class="input-field col s12 m3 l3">
          <input type="submit" name="enviar" value="Buscar" style="padding: 15px; width: 106.0%; margin-top: 15px; margin-left: 0%; width: 100%; height: 100%; display: block;">
        </div>
    </div>
</form>
<?php 
    if (isset($_POST['enviar'])) {
        $idEquipo = $_POST['Equipo_idEquipoLocalSelect'];
        //echo "perra ".$idEquipo;
        if (is_array($control->listarTecnicosEquipo($idEquipo)) || is_object($$control->listarTecnicosEquipo($idEquipo))){
            ?>
        <table class="centered" style="font-family: cursive; border-collapse: separate; border-spacing: 5px 10px;">
        <thead style="font-size: 10px; text-transform: uppercase;">
            <tr>

                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Nombre</th>
                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Cargo</th>
                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Equipo</th>
                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Editar</th>

            </tr>
        </thead>


        <tbody>
            <tr>
                <?php 
                    foreach ($control->listarTecnicosEquipo($idEquipo) as $tecnico):
                ?>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $tecnico->__GET('Nombre_CT'); 
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $tecnico->__GET('Cargo'); 
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $tecnico->__GET('Equipo_idEquipo');
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                <a href="editarInformacion.php?id=<?php echo $tecnico->idCuerpo_Tecnico; ?>">Editar </a>
                     <!--<a href="editar.php?id=<?php// echo $r->nombre; ?>"><i class="small material-icons" style="color: black">mode_edit</i></a>-->
                </td>
        </tbody>
        <?php 
            endforeach; 
        ?>
    </table>
            <?php
        }
    } 
?>
</div>
<div>
    
    <!--<a href="registrar.php"><input type="submit" value="Registrar" id="btn_re"></a>-->
</div>
<!--<a href="../../index.php" title="Ir la página anterior">Volver al menu inicial</a>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>

</html>
