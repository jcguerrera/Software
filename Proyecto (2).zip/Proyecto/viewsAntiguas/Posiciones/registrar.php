<?php 
    require_once '../../model/model_Equipos.php';
    require_once '../../model/model_Torneo.php';
    require_once '../../controller/equipos_controller.php';
    require_once '../../controller/Torneo_controller.php';
    require_once 'headerPosiciones.php';
    //include 'headerBorders.php';

    $controlTorneos = new Torneo_Controller();
    $controlEquipo = new Equipos_controller();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registrar</title>
    <!--<script src="https://code.jquery.com/jquery-3.4.0.js" integrity="sha256-DYZMCC8HTC+QDr5QNaIcfR7VSPtcISykd+6eSmBW5qo=" crossorigin="anonymous"></script>-->
</head>
<body>
<div class="row" style="width: 500px">
<form class="col s12" method="POST" action="registro.php">
  <div class="row">
      <div class="input-field col s12 m6 l6" style="margin-top: 5%">
        <label style="margin-left: 45px; font-size: 15px; display: block; margin-top: -15%" id="Equipo_idEquipo">Selecciona un Equipo</label>
        <select name="Equipo_idEquipoSelect" id="Equipo_idEquipoSelect" required style="padding: 15px; width: 106.5%; margin-top: 15px; margin-left: 5%; width: 100%; height: 100%; display: block;">
          <option value="" disabled selected>Seleccione un Equipo</option>
            <?php 
            foreach ($controlEquipo->listar() as $equipo):
            ?>
              <option value="<?php echo $equipo->__GET('idEquipo'); ?>">
              <?php 
                echo $equipo->__GET('Nombre_Equipo'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
        </select>
      </div>
      <div class="input-field col s12 m6 l6" style="margin-top: 5%">
        <label style="margin-left: 45px; font-size: 15px; display: block; margin-top: -15%" id="idTorneo">Seleccione un Torneo</label>
        <select name="Torneo_idTorneoSelect" id="Torneo_idTorneoSelect" required style="padding: 15px; width: 106.5%; margin-top: 15px; margin-left: 5%; width: 100%; height: 100%; display: block;">
          <option value="" disabled selected>Seleccione un Torneo</option>
            <?php 
            foreach ($controlTorneos->listar() as $torneo):
            ?>
              <option value="<?php echo $torneo->__GET('idTorneo'); ?>">
              <?php 
                echo $torneo->__GET('Nombre_Torneo'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
        </select>
      </div>
  </div>
  <input type="submit" name="Enviar">
</form>
</div>
</body>
</html>
