<?php 
    require_once '../../controller/Posicion_Controller.php';
    require_once '../../model/model_Posicion.php';
    require_once '../../controller/equipos_controller.php';
    require_once '../../model/model_Equipos.php';

    $controlEquipos = new Equipos_controller();
    $equipo = new Equipos();
    $nombreEquipo = null;
    $idEquipo = $_POST['Equipo_idEquipoSelect'];
    foreach ($controlEquipos->obtenerNombre($idEquipo) as $equipo){
        $nombreEquipo = $equipo->__GET('Nombre_Equipo');
    }
    $posicion = new Posicion();
    $control = new Posicion_Controller();
    $posicion->__SET('IdEquipo',$idEquipo);
    $posicion->__SET('Nombre_Equipo',$nombreEquipo);
    $posicion->__SET('Puntos',0);
    $posicion->__SET('GolesFavor',0);
    $posicion->__SET('GolesContra',0);
    $posicion->__SET('TarjetasAmarillas',0);
    $posicion->__SET('TarjetasRojas',0);
    $posicion->__SET('Torneo_idTorneo',$_POST['Torneo_idTorneoSelect']);
    if($control->Insertar($posicion) != true){
      ?>
            <script language="JavaScript" type="text/javascript">
                alert("El equipo ya se agrego a la tabla de posiciones del Torneo seleccionado");
            </script>
            <meta http-equiv="refresh" content="0; url=registrar.php">
            <?php
    }else{
      ?>
            <script language="JavaScript" type="text/javascript">
                alert("Jugador ingresado correctamente");
            </script>
            <meta http-equiv="refresh" content="0; url=registrar.php">
            <?php
    }
    //$nombre = $_POST['nombre'];

?>

