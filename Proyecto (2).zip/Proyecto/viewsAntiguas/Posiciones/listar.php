<?php 

require_once '../../controller/Posicion_controller.php';
require_once '../../controller/Torneo_controller.php';
require_once '../../model/model_Posicion.php';
require_once '../../model/conexion.php';
require_once '../../model/model_Torneo.php';
require_once 'headerPosiciones.php';

$control = new Posicion_Controller();
$controlTorneos = new Torneo_Controller();

?>
<!DOCTYPE html>
<html>
<head>
    <title>Tabla de posiciones</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
<div style="width: 500px; margin-left: 30%; display:block;" id="contenedor">
<form method="POST">
        <p style="font-size: 18px; font-family:  cursive;">Torneo para ver tabla de posiciones</p>
      <div class="input-field col s12">
        <div class="input-field col s12 m5 l5">
          <select name="Torneo_idTorneoSelect" id="Torneo_idTorneoSelect" required style="padding: 15px; width: 106.0%; margin-top: 5%; margin-left: 0%; width: 100%; height: 100%; display: block;">
            <option value="" disabled selected>Seleccione un Torneo</option>
            <?php 
            foreach ($controlTorneos->listar() as $torneo):
            ?>
              <option value="<?php echo $torneo->__GET('idTorneo'); ?>">
              <?php 
                echo $torneo->__GET('Nombre_Torneo'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
          </select>
        </div>
        <div class="input-field col s12 m3 l3">
          <input type="submit" name="enviar" value="Buscar" style="padding: 15px; width: 106.0%; margin-top: 15px; margin-left: 0%; width: 100%; height: 100%; display: block;">
        </div>
    </div>
</form>
</div>
<?php 
    if (isset($_POST['enviar'])) {
        $idTorneo = $_POST['Torneo_idTorneoSelect'];
        if (is_array($control->listar($idTorneo)) || is_object($$control->listar($idTorneo))){
            $nombreTorneo = null;
            $idTorneo = $_POST['Torneo_idTorneoSelect'];
            foreach ($controlTorneos->getName($idTorneo) as $torneo){
                $nombreTorneo = $torneo->__GET('Nombre_Torneo');
            }
            ?>
                <p style="font-size: 20px; font-family: cursive; margin-left: 3%">Tabla de posiciones <?php echo $nombreTorneo; ?></p>
                <table class="centered" style="font-family: cursive; border-collapse: separate; border-spacing: 5px 10px;">
                    <thead style="font-size: 10px; text-transform: uppercase;">
                        <tr>
                            <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px">Id Equipo</th>
                            <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px">Equipo</th>
                            <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px">Puntos</th>
                            <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px">Goles a Favor</th>
                            <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px">Goles en Contra</th>
                            <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px">Tarjetas Amarillas</th>
                            <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px">Tarjetas Rojas</th>
                        </tr>
                    </thead>

            <tbody>
            <tr>
                <?php
                if (is_array($control->listar($idTorneo)) || is_object($control->listar($idTorneo))){
                    foreach ($control->listar($idTorneo) as $posicion){
                ?>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $posicion->__GET('idEquipo'); 
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $posicion->__GET('Nombre_Equipo'); 
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $posicion->__GET('Puntos'); 
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $posicion->__GET('GolesFavor');
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $posicion->__GET('GolesContra');
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $posicion->__GET('TarjetasAmarillas');
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $posicion->__GET('TarjetasRojas');
                    ?>
                </td>
            </tr>
        </tbody>
            <?php
            }
        }
    }
}
?>
<!--<a href="../../index.php" title="Ir la página anterior">Volver al menu inicial</a>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>

</html>
