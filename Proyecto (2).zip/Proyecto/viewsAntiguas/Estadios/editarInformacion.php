<?php 
require_once '../../controller/Estadio_controller.php';
require_once '../../model/model_Estadio.php';

$control = new Estadio_Controller();
$estadio = new Estadio();
$identificacion = $_GET['id'];
//$identificacion = $_GET['id'];

?>
<!DOCTYPE html>
<html>
<head>
    <title>Modificar Estadio</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">


    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="../../css/materialize.css"/>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../../css/materialize.min.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript" src="../../js/materialize.min.js"></script>
    <script src="../../js/sweetalert2.min.js"></script>
    <script src="../../js/sweetalert2.js"></script>
    <link rel="stylesheet" href="../../css/sweetalert2.min.css">
    <link rel="stylesheet" href="../../css/sweetalert2.css">
    <script src="../../js/materialize.js"></script>
    <script src="../../js/materialize.min.js"></script>
    <script scr="funciones.js"></script>
    <script src="validar.js"></script>
</head>

<body>
<div class="row" style="width: 90%">
    <form class="col s12" action="#" method="POST">
        <div class="row" style="margin-top: 20px;">
            <?php 
                foreach ($control->buscar($identificacion) as $estadio):
            ?>
                    <div class="input-field col s12">
                        <i class="material-icons prefix">search</i>
                        <label>Id Estadio</label>
                        <input id="icon_prefix" disabled type="number" class="validate" name="id" value="<?php echo $estadio->__GET('idEstadio');?>"/>
                    </div>
                    <div class="input-field col s12">
                        <i class="material-icons prefix">search</i>
                        <label>Nombre Estadio</label>
                        <input id="icon_prefix" type="text" class="validate" name="Nombre_Estadio" value="<?php echo $estadio->__GET('Nombre_Estadio');?>"/>
                    </div>
                    <div class="input-field col s12">
                        <i class="material-icons prefix">search</i>
                        <label>Capacidad</label>
                        <input id="icon_prefix" type="number" class="validate" name="Capacidad" value="<?php echo $estadio->__GET('Capacidad');?>"/>
                    </div>
            <?php 
                endforeach; 
            ?>
        </div>
        <input type="submit" value="GUARDAR" id="btn_formulario" name="enviar" style="margin-top:3%">
    </form>
 <?php 
    if (isset($_POST['enviar'])) {
        $estadio->__SET('idEquipo',$identificacion);
        $estadio->__SET('Nombre_Estadio',$_POST['Nombre_Estadio']);
        $estadio->__SET('Capacidad',$_POST['Capacidad']);
        if(($control->actualizar($estadio)) != true){
            ?>
            <script language="JavaScript" type="text/javascript">
                alert("Error al modificar datos");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
        }else{
            ?>
            <script language="JavaScript" type="text/javascript">
                alert("Datos modificados modificado exitosamente");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
        }
    } 
?>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>
