<?php 
    require_once '../../controller/Estadio_controller.php';
    require_once '../../model/model_Estadio.php';
    //include 'headerBorders.php';

    $estadio = new Estadio();
    $control = new Estadio_Controller();
    //$border = new Borders();
    //$control = new Borders_Controller();
    $estadio->__SET('Nombre_Estadio',$_POST['Nombre_Estadio']);
    $estadio->__SET('Capacidad',$_POST['Capacidad']);

    if($control->Insertar($estadio) != true){
        ?>
            <script language="JavaScript" type="text/javascript">
                alert("Error al registrar un estadio");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
    }else{
      ?>
            <script language="JavaScript" type="text/javascript">
                alert("Estadio registrado correctamente");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
    }
    //$nombre = $_POST['nombre'];

?>

