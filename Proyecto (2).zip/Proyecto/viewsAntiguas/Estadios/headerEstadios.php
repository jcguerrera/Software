<!DOCTYPE html>
<html>
<head>
	<title>Header Estadios</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">


  <meta charset="UTF-8">
  <link type="text/css" rel="stylesheet" href="../../css/materialize.css"/>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
  <link rel="stylesheet" type="text/css" href="../../css/materialize.min.css">
  <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script type="text/javascript" src="../../js/materialize.min.js"></script>
  <script src="../../js/sweetalert2.min.js"></script>
  <script src="../../js/sweetalert2.js"></script>
  <link rel="stylesheet" href="../../css/sweetalert2.min.css">
  <link rel="stylesheet" href="../../css/sweetalert2.css">
  <script src="../../js/materialize.js"></script>
  <script src="../../js/materialize.min.js"></script>
  <script scr="funciones.js"></script>
  <script src="validar.js"></script>

</head>
<body>
    <nav>
    <div class="nav-wrapper blue">
      <a class="brand-logo" style="border-right: 15px; padding: 0px 15px;">Menú Estadios</a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="registrar.php"><i class="material-icons left">vpn_lock</i>Agregar Estadio</a></li>
        <li><a href="listar.php"><i class="material-icons left">vpn_lock</i>Ver Estadios</a></li>
        <li><a href="../../login/cerrar.php"><i class="material-icons left">public</i>Cerrar Sesion</a></li>
        <!--<li><a href="listarJugadores.php"><i class="material-icons left">vpn_lock</i>Ver Jugadores por equipo</a></li>-->
      </ul>
    </div>
  </nav>

<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>