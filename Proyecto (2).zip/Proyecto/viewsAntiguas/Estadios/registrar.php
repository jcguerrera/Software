<?php
	require_once 'headerEstadios.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registrar Estadio</title>
</head>
<body>
<div class="row" style="width: 500px">
<form class="col s12" method="POST" action="registro.php">
  <div class="row">
      <div class="input-field col s12" id="Nombre_Estadio">
        <i class="material-icons prefix">account_circle</i>
        <input id="icon_prefix nombre" type="text" class="validate" name="Nombre_Estadio" required>
        <label for="icon_prefix">Nombre Estadio</label>
      </div>
      <div class="input-field col s12" id="Capacidad" style="display: none;">
        <i class="material-icons prefix">account_circle</i>
        <input id="icon_prefix nombre" type="number" class="validate" name="Capacidad" required>
        <label for="icon_prefix">Capacidad</label>
      </div>
  </div>
  <script>
        document.getElementById("Nombre_Estadio").onclick = function() {ShowFecha()};

        function ShowFecha() {
            document.getElementById("Capacidad").style.display = "block";
        }


 </script>
  <input type="submit" name="Enviar">
</form>
</div>
</body>
</html>
