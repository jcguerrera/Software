<?php 
if (!isset($_SESSION['usuario'])) {
    session_start();
}   
if (isset($_SESSION['usuario'])) {
    require_once 'registro.php';
} else {
    header('Location: ../../login/login.php');
}
?>
<?php 
    require_once '../../controller/equipos_controller.php';
    require_once '../../model/model_Equipos.php';
    require_once 'headerEquipos.php';

    $equipo = new Equipos();
    $control = new Equipos_controller();
    //$border = new Borders();
    //$control = new Borders_Controller();
    $Nombre_Equipo = $_POST['Nombre_Equipo'];
    $Fundacion_Equipo = $_POST['Fundacion_Equipo'];
    $Escudo = $_FILES['Escudo']['tmp_name'];
    $destino = "Escudos/".$Nombre_Equipo.".png";
    copy($Escudo,$destino);

    $equipo->__SET('Nombre_Equipo',$Nombre_Equipo);
    $equipo->__SET('Fundacion_Equipo',$Fundacion_Equipo);
    $equipo->__SET('Escudo',$destino);

    if($control->Insertar($equipo) != true){
        ?>
            <script language="JavaScript" type="text/javascript">
                alert("Error al registrar un equipo");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
    }else{
      ?>
            <script language="JavaScript" type="text/javascript">
                alert("Equipo registrado correctamente");
            </script>
            <!--<meta http-equiv="refresh" content="0; url=listar.php">-->
            <?php
    }
    //$nombre = $_POST['nombre'];

?>

