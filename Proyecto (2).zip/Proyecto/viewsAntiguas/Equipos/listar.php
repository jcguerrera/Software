<?php 
if (!isset($_SESSION['usuario'])) {
    session_start();
}   
if (isset($_SESSION['usuario'])) {
    require_once 'listar.php';
} else {
    header('Location: ../../login/login.php');
}
?>
<?php 

require_once '../../controller/equipos_controller.php';
require_once '../../model/model_Equipos.php';
require_once '../../model/conexion.php';
require_once 'headerEquipos.php';

$control = new Equipos_Controller();

?>
<!DOCTYPE html>
<html>
<head>
    <title>Listar Equipos Liga</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
<div style="margin-top: 2%">
    <table class="centered" style="font-family: cursive; border-collapse: separate; border-spacing: 5px 10px;">
        <thead style="font-size: 10px; text-transform: uppercase;">
            <tr>

                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Nombre</th>
                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Fecha de fundacion</th>
                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Escudo</th>
                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Editar</th>

            </tr>
        </thead>


        <tbody>
            <tr>
                <?php 
                    foreach ($control->listar() as $equipo):
                ?>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 10px; font-size: 15px">
                    <?php 
                        echo $equipo->__GET('Nombre_Equipo'); 
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 10px; font-size: 15px">
                    <?php 
                        echo $equipo->__GET('Fundacion_Equipo'); 
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 10px;">
                    <img style="width: 80px; height: 80px" src="Escudos/<?php echo $equipo->__GET('Nombre_Equipo').".png";?>">
                    <!--<img src="data:image/png;base64,<?php //echo base64_encode($equipo->__GET('Escudo'));?>"/>-->
                </td>
                
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 10px; font-size: 15px">
                <a href="editarInformacion.php?id=<?php echo $equipo->idEquipo; ?>">Editar </a>
                </td>
        </tbody>
        <?php 
            endforeach; 
        ?>
    </table>
    <!--<a href="registrar.php"><input type="submit" value="Registrar" id="btn_re"></a>-->
</div>
<!--<a href="../../index.php" title="Ir la página anterior">Volver al menu inicial</a>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>

</html>
