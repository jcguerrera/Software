<?php 
if (!isset($_SESSION['usuario'])) {
    session_start();
}   
if (isset($_SESSION['usuario'])) {
    require_once 'registrar.php';
} else {
    header('Location: ../../login/login.php');
}
?>
<?php
	require_once 'headerEquipos.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registrar</title>
    <!--<script src="https://code.jquery.com/jquery-3.4.0.js" integrity="sha256-DYZMCC8HTC+QDr5QNaIcfR7VSPtcISykd+6eSmBW5qo=" crossorigin="anonymous"></script>-->
</head>
<body>
<div class="row" style="width: 500px">
<form class="col s12" method="POST" action="registro.php" enctype="multipart/form-data">
  <div class="row">
      <div class="input-field col s12" id="Nombre_Equipo">
        <i class="material-icons prefix">account_circle</i>
        <input id="icon_prefix nombre" type="text" class="validate" name="Nombre_Equipo" required>
        <label for="icon_prefix">Nombre Equipo</label>
      </div>
      <div class="input-field col s12" id="Fundacion_Equipo" style="display: none;">
        <i class="material-icons prefix">account_circle</i>
        <input type="date" id="Fundacion_Equipo" name="Fundacion_Equipo" required>
        <label for="icon_prefix">Fundacion Equipo</label>
      </div>
      <div style="height: 200px;"></div>
      <!--<br><br><br><br><br><br><br>-->
      
      <div class="file-field input-field" id="Escudo" style="display: none; margin-top: 5%;">
        <div class="btn light-blue" style="width: 200px; margin-left: 15%">
          <span>Añadir Escudo Equipo</span>
          <input type="file" name="Escudo" id="file" required>
        </div>
        <div class="file-path-wrapper" style="width: 200px">
          <input class="file-path validate" type="text">
        </div>
      </div>
  </div>
  <script>
        document.getElementById("Nombre_Equipo").onclick = function() {ShowFecha()};
        document.getElementById("Fundacion_Equipo").onclick = function() {ShowEscudo()};

        function ShowFecha() {
            document.getElementById("Fundacion_Equipo").style.display = "block";
        }
        function ShowEscudo() {
            document.getElementById("Escudo").style.display = "block";
        }


 </script>
  <input type="submit" name="Enviar">
</form>
</div>
</body>
</html>
