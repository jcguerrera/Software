<?php 
if (!isset($_SESSION['usuario'])) {
    session_start();
}   
if (isset($_SESSION['usuario'])) {
    require_once 'editarInformacion.php';
} else {
    header('Location: ../../login/login.php');
}
?>
<?php 
require_once '../../controller/equipos_controller.php';
require_once '../../model/model_Equipos.php';
require_once 'headerEquipos.php';

$control = new Equipos_controller();
$equipo = new Equipos();
$identificacion = $_GET['id'];
//$identificacion = $_GET['id'];

?>
<!DOCTYPE html>
<html>
<head>
    <title>Update Country</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">


    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="../../css/materialize.css"/>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../../css/materialize.min.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript" src="../../js/materialize.min.js"></script>
    <script src="../../js/sweetalert2.min.js"></script>
    <script src="../../js/sweetalert2.js"></script>
    <link rel="stylesheet" href="../../css/sweetalert2.min.css">
    <link rel="stylesheet" href="../../css/sweetalert2.css">
    <script src="../../js/materialize.js"></script>
    <script src="../../js/materialize.min.js"></script>
    <script scr="funciones.js"></script>
    <script src="validar.js"></script>
</head>

<body>
<div class="row" style="width: 90%">
    <form class="col s12" method="POST" action="actualizar.php" enctype="multipart/form-data">
        <div class="row" style="margin-top: 20px;">
            <?php 
                foreach ($control->buscar($identificacion) as $equipo):
            ?>
                    <div class="input-field col s12">
                        <i class="material-icons prefix">search</i>
                        <label>Id Equipo</label>
                        <input id="icon_prefix" disabled type="number" class="validate" name="id" value="<?php echo $equipo->__GET('idEquipo');?>"/>
                    </div>
                    <div class="input-field col s12">
                        <i class="material-icons prefix">search</i>
                        <label>Nombre</label>
                        <input id="icon_prefix" type="text" class="validate" name="Nombre_Equipo" value="<?php echo $equipo->__GET('Nombre_Equipo');?>"/>
                    </div>
                    <div class="input-field col s12">
                        <i class="material-icons prefix">search</i>
                        <label>Fecha de fundacion</label>
                        <input id="icon_prefix" type="date" class="validate" name="Fundacion_Equipo" value="<?php echo $equipo->__GET('Fundacion_Equipo');?>"/>
                    </div>
                    <div style="height: 200px;"></div>
                    <div class="file-field input-field" id="Escudo" style=" margin-top: 7%;">
                        <div class="btn light-blue" style="width: 200px; margin-left: 15%">
                            <span>Añadir Escudo Equipo</span>
                            <input type="file" name="Escudo" id="file" required>
                        </div>
                        <div class="file-path-wrapper" style="width: 200px">
                            <input class="file-path validate" type="text">
                        </div>
                    </div>
            <?php 
                endforeach; 
            ?>
        </div>
        <input type="submit" value="GUARDAR" id="btn_formulario" name="enviar" style="margin-top:3%">
    </form>

</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>
