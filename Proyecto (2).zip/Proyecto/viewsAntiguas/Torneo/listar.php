<?php 

require_once '../../controller/Torneo_controller.php';
require_once '../../model/model_Torneo.php';
require_once '../../model/conexion.php';
include 'headerTorneo.php';

$control = new Torneo_Controller();

?>
<!DOCTYPE html>
<html>
<head>
    <title>Listar Estadios</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
<div>
    <table class="centered" style="font-family: cursive; border-collapse: separate; border-spacing: 5px 10px;">
        <thead style="font-size: 10px; text-transform: uppercase;">
            <tr>

                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Nombre Torneo</th>
                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Editar</th>

            </tr>
        </thead>


        <tbody>
            <tr>
                <?php 
                    foreach ($control->listar() as $torneo):
                ?>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $torneo->__GET('Nombre_Torneo'); 
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                <a href="editarInformacion.php?id=<?php echo $torneo->idTorneo; ?>">Editar </a>
                </td>
        </tbody>
        <?php 
            endforeach; 
        ?>
    </table>
    <!--<a href="registrar.php"><input type="submit" value="Registrar" id="btn_re"></a>-->
</div>
<!--<a href="../../index.php" title="Ir la página anterior">Volver al menu inicial</a>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>

</html>
