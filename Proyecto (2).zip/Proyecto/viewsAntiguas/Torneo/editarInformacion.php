<?php 
require_once '../../controller/Torneo_controller.php';
require_once '../../model/model_Torneo.php';
require_once 'headerTorneo.php';

$control = new Torneo_Controller();
$torneo = new Torneo();
$identificacion = $_GET['id'];
//$identificacion = $_GET['id'];

?>
<!DOCTYPE html>
<html>
<head>
    <title>Modificar Estadio</title>
</head>

<body>
<div class="row" style="width: 90%">
    <form class="col s12" action="#" method="POST">
        <div class="row" style="margin-top: 20px;">
            <?php 
                foreach ($control->buscar($identificacion) as $torneo):
            ?>
                    <div class="input-field col s12">
                        <i class="material-icons prefix">search</i>
                        <label>Id Estadio</label>
                        <input id="icon_prefix" disabled type="number" class="validate" name="id" value="<?php echo $torneo->__GET('idTorneo');?>"/>
                    </div>
                    <div class="input-field col s12">
                        <i class="material-icons prefix">search</i>
                        <label>Nombre Estadio</label>
                        <input id="icon_prefix" type="text" class="validate" name="Nombre_Torneo" value="<?php echo $torneo->__GET('Nombre_Torneo');?>"/>
                    </div>
            <?php 
                endforeach; 
            ?>
        </div>
        <input type="submit" value="GUARDAR" id="btn_formulario" name="enviar" style="margin-top:3%">
    </form>
 <?php 
    if (isset($_POST['enviar'])) {
        $torneo->__SET('idEquipo',$identificacion);
        $torneo->__SET('Nombre_Torneo',$_POST['Nombre_Torneo']);
        if(($control->actualizar($torneo)) != true){
            ?>
            <script language="JavaScript" type="text/javascript">
                alert("Error al modificar datos");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
        }else{
            ?>
            <script language="JavaScript" type="text/javascript">
                alert("Datos modificados modificado exitosamente");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
        }
    } 
?>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>
