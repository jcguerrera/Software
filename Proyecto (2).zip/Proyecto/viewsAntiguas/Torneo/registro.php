<?php 
    require_once '../../controller/Torneo_controller.php';
    require_once '../../model/model_Torneo.php';
    //include 'headerBorders.php';

    $torneo = new Torneo();
    $control = new Torneo_Controller();
    //$border = new Borders();
    //$control = new Borders_Controller();
    $torneo->__SET('Nombre_Torneo',$_POST['Nombre_Torneo']);
    if($control->Insertar($torneo) != true){
        ?>
            <script language="JavaScript" type="text/javascript">
                alert("Error al registrar un torneo");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
    }else{
      ?>
            <script language="JavaScript" type="text/javascript">
                alert("Torneo registrado correctamente");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
    }
    //$nombre = $_POST['nombre'];

?>

