<?php
	require_once 'headerTorneo.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registrar Estadio</title>
</head>
<body>
<div class="row" style="width: 500px">
<form class="col s12" method="POST" action="registro.php">
  <div class="row">
      <div class="input-field col s12" id="Nombre_Torneo">
        <i class="material-icons prefix">account_circle</i>
        <input id="icon_prefix nombre" type="text" class="validate" name="Nombre_Torneo" required>
        <label for="icon_prefix">Nombre Torneo</label>
      </div>
  </div>
  <input type="submit" name="Enviar">
</form>
</div>
</body>
</html>
