<?php 
if (!isset($_SESSION['usuario'])) {
    session_start();
}   
if (isset($_SESSION['usuario'])) {
    require_once 'listar.php';
} else {
    header('Location: ../../login/login.php');
}
?>
<?php 

require_once '../../controller/Encuentro_controller.php';
require_once '../../controller/Equipos_controller.php';
require_once '../../model/model_Encuentro.php';
require_once '../../model/model_Equipos.php';
require_once '../../model/conexion.php';
require_once 'headerEncuentro.php';

$control = new Encuentro_Controller();
$controlEquipos = new Equipos_controller();

?>
<!DOCTYPE html>
<html>
<head>
    <title>Jugadores de la liga</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
<div>
    <table class="centered" style="font-family: cursive; border-collapse: separate; border-spacing: 5px 10px;">
        <thead style="font-size: 10px; text-transform: uppercase;">
            <tr>

                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Equipo Local</th>
                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Equipo Visitante</th>
                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Estado Encuentro</th>
                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Fecha</th>
                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Actualizar</th>

            </tr>
        </thead>


        <tbody>
            <tr>
                <?php 
                    foreach ($control->listar() as $encuentro):
                ?>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php
                        $idEquipoLocal = $encuentro->__GET('Equipo_idEquipoLocal');
                        foreach($controlEquipos->buscar($idEquipoLocal) as $equipo):
                            echo $equipo->__GET('Nombre_Equipo');
                        endforeach;
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php
                        $idEquipoLocal = $encuentro->__GET('Equipo_idEquipoVisitante');
                        foreach($controlEquipos->buscar($idEquipoLocal) as $equipo):
                            echo $equipo->__GET('Nombre_Equipo');
                        endforeach;
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $encuentro->__GET('Estado_Encuentro'); 
                    ?>
                </td>

                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $encuentro->__GET('Fecha_Encuentro');
                    ?>
                </td>
                <?php
                    if(($encuentro->__GET('Estado_Encuentro') == 'PENDIENTE') || ($encuentro->__GET('Estado_Encuentro') == 'EN JUEGO')){
                        ?>
                            <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                                <a href="editarInformacion.php?id=<?php echo $encuentro->idEncuentro; ?>">Editar </a>
                            </td>
                        <?php
                    }else{
                        ?>
                        <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                                <a>No se puede modificar</a>
                        </td>
                        <?php
                    }
                ?>
        </tbody>
        <?php 
            endforeach; 
        ?>
    </table>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>

</html>
