<?php 
if (!isset($_SESSION['usuario'])) {
    session_start();
}   
if (isset($_SESSION['usuario'])) {
    require_once 'registro.php';
} else {
    header('Location: ../../login/login.php');
}
?>
<?php 
    require_once '../../controller/Encuentro_controller.php';
    require_once '../../model/model_Encuentro.php';
    //include 'headerBorders.php';

    //echo "Equipo local ".$_POST['Equipo_idEquipoLocalSelect'];
    //echo "Equipo visitante ".$_POST['Equipo_idEquipoVisitanteSelect'];
    $encuentro = new Encuentro();
    $control = new Encuentro_Controller();
    $encuentro->__SET('Estado_Encuentro',$_POST['Estado_Encuentro']);
    $encuentro->__SET('Fecha_Encuentro','2019-06-04');
    $encuentro->__SET('Arbitro_idArbitro',$_POST['Arbitro_idArbitroSelect']);
    $encuentro->__SET('Estadio_idEstadio',$_POST['Estadio_idEstadioSelect']);
    $encuentro->__SET('Equipo_idEquipoLocal',$_POST['Equipo_idEquipoLocalSelect']);
    $encuentro->__SET('Equipo_idEquipoVisitante',$_POST['Equipo_idEquipoVisitanteSelect']);
    $encuentro->__SET('Goles_Equipo_Local',0);
    $encuentro->__SET('Goles_Equipo_Visitante',0);
    $encuentro->__SET('Tarj_Ama_Local',0);
    $encuentro->__SET('Tarj_Ama_Visitante',0);
    $encuentro->__SET('Tarj_Rojas_Local',0);
    $encuentro->__SET('Tarj_Rojas_Visitante',0);
    $encuentro->__SET('Torneo_idTorneo',$_POST['Torneo_idTorneoSelect']);

    if($control->Insertar($encuentro) != true){
      ?>
            <script language="JavaScript" type="text/javascript">
                alert("Error al ingresar los datos del encuentro");
            </script>
            <!--<meta http-equiv="refresh" content="0; url=registrar.php">-->
            <?php
    }else{
      ?>
            <script language="JavaScript" type="text/javascript">
                alert("Encuentro ingresado correctamente");
            </script>
            <!--<meta http-equiv="refresh" content="0; url=listar.php">-->
            <?php
    }
?>

