<?php 
if (!isset($_SESSION['usuario'])) {
    session_start();
}   
if (isset($_SESSION['usuario'])) {
    require_once 'editarInformacion.php';
} else {
    header('Location: ../../login/login.php');
}
?>
<?php 
require_once '../../controller/Encuentro_controller.php';
require_once '../../model/model_Encuentro.php';
include'headerEncuentro.php';

$control = new Encuentro_Controller();
$encuentroMod = new Encuentro();
$identificacion = $_GET['id'];
$idLocal = null;

?>
<!DOCTYPE html>
<html>
<head>
    <title>Update Country</title>
</head>

<body>
<div class="row" style="width: 500px">
    <form class="col s12" action="#" method="POST">
        <div class="row" style="margin-top: 20px;">
            <?php 
                foreach ($control->buscar($identificacion) as $encuentro):
                    $idLocal = $encuentro->__GET('Equipo_idEquipoLocal');
            ?>
                    <div class="input-field col s12" id="idEncuentro">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="number" disabled class="validate" name="idEncuentro" value="<?php echo $encuentro->__GET('idEncuentro');?>">
                        <label for="icon_prefix">Id Encuentro</label>
                    </div>
                    <div class="input-field col s12" id="Estado_Encuentro">
                        <i class="material-icons prefix">account_circle</i>
                        <select name="Estado_EncuentroSelect" id="Estado_EncuentroSelect" required style="padding: 15px; margin-top: 15px; margin-left: 5%; height: 100%; display: block;">Estado
                        <?php
                            if($encuentro->__GET('Estado_Encuentro') == 'PENDIENTE'){
                                ?>
                                <option selected>PENDIENTE</option>
                                <option>EN JUEGO</option>
                                <option>FINALIZADO</option>
                                <?php
                            }else if($encuentro->__GET('Estado_Encuentro') == 'EN JUEGO'){
                                ?>
                                <option selected>EN JUEGO</option>
                                <option>FINALIZADO</option>
                                <?php
                            }else{
                                ?>
                                <option selected>FINALIZADO</option>
                                <?php
                            }
                        ?>
                        </select>
                        
                    </div>
                    <div class="input-field col s12" id="Fecha_Encuentro">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="date" disabled class="validate" name="Fecha_Encuentro" value="<?php echo $encuentro->__GET('Fecha_Encuentro');?>">
                        <label for="icon_prefix">Fecha Encuentro</label>
                    </div>
                    <div class="input-field col s12" id="Arbitro_idArbitro">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="text" disabled class="validate" name="Arbitro_idArbitro" value="<?php echo $encuentro->__GET('Arbitro_idArbitro');?>">
                        <label for="icon_prefix">Arbitro</label>
                    </div>
                    <div class="input-field col s12" id="Estadio_idEstadio">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="text" disabled class="validate" name="Estadio_idEstadio" value="<?php echo $encuentro->__GET('Estadio_idEstadio');?>">
                        <label for="icon_prefix">Estadio</label>
                    </div>
                    <div class="input-field col s12" id="Equipo_idEquipoLocal">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="text" disabled class="validate" name="Equipo_idEquipoLocal" value="<?php echo $encuentro->__GET('Equipo_idEquipoLocal');?>">
                        <label for="icon_prefix">Equipo Local</label>
                    </div>
                    <div class="input-field col s12" id="Equipo_idEquipoVisitante">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="text" disabled class="validate" name="Equipo_idEquipoVisitante" value="<?php echo $encuentro->__GET('Equipo_idEquipoVisitante');?>">
                        <label for="icon_prefix">Equipo Visitante</label>
                    </div>
                    <div class="input-field col s12" id="Goles_Equipo_Local">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="number" class="validate" name="Goles_Equipo_Local" value="<?php echo $encuentro->__GET('Goles_Equipo_Local');?>">
                        <label for="icon_prefix">Goles Equipo Local</label>
                    </div>
                    <div class="input-field col s12" id="Goles_Equipo_Visitante">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="number" class="validate" name="Goles_Equipo_Visitante" value="<?php echo $encuentro->__GET('Goles_Equipo_Visitante');?>">
                        <label for="icon_prefix">Goles Equipo Visitante</label>
                    </div>
                    <div class="input-field col s12" id="Tarj_Ama_Local">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="number" class="validate" name="Tarj_Ama_Local" value="<?php echo $encuentro->__GET('Tarj_Ama_Local');?>">
                        <label for="icon_prefix">Tarjetas Amarillas Equipo Local</label>
                    </div>
                    <div class="input-field col s12" id="Tarj_Ama_Visitante">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="number" class="validate" name="Tarj_Ama_Visitante" value="<?php echo $encuentro->__GET('Tarj_Ama_Visitante');?>">
                        <label for="icon_prefix">Tarjetas Amarillas Equipo Visitante</label>
                    </div>
                    <div class="input-field col s12" id="Tarj_Rojas_Local">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="number" class="validate" name="Tarj_Rojas_Local" value="<?php echo $encuentro->__GET('Tarj_Rojas_Local');?>">
                        <label for="icon_prefix">Tarjetas Rojas Equipo Local</label>
                    </div>
                    <div class="input-field col s12" id="Tarj_Rojas_Visitante">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="number" class="validate" name="Tarj_Rojas_Visitante" value="<?php echo $encuentro->__GET('Tarj_Rojas_Visitante');?>">
                        <label for="icon_prefix">Tarjetas Rojas Equipo Visitante</label>
                    </div>
                    <div class="input-field col s12" id="Torneo_idTorneo">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="number" disabled class="validate" name="Torneo_idTorneo" value="<?php echo $encuentro->__GET('Torneo_idTorneo');?>">
                        <label for="icon_prefix">Id Torneo</label>
                    </div>
            <?php 
                endforeach; 
            ?>
        </div>
        <input type="submit" value="GUARDAR" id="btn_formulario" name="enviar" style="margin-top:3%">
    </form>
     <?php 
    if (isset($_POST['enviar'])) {
        $encuentroMod->__SET('idEncuentro',$identificacion);
        $encuentroMod->__SET('Estado_Encuentro',$_POST['Estado_EncuentroSelect']);
        $encuentroMod->__SET('Fecha_Encuentro',$encuentro->__GET('Fecha_Encuentro'));
        $encuentroMod->__SET('Arbitro_idArbitro',$encuentro->__GET('Arbitro_idArbitro'));
        $encuentroMod->__SET('Estadio_idEstadio',$encuentro->__GET('Estadio_idEstadio'));
        $encuentroMod->__SET('Equipo_idEquipoLocal',$encuentro->__GET('Equipo_idEquipoLocal'));
        $encuentroMod->__SET('Equipo_idEquipoVisitante',$encuentro->__GET('Equipo_idEquipoVisitante'));
        $encuentroMod->__SET('Goles_Equipo_Local',$_POST['Goles_Equipo_Local']);
        $encuentroMod->__SET('Goles_Equipo_Visitante',$_POST['Goles_Equipo_Visitante']);
        $encuentroMod->__SET('Tarj_Ama_Local',$_POST['Tarj_Ama_Local']);
        $encuentroMod->__SET('Tarj_Ama_Visitante',$_POST['Tarj_Ama_Visitante']);
        $encuentroMod->__SET('Tarj_Rojas_Local',$_POST['Tarj_Rojas_Local']);
        $encuentroMod->__SET('Tarj_Rojas_Visitante',$_POST['Tarj_Rojas_Visitante']);
        $encuentroMod->__SET('Torneo_idTorneo',$encuentro->__GET('Torneo_idTorneo'));
        if(($control->actualizar($encuentroMod)) != true){
            ?>
            <script language="JavaScript" type="text/javascript">
                alert("Error al ingresar los datos");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
        }else{
            ?>
            <script language="JavaScript" type="text/javascript">
                alert("Datos modificados modificado exitosamente");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
        }
    } 
?>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>
