
<?php 
    require_once '../../model/model_Estadio.php';
    require_once '../../model/model_Arbitro.php';
    require_once '../../model/model_Equipos.php';
    require_once '../../model/model_Torneo.php';
    require_once '../../controller/equipos_controller.php';
    require_once '../../controller/Arbitro_controller.php';
    require_once '../../controller/Estadio_controller.php';
    require_once '../../controller/Torneo_controller.php';
    require_once 'headerEncuentro.php';
    //include 'headerBorders.php';

    $controlEquipo = new Equipos_controller();
    $controlArbitro = new Arbitro_Controller();
    $controlEstadio = new Estadio_Controller();
    $controlTorneo = new Torneo_Controller();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registrar</title>
    <!--<script src="https://code.jquery.com/jquery-3.4.0.js" integrity="sha256-DYZMCC8HTC+QDr5QNaIcfR7VSPtcISykd+6eSmBW5qo=" crossorigin="anonymous"></script>-->
</head>
<body>
<?php
      ?>
      <div class="row" style="width: 850px; border-radius: 5px; border: solid 1px black; margin-top: 5%">
      <p style="font-size: 20px; font-family: cursive; margin-left: 3%">Configuracion del partido</p>
      <form method="POST" action="registro.php">
      <div class="input-field col s12">
        <div class="input-field col s12 m5 l5">
          <label style="margin-top: -40px; margin-left: 45px; font-size: 15px" id="Equipo_idEquipoLocal">Equipo Local</label>
          <select name="Equipo_idEquipoLocalSelect" id="Equipo_idEquipoLocalSelect" required style="padding: 15px; width: 106.0%; margin-top: 15px; margin-left: 0%; width: 100%; height: 100%; display: block;">
            <option value="" disabled selected>Seleccione un Equipo</option>
            <?php 
            foreach ($controlEquipo->listar() as $equipo):
            ?>
              <option value="<?php echo $equipo->__GET('idEquipo'); ?>">
              <?php 
                echo $equipo->__GET('Nombre_Equipo'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
          </select>
        </div>
        <div class="input-field col s12 m2 l2">
          <p style="margin-left: 40%; padding: 15px">VS</p>
        </div>
        <div class="input-field col s12 m5 l5">
          <label style="margin-top: -40px; margin-left: 45px; font-size: 15px" id="Equipo_idEquipoVisitante">Equipo Visitante</label>
          <select name="Equipo_idEquipoVisitanteSelect" id="Equipo_idEquipoVisitanteSelect" required style="padding: 15px; width: 106.0%; margin-top: 15px; margin-left: 0%; width: 100%; height: 100%; display: block;">
          <option value="" disabled selected>Seleccione un Equipo</option>
            <?php 
            foreach ($controlEquipo->listar() as $equipo):
            ?>
              <option value="<?php echo $equipo->__GET('idEquipo'); ?>">
              <?php 
                echo $equipo->__GET('Nombre_Equipo'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
        </select>          
        </div>
      </div>
      <div class="input-field col s12">
        <div class="input-field col s12 m3 l3">
        <label style="margin-top: -40px; margin-left: 45px; font-size: 15px" id="Equipo_idEquipo">Estado encuentro</label>
          <select name="Estado_Encuentro" id="Estado_Encuentro" required style="padding: 15px; margin-top: 15px; margin-left: 0%; width: 100%; height: 100%; display: block;">
            <option value="" disabled selected>Seleccione Estado</option>
            <option>PENDIENTE</option>
            <option>EN JUEGO</option>
            <option>FINALIZADO</option>
          </select>
        </div>
        <div class="input-field col s12 m3 l3">
          <label style="margin-top: -40px; margin-left: 45px; font-size: 15px" id="Arbitro_idArbitro">Arbitro</label>
          <select name="Arbitro_idArbitroSelect" id="Arbitro_idArbitroSelect" required style="padding: 15px; margin-top: 15px; margin-left: 0%; width: 100%; height: 100%; display: block;">
          <option value="" disabled selected>Seleccione Arbitro</option>
            <?php 
            foreach ($controlArbitro->listar() as $arbitro):
            ?>
              <option value="<?php echo $arbitro->__GET('idArbitro'); ?>">
              <?php 
                echo $arbitro->__GET('Nombre_Arbitro'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
        </select>          
        </div>
        <div class="input-field col s12 m3 l3">
          <label style="margin-top: -40px; margin-left: 45px; font-size: 15px" id="Estadio_idEstadio">Estadio</label>
          <select name="Estadio_idEstadioSelect" id="Estadio_idEstadioSelect" required style="padding: 15px; margin-top: 15px; margin-left: 0%; width: 100%; height: 100%; display: block;">
          <option value="" disabled selected>Seleccione Estadio</option>
            <?php 
            foreach ($controlEstadio->listar() as $estadio):
            ?>
              <option value="<?php echo $estadio->__GET('idEstadio'); ?>">
              <?php 
                echo $estadio->__GET('Nombre_Estadio'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
        </select>          
        </div>
        <div class="input-field col s12 m3 l3">
          <label style="margin-top: -40px; margin-left: 45px; font-size: 15px" id="Torneo_idTorneo">Estadio</label>
          <select name="Torneo_idTorneoSelect" id="Torneo_idTorneoSelect" required style="padding: 15px; margin-top: 15px; margin-left: 0%; width: 100%; height: 100%; display: block;">
          <option value="" disabled selected>Seleccione un Torneo</option>
            <?php 
            foreach ($controlTorneo->listar() as $torneo):
            ?>
              <option value="<?php echo $torneo->__GET('idTorneo'); ?>">
              <?php 
                echo $torneo->__GET('Nombre_Torneo'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
        </select>          
        </div>
        <div class="input-field col s12 m4 l4">
        </div>
        <div class="input-field col s12 m4 l4">
          <input type="submit" name="mostrar" value="Agregar Encuentro" style="padding: 15px; width: 106.0%; margin-top: 15px; margin-left: 0%; width: 100%; height: 100%; display: block;">
        </div>
        <div class="input-field col s12 m4 l4">
        </div>
      </div>
      </form>
      </div>
      <br><br>
      <?php
      //$contador++;
   // }
  //}
?>
</body>
</html>
