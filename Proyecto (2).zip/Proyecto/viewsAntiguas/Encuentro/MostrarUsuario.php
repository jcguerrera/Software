<?php 
require_once '../../controller/Encuentro_controller.php';
require_once '../../controller/Equipos_controller.php';
require_once '../../controller/Arbitro_controller.php';
require_once '../../controller/Estadio_controller.php';
require_once '../../model/model_Encuentro.php';
require_once '../../model/model_Equipos.php';
require_once '../../model/model_Estadio.php';
require_once '../../model/model_Arbitro.php';
require_once '../../model/conexion.php';
//require_once 'headerEncuentro.php';

$controlEncuentros = new Encuentro_Controller();
$controlEquipos = new Equipos_controller();
$controlEstadios = new Estadio_Controller();
$controlArbitros = new Arbitro_Controller();

?>
<!DOCTYPE html>
<html>
<head>
    <title>Jugadores de la liga</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    <div class="row">
        <div class="input-field col s12" style="width: 100%">
        <div class="input-field col s6 m5 l5" style="width: 700px; height: 100%">
            <p style="font-size: 20px; font-family: cursive; margin-left: 3%">Proximos Encuentros</p>
            <?php
                foreach ($controlEncuentros->listarFiltro('FINALIZADO') as $encuentro) {
                    ?>
                        <div class="row" style="height: 80%">
                            <?php
                                $idEquipoLocal = $encuentro->__GET('Equipo_idEquipoLocal');
                                $idEquipoVisitante = $encuentro->__GET('Equipo_idEquipoVisitante');
                                foreach($controlEquipos->buscar($idEquipoLocal) as $equipo):
                                    $Nombre_EquipoLocal = $equipo->__GET('Nombre_Equipo');
                                endforeach;
                                foreach($controlEquipos->buscar($idEquipoVisitante) as $equipo):
                                    $Nombre_EquipoVisitante = $equipo->__GET('Nombre_Equipo');
                                endforeach;
                            ?>
                            <div class="input-field col s12 m4 l4" style="text-align: center; font-size: 18px; margin-top: -0.5%">
                                <p><?php echo $Nombre_EquipoLocal; ?></p>
                            </div>
                            <div class="input-field col s12 m1 l1" style="padding: -0.5%">
                                <img style="width: 30px; height: 30px" src="../Equipos/Escudos/<?php echo $Nombre_EquipoLocal.".png";?>">
                            </div>
                            <div class="input-field col s12 m1 l1" style="margin-left: 2%; margin-top: 0.5%">
                                <p>VS</p>
                            </div>
                            <div class="input-field col s12 m1 l1" style="padding: -0.5%">
                                <img style="width: 30px; height: 30px" src="../Equipos/Escudos/<?php echo $Nombre_EquipoVisitante.".png";?>">
                            </div>
                            <div class="input-field col s12 m4 l4" style="text-align: center; font-size: 18px; margin-top: -0.5%">
                                <p><?php echo $Nombre_EquipoVisitante; ?></p>
                            </div>
                        </div>
                        <div class="row" style="margin-top: -2%">
                            <?php
                                $golesLocal = $encuentro->__GET('Goles_Equipo_Local');
                                $golesVisitante = $encuentro->__GET('Goles_Equipo_Visitante');
                                $amarillasLocal = $encuentro->__GET('Tarj_Ama_Local');
                                $amarillasVisitante = $encuentro->__GET('Tarj_Ama_Visitante');
                                $rojasLocal = $encuentro->__GET('Tarj_Rojas_Local');
                                $rojasVisitante = $encuentro->__GET('Tarj_Rojas_Visitante');
                                foreach($controlEquipos->buscar($idEquipoLocal) as $equipo):
                                    $Nombre_EquipoLocal = $equipo->__GET('Nombre_Equipo');
                                endforeach;
                                foreach($controlEquipos->buscar($idEquipoVisitante) as $equipo):
                                    $Nombre_EquipoVisitante = $equipo->__GET('Nombre_Equipo');
                                endforeach;
                            ?>
                            <div class="input-field col s12 m1 l1" style="text-align: right; font-size: 18px; margin-top: -2%">
                                <p><?php echo $amarillasLocal; ?></p>
                            </div>
                            <div class="input-field col s12 m1 l1" style="margin-top: 4.5%; margin-left: -2%; margin-top: 0.5%">
                                <img style="width: 30px; height: 30px" src="../Equipos/Escudos/tarjetaAmarilla.png">
                            </div>
                            <div class="input-field col s12 m1 l1" style="text-align: right; font-size: 18px; margin-left: 2%; margin-top: -2%">
                                <p><?php echo $rojasLocal; ?></p>
                            </div>
                            <div class="input-field col s12 m1 l1" style="margin-top: 4.5%; margin-left: -2%; margin-top: 0.5%">
                                <img style="width: 30px; height: 30px" src="../Equipos/Escudos/tarjetaRoja.png">
                            </div>
                            <div class="input-field col s12 m1 l1" style="text-align: center; font-size: 18px; margin-left: 2%; margin-top: -2%">
                                <p><?php echo $golesLocal; ?></p>
                            </div>
                            <div class="input-field col s12 m1 l1" style="margin-left: 2%; margin-top: 2.5%; margin-top: -2%">
                                <p> - </p>
                            </div>
                            <div class="input-field col s12 m1 l1" style="text-align: center; font-size: 18px; margin-left: -0.7%; margin-top: -2%">
                                <p><?php echo $golesVisitante; ?></p>
                            </div>
                            <div class="input-field col s12 m1 l1" style="margin-top: 4.5%; margin-left: 3%; margin-top: 0.5%">
                                <img style="width: 30px; height: 30px" src="../Equipos/Escudos/tarjetaRoja.png">
                            </div>
                            <div class="input-field col s12 m1 l1" style="text-align: left; font-size: 18px; margin-left: -2.5%; margin-top: -2%">
                                <p><?php echo $rojasVisitante; ?></p>
                            </div>
                            <div class="input-field col s12 m1 l1" style="padding: 2.3%; margin-top: -2%">
                                <img style="width: 30px; height: 30px" src="../Equipos/Escudos/tarjetaAmarilla.png">
                            </div>
                            <div class="input-field col s12 m1 l1" style="text-align: left; font-size: 18px; margin-left: -2.5%; margin-top: -2%">
                                <p><?php echo $amarillasVisitante; ?></p>
                            </div>
                        </div>
                        <div class="row" style="margin-top: -2%">
                            <?php
                                $fecha = $encuentro->__GET('Fecha_Encuentro');
                                $idEstadio = $encuentro->__GET('Estadio_idEstadio');
                                $idArbitro = $encuentro->__GET('Arbitro_idArbitro');
                                foreach($controlArbitros->buscar($idArbitro) as $arbitro):
                                    $Arbitro_idArbitro = $arbitro->__GET('Nombre_Arbitro');
                                endforeach;
                                foreach($controlEstadios->buscar($idEstadio) as $estadio):
                                    $Estadio_idEstadio = $estadio->__GET('Nombre_Estadio');
                                endforeach;
                            ?>
                            <div class="input-field col s12 m3 l4" style="text-align: center; font-size: 15px; margin-top: -5%; margin-left: -2.5%">
                                <p>Arbitro: <?php echo $Arbitro_idArbitro; ?></p>
                            </div>
                            <div class="input-field col s12 m3 l4" style="text-align: center; font-size: 15px; margin-top: -5%; margin-left: -2.5%">
                                <p>Fecha: <?php echo $fecha; ?></p>
                            </div>
                            <div class="input-field col s12 m3 l4" style="text-align: center; font-size: 15px; margin-top: -5%; margin-left: -2.5%">
                                <p>Estadio: <?php echo $Estadio_idEstadio; ?></p>
                            </div>
                        </div><br><br>
                    <?php
                }
            ?>
        </div>
        <div class="input-field col s6 m5 l5" style="width: 700px; height: 100%">
            <?php
                if (is_array($controlEncuentros->listarFiltros('FINALIZADO')) || is_object($controlEncuentros->listarFiltro('FINALIZADO'))){
                    ?>
                    <p style="font-size: 20px; font-family: cursive; margin-left: 3%">Ultimos Encuentros</p>
                    <?php
                foreach ($controlEncuentros->listarFiltro('FINALIZADO') as $encuentro) {
                    ?>
                        <div class="row" style="height: 80%">
                            <?php
                                $idEquipoLocal = $encuentro->__GET('Equipo_idEquipoLocal');
                                $idEquipoVisitante = $encuentro->__GET('Equipo_idEquipoVisitante');
                                foreach($controlEquipos->buscar($idEquipoLocal) as $equipo):
                                    $Nombre_EquipoLocal = $equipo->__GET('Nombre_Equipo');
                                endforeach;
                                foreach($controlEquipos->buscar($idEquipoVisitante) as $equipo):
                                    $Nombre_EquipoVisitante = $equipo->__GET('Nombre_Equipo');
                                endforeach;
                            ?>
                            <div class="input-field col s12 m4 l4" style="text-align: center; font-size: 18px; margin-left: 2%; margin-top: -0.5%">
                                <p><?php echo $Nombre_EquipoLocal; ?></p>
                            </div>
                            <div class="input-field col s12 m1 l1" style="padding: -0.5%">
                                <img style="width: 30px; height: 30px" src="../Equipos/Escudos/<?php echo $Nombre_EquipoLocal.".png";?>">
                            </div>
                            <div class="input-field col s12 m1 l1" style="margin-left: 2%; margin-top: 0.5%">
                                <p>VS</p>
                            </div>
                            <div class="input-field col s12 m1 l1" style="padding: -0.5%">
                                <img style="width: 30px; height: 30px" src="../Equipos/Escudos/<?php echo $Nombre_EquipoVisitante.".png";?>">
                            </div>
                            <div class="input-field col s12 m4 l4" style="text-align: center; font-size: 18px; margin-left: 2%; margin-top: -0.5%">
                                <p><?php echo $Nombre_EquipoVisitante; ?></p>
                            </div>
                        </div>
                        <div class="row" style="margin-top: -2%">
                            <?php
                                $golesLocal = $encuentro->__GET('Goles_Equipo_Local');
                                $golesVisitante = $encuentro->__GET('Goles_Equipo_Visitante');
                                $amarillasLocal = $encuentro->__GET('Tarj_Ama_Local');
                                $amarillasVisitante = $encuentro->__GET('Tarj_Ama_Visitante');
                                $rojasLocal = $encuentro->__GET('Tarj_Rojas_Local');
                                $rojasVisitante = $encuentro->__GET('Tarj_Rojas_Visitante');
                                foreach($controlEquipos->buscar($idEquipoLocal) as $equipo):
                                    $Nombre_EquipoLocal = $equipo->__GET('Nombre_Equipo');
                                endforeach;
                                foreach($controlEquipos->buscar($idEquipoVisitante) as $equipo):
                                    $Nombre_EquipoVisitante = $equipo->__GET('Nombre_Equipo');
                                endforeach;
                            ?>
                            <div class="input-field col s12 m1 l1" style="text-align: right; font-size: 18px; margin-left: 2%; margin-top: -2%">
                                <p><?php echo $amarillasLocal; ?></p>
                            </div>
                            <div class="input-field col s12 m1 l1" style="margin-top: 4.5%; margin-left: -2%; margin-top: 0.5%">
                                <img style="width: 30px; height: 30px" src="../Equipos/Escudos/tarjetaAmarilla.png">
                            </div>
                            <div class="input-field col s12 m1 l1" style="text-align: right; font-size: 18px; margin-left: 2%; margin-top: -2%">
                                <p><?php echo $rojasLocal; ?></p>
                            </div>
                            <div class="input-field col s12 m1 l1" style="margin-top: 4.5%; margin-left: -2%; margin-top: 0.5%">
                                <img style="width: 30px; height: 30px" src="../Equipos/Escudos/tarjetaRoja.png">
                            </div>
                            <div class="input-field col s12 m1 l1" style="text-align: center; font-size: 18px; margin-left: 2%; margin-top: -2%">
                                <p><?php echo $golesLocal; ?></p>
                            </div>
                            <div class="input-field col s12 m1 l1" style="margin-left: 2%; margin-top: 2.5%; margin-top: -2%">
                                <p> - </p>
                            </div>
                            <div class="input-field col s12 m1 l1" style="text-align: center; font-size: 18px; margin-left: -0.7%; margin-top: -2%">
                                <p><?php echo $golesVisitante; ?></p>
                            </div>
                            <div class="input-field col s12 m1 l1" style="margin-top: 4.5%; margin-left: 3%; margin-top: 0.5%">
                                <img style="width: 30px; height: 30px" src="../Equipos/Escudos/tarjetaRoja.png">
                            </div>
                            <div class="input-field col s12 m1 l1" style="text-align: left; font-size: 18px; margin-left: -2.5%; margin-top: -2%">
                                <p><?php echo $rojasVisitante; ?></p>
                            </div>
                            <div class="input-field col s12 m1 l1" style="padding: 2.3%; margin-top: -2%">
                                <img style="width: 30px; height: 30px" src="../Equipos/Escudos/tarjetaAmarilla.png">
                            </div>
                            <div class="input-field col s12 m1 l1" style="text-align: left; font-size: 18px; margin-left: -2.5%; margin-top: -2%">
                                <p><?php echo $amarillasVisitante; ?></p>
                            </div>
                        </div>
                        <div class="row" style="margin-top: -2%">
                            <?php
                                $fecha = $encuentro->__GET('Fecha_Encuentro');
                                $idEstadio = $encuentro->__GET('Estadio_idEstadio');
                                $idArbitro = $encuentro->__GET('Arbitro_idArbitro');
                                foreach($controlArbitros->buscar($idArbitro) as $arbitro):
                                    $Arbitro_idArbitro = $arbitro->__GET('Nombre_Arbitro');
                                endforeach;
                                foreach($controlEstadios->buscar($idEstadio) as $estadio):
                                    $Estadio_idEstadio = $estadio->__GET('Nombre_Estadio');
                                endforeach;
                            ?>
                            <div class="input-field col s12 m3 l4" style="text-align: center; font-size: 15px; margin-top: -5%">
                                <p>Arbitro: <?php echo $Arbitro_idArbitro; ?></p>
                            </div>
                            <div class="input-field col s12 m3 l4" style="text-align: center; font-size: 15px; margin-top: -5%">
                                <p>Fecha: <?php echo $fecha; ?></p>
                            </div>
                            <div class="input-field col s12 m3 l4" style="text-align: center; font-size: 15px; margin-top: -5%">
                                <p>Estadio: <?php echo $Estadio_idEstadio; ?></p>
                            </div>
                        </div><br><br>
                    <?php
                }
             }else{
                require_once '../Posiciones/listar.php';
             }
            ?>
        </div>
    </div>
    </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>

</html>
