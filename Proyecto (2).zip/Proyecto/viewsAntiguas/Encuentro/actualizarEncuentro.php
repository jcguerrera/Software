<?php 
if (!isset($_SESSION['usuario'])) {
    session_start();
}   
if (isset($_SESSION['usuario'])) {
    require_once 'actualizarEncuentro.php';
} else {
    header('Location: ../../login/login.php');
}
?>
<?php 
    //require_once '../../controller/Estadio_controller.php';
    require_once '../../model/model_Encuentro.php';
    //require_once '../../model/model_Arbitro.php';
    require_once '../../model/model_Equipos.php';
    require_once '../../controller/equipos_controller.php';
    require_once '../../controller/Encuentro_controller.php';
    require_once 'headerEncuentro.php';
    //include 'headerBorders.php';

    $controlEquipo = new Equipos_controller();
    $controlEncuentro = new Encuentro_Controller();
    //$controlArbitro = new Arbitro_Controller();
    //$controlEstadio = new Estadio_Controller();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registrar</title>
    <!--<script src="https://code.jquery.com/jquery-3.4.0.js" integrity="sha256-DYZMCC8HTC+QDr5QNaIcfR7VSPtcISykd+6eSmBW5qo=" crossorigin="anonymous"></script>-->
</head>
<body>
      <div class="row" style="width: 800px; border-radius: 5px; border: solid 1px black">
      <form method="POST">
        <div class="input-field col s12 m5 l5">
          <label style="margin-top: -40px; margin-left: 45px; font-size: 12px" id="Equipo_idEquipoLocal">Id Encuentro</label>
          <select name="Equipo_idEquipoLocalSelect" id="Equipo_idEquipoLocalSelect" required style="padding: 15px; width: 106.0%; margin-top: 15px; margin-left: 0%; width: 100%; height: 100%; display: block;">
            <option value="" disabled selected>Seleccione un Equipo</option>
            <?php 
            foreach ($controlEquipo->listar() as $equipo):
            ?>
              <option value="<?php echo $equipo->__GET('idEquipo'); ?>">
              <?php 
                echo $equipo->__GET('Nombre_Equipo'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
          </select>
        </div>





















      <div class="input-field col s12">
        <div class="input-field col s12 m5 l5">
          <label style="margin-top: -40px; margin-left: 45px; font-size: 12px" id="Equipo_idEquipoLocal">Equipo Local</label>
          <select name="Equipo_idEquipoLocalSelect" id="Equipo_idEquipoLocalSelect" required style="padding: 15px; width: 106.0%; margin-top: 15px; margin-left: 0%; width: 100%; height: 100%; display: block;">
            <option value="" disabled selected>Seleccione un Equipo</option>
            <?php 
            foreach ($controlEquipo->listar() as $equipo):
            ?>
              <option value="<?php echo $equipo->__GET('idEquipo'); ?>">
              <?php 
                echo $equipo->__GET('Nombre_Equipo'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
          </select>
        </div>
        <div class="input-field col s12 m2 l2">
          <p style="margin-left: 40%; padding: 15px">VS</p>
        </div>
        <div class="input-field col s12 m5 l5">
          <label style="margin-top: -40px; margin-left: 45px; font-size: 12px" id="Equipo_idEquipoVisitante">Equipo Visitante</label>
          <select name="Equipo_idEquipoVisitanteSelect" id="Equipo_idEquipoVisitanteSelect" required style="padding: 15px; width: 106.0%; margin-top: 15px; margin-left: 0%; width: 100%; height: 100%; display: block;">
          <option value="" disabled selected>Seleccione un Equipo</option>
            <?php 
            foreach ($controlEquipo->listar() as $equipo):
            ?>
              <option value="<?php echo $equipo->__GET('idEquipo'); ?>">
              <?php 
                echo $equipo->__GET('Nombre_Equipo'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
        </select>          
        </div>
      </div>
      <div class="input-field col s12">
        <div class="input-field col s12 m3 l3">
        <label style="margin-top: -40px; margin-left: 45px; font-size: 12px" id="Equipo_idEquipo">Estado encuentro</label>
          <select name="Estado_Encuentro" id="Estado_Encuentro" required style="padding: 15px; margin-top: 15px; margin-left: 0%; width: 100%; height: 100%; display: block;">
            <option value="" disabled selected>Seleccione Estado</option>
            <option>PENDIENTE</option>
            <option>EN JUEGO</option>
            <option>FINALIZADO</option>
          </select>
        </div>
        <div class="input-field col s12 m3 l3">
          <label style="margin-top: -40px; margin-left: 45px; font-size: 12px" id="Arbitro_idArbitro">Arbitro</label>
          <select name="Arbitro_idArbitroSelect" id="Arbitro_idArbitroSelect" required style="padding: 15px; margin-top: 15px; margin-left: 0%; width: 100%; height: 100%; display: block;">
          <option value="" disabled selected>Seleccione Arbitro</option>
            <?php 
            foreach ($controlArbitro->listar() as $arbitro):
            ?>
              <option value="<?php echo $arbitro->__GET('idArbitro'); ?>">
              <?php 
                echo $arbitro->__GET('Nombre_Arbitro'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
        </select>          
        </div>
        <div class="input-field col s12 m3 l3">
          <label style="margin-top: -40px; margin-left: 45px; font-size: 12px" id="Estadio_idEstadio">Estadio</label>
          <select name="Estadio_idEstadioSelect" id="Estadio_idEstadioSelect" required style="padding: 15px; margin-top: 15px; margin-left: 0%; width: 100%; height: 100%; display: block;">
          <option value="" disabled selected>Seleccione Estadio</option>
            <?php 
            foreach ($controlEstadio->listar() as $estadio):
            ?>
              <option value="<?php echo $estadio->__GET('idEstadio'); ?>">
              <?php 
                echo $estadio->__GET('Nombre_Estadio'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
        </select>          
        </div>
        <div class="input-field col s12 m3 l3">
          <input type="submit" name="enviar" value="Mostrar Usuario" style="padding: 15px; width: 106.0%; margin-top: 15px; margin-left: 0%; width: 100%; height: 100%; display: block;">
        </div>
      </div>
      </form>
      </div>
      <br><br>
</body>
</html>
