<?php 

require_once '../../controller/jugadores_controller.php';
require_once '../../model/model_Jugadores.php';
require_once '../../model/model_Equipos.php';
require_once '../../controller/equipos_controller.php';
require_once 'headerJugadores.php';
//include 'headerCountries.php';

$control = new jugador_Controller();
$controlEquipo = new Equipos_controller();

?>
<!DOCTYPE html>
<html>
<head>
    <title>Jugadores de la liga</title>

</head>
<body>
<div style="width: 500px; margin-left: 30%">
    <form method="POST">
        <p style="font-size: 18px; font-family:  cursive;">Equipo para ver Jugadores</p>
      <div class="input-field col s12">
        <div class="input-field col s12 m5 l5">
          <select name="Equipo_idEquipoLocalSelect" id="Equipo_idEquipoLocalSelect" required style="padding: 15px; width: 106.0%; margin-top: 5%; margin-left: 0%; width: 100%; height: 100%; display: block;">
            <option value="" disabled selected>Seleccione un Equipo</option>
            <?php 
            foreach ($controlEquipo->listar() as $equipo):
            ?>
              <option value="<?php echo $equipo->__GET('idEquipo'); ?>">
              <?php 
                echo $equipo->__GET('Nombre_Equipo'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
          </select>
        </div>
        <div class="input-field col s12 m3 l3">
          <input type="submit" name="enviar" value="Buscar" style="padding: 15px; width: 106.0%; margin-top: 15px; margin-left: 0%; width: 100%; height: 100%; display: block;">
        </div>
    </div>
</form>
<?php 
    if (isset($_POST['enviar'])) {
        $idEquipo = $_POST['Equipo_idEquipoLocalSelect'];
        //echo "perra ".$idEquipo;
        if (is_array($control->listarJugadoresEquipo($idEquipo)) || is_object($$control->listarJugadoresEquipo($idEquipo))){
            ?>
        <table class="centered" style="font-family: cursive; border-collapse: separate; border-spacing: 5px 10px;">
        <thead style="font-size: 10px; text-transform: uppercase;">
            <tr>

                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Nombre</th>
                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Edad</th>
                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Posicion</th>
                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Nacionalidad</th>
                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Equipo</th>
                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Editar</th>

            </tr>
        </thead>


        <tbody>
            <tr>
                <?php 
                    foreach ($control->listarJugadoresEquipo($idEquipo) as $jugador):
                ?>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $jugador->__GET('Nombre_Jugador'); 
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $jugador->__GET('Edad'); 
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $jugador->__GET('Posicion'); 
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $jugador->__GET('Pais_idPais');
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $jugador->__GET('Equipo_idEquipo');
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                <a href="editarInformacion.php?id=<?php echo $jugador->idJugador; ?>">Editar </a>
                     <!--<a href="editar.php?id=<?php// echo $r->nombre; ?>"><i class="small material-icons" style="color: black">mode_edit</i></a>-->
                </td>
        </tbody>
        <?php 
            endforeach; 
        ?>
    </table>
            <?php
        }
    } 
?>
</div>
<div>
    
    <!--<a href="registrar.php"><input type="submit" value="Registrar" id="btn_re"></a>-->
</div>
<!--<a href="../../index.php" title="Ir la página anterior">Volver al menu inicial</a>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>

</html>
