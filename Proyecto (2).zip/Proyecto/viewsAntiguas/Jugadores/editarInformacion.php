<?php 
require_once '../../controller/paises_controller.php';
require_once '../../controller/jugadores_controller.php';
require_once '../../controller/equipos_controller.php';
require_once '../../model/model_Pais.php';
require_once '../../model/model_Equipos.php';
require_once '../../model/model_Jugadores.php';
require_once 'headerJugadores.php';

$control = new jugador_Controller();
$controlPaises = new Paises_Controller();
$controlEquipos = new equipos_controller();
$jugador = new Jugadores();
$identificacion = $_GET['id'];
//$identificacion = $_GET['id'];

?>
<!DOCTYPE html>
<html>
<head>
    <title>Update Country</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="../../css/materialize.css"/>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../../css/materialize.min.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript" src="../../js/materialize.min.js"></script>
    <script src="../../js/sweetalert2.min.js"></script>
    <script src="../../js/sweetalert2.js"></script>
    <link rel="stylesheet" href="../../css/sweetalert2.min.css">
    <link rel="stylesheet" href="../../css/sweetalert2.css">
    <script src="../../js/materialize.js"></script>
    <script src="../../js/materialize.min.js"></script>
    <script scr="funciones.js"></script>
    <script src="validar.js"></script>
</head>

<body>
<div class="row" style="width: 500px">
    <form class="col s12" action="#" method="POST">
        <div class="row" style="margin-top: 20px;">
            <?php 
                foreach ($control->buscar($identificacion) as $jugador):
            ?>
                    <div class="input-field col s12" id="idJugador">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="number" disabled class="validate" name="idJugador" value="<?php echo $jugador->__GET('idJugador');?>">
                        <label for="icon_prefix">Id Jugador</label>
                    </div>
                    <div class="input-field col s12" id="Nombre_Jugador">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="text" class="validate" name="Nombre_Jugador" value="<?php echo $jugador->__GET('Nombre_Jugador');?>">
                        <label for="icon_prefix">Nombre Jugador</label>
                    </div>
                    <div class="input-field col s12" id="Edad">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="number" class="validate" name="Edad" value="<?php echo $jugador->__GET('Edad');?>">
                        <label for="icon_prefix">Edad</label>
                    </div>
                    <div class="input-field col s12" id="Posicion">
                        <i class="material-icons prefix">account_circle</i>
                        <input id="icon_prefix nombre" type="text" class="validate" name="Posicion" value="<?php echo $jugador->__GET('Posicion');?>">
                        <label for="icon_prefix">Posicion</label>
                    </div>
                    <div class="input-field col s12">
                        <label style="margin-top: -40px; margin-left: 45px; font-size: 12px" id="Pais_idPais">Selecciona un pais</label>
                        <select name="Pais_idPaisSelect" id="Pais_idPaisSelect" required style="padding: 15px; margin-top: 15px; margin-left: 5%; height: 100%; display: block;">
                            <?php 
                            foreach ($controlPaises->buscar($jugador->__GET('Pais_idPais')) as $pais):
                            ?>
                            <option selected value="<?php echo $pais->__GET('idPais'); ?>">
                            <?php 
                                echo $pais->__GET('Nombre_Pais'); 
                            ?>
                            </option>
                            <?php 
                            endforeach; 
                            ?>

                            <?php 
                            foreach ($controlPaises->listarDiferente($jugador->__GET('Pais_idPais')) as $pais):
                            ?>
                            <option value="<?php echo $pais->__GET('idPais'); ?>">
                            <?php 
                                echo $pais->__GET('Nombre_Pais'); 
                            ?>
                            </option>
                            <?php 
                            endforeach; 
                            ?>
                        </select>
                    </div>

                    <div class="input-field col s12">
                        <label style="margin-top: -40px; margin-left: 45px; font-size: 12px" id="Equipo_idEquipo">Selecciona un equipo</label>
                        <select name="Equipo_idEquipoSelect" id="Equipo_idEquipoSelect" required style="padding: 15px; margin-top: 15px; margin-left: 5%; height: 100%; display: block;">
                            <?php 
                            foreach ($controlEquipos->buscar($jugador->__GET('Equipo_idEquipo')) as $equipo):
                            ?>
                            <option selected value="<?php echo $equipo->__GET('idEquipo'); ?>">
                            <?php 
                                echo $equipo->__GET('Nombre_Equipo'); 
                            ?>
                            </option>
                            <?php 
                            endforeach; 
                            ?>

                            <?php 
                            foreach ($controlEquipos->listarDiferente($jugador->__GET('Equipo_idEquipo')) as $equipo):
                            ?>
                            <option value="<?php echo $equipo->__GET('idEquipo'); ?>">
                            <?php 
                                echo $equipo->__GET('Nombre_Equipo'); 
                            ?>
                            </option>
                            <?php 
                            endforeach; 
                            ?>
                        </select>
                    </div>

            <?php 
                endforeach; 
            ?>
        </div>
        <input type="submit" value="GUARDAR" id="btn_formulario" name="enviar" style="margin-top:3%">
    </form>
     <?php 
    if (isset($_POST['enviar'])) {
        $jugador->__SET('idJugador',$identificacion);
        $jugador->__SET('Nombre_Jugador',$_POST['Nombre_Jugador']);
        $jugador->__SET('Edad',$_POST['Edad']);
        $jugador->__SET('Posicion',$_POST['Posicion']);
        $jugador->__SET('Pais_idPais',$_POST['Pais_idPaisSelect']);
        $jugador->__SET('Equipo_idEquipo',$_POST['Equipo_idEquipoSelect']);
        if(($control->actualizar($jugador)) != true){
            ?>
            <script language="JavaScript" type="text/javascript">
                alert("Error al ingresar los datos");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
        }else{
            ?>
            <script language="JavaScript" type="text/javascript">
                alert("Datos modificados modificado exitosamente");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
        }
    } 
?>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>
