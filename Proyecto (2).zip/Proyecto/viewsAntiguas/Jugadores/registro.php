<?php 
    require_once '../../controller/jugadores_controller.php';
    require_once '../../model/model_Jugadores.php';

    $jugador = new Jugadores();
    $control = new jugador_Controller();
    $jugador->__SET('Nombre_Jugador',$_POST['Nombre_Jugador']);
    $jugador->__SET('Edad',$_POST['Edad']);
    $jugador->__SET('Posicion',$_POST['PosicionSelect']);
    $jugador->__SET('Pais_idPais',$_POST['Pais_idPaisSelect']);
    $jugador->__SET('Equipo_idEquipo',$_POST['Equipo_idEquipoSelect']);
    if($control->Insertar($jugador) != true){
      ?>
            <script language="JavaScript" type="text/javascript">
                alert("Error al ingresar los datos del jugador");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
    }else{
      ?>
            <script language="JavaScript" type="text/javascript">
                alert("Jugador ingresado correctamente");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
    }

?>

