<?php 
    //require_once '../../controller/equipos_controller.php';
    require_once '../../model/model_Jugadores.php';
    require_once '../../model/model_Pais.php';
    require_once '../../model/model_Equipos.php';
    require_once '../../controller/equipos_controller.php';
    require_once '../../controller/paises_controller.php';
    require_once 'headerJugadores.php';
    //include 'headerBorders.php';

    $jugador = new Jugadores();
    $controlPaises = new Paises_Controller();
    $controlEquipo = new Equipos_controller();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registrar</title>
    <!--<script src="https://code.jquery.com/jquery-3.4.0.js" integrity="sha256-DYZMCC8HTC+QDr5QNaIcfR7VSPtcISykd+6eSmBW5qo=" crossorigin="anonymous"></script>-->
</head>
<body>
<div class="row" style="width: 500px">
<form class="col s12" method="POST" action="registro.php">
  <div class="row">
      <div class="input-field col s12" id="Nombre_Jugador">
        <i class="material-icons prefix">account_circle</i>
        <input id="icon_prefix nombre" type="text" class="validate" name="Nombre_Jugador" required>
        <label for="icon_prefix">Nombre Jugador</label>
      </div>
      <div class="input-field col s12" id="Edad" style="display: none;">
        <i class="material-icons prefix">account_circle</i>
        <input id="icon_prefix nombre" type="number" class="validate" name="Edad" required>
        <label for="icon_prefix">Edad</label>
      </div>
      <div class="input-field col s12">
        <label style="display: none; margin-top: -40px; margin-left: 45px; font-size: 12px" id="Posicion">Selecciona una posicion</label>
        <select name="PosicionSelect" id="PosicionSelect" required style="padding: 15px; width: 106.5%; margin-top: 15px; margin-left: 5%; width: 100%; height: 100%">
          <option value="" disabled selected>Seleccione una Posicion</option>
              <option value="POR">POR</option>
              <option value="DEF">DEF</option>
              <option value="MED">MED</option>
              <option value="DEL">DEL</option>
        </select>
      </div>
      <div class="input-field col s12">
        <label style="display: none; margin-top: -40px; margin-left: 45px; font-size: 12px" id="Pais_idPais">Selecciona un pais</label>
        <select name="Pais_idPaisSelect" id="Pais_idPaisSelect" required style="padding: 15px; width: 106.5%; margin-top: 15px; margin-left: 5%; width: 100%; height: 100%">
          <option value="" disabled selected>Seleccione un pais</option>
            <?php 
            foreach ($controlPaises->listar() as $pais):
            ?>
              <option value="<?php echo $pais->__GET('idPais'); ?>">
              <?php 
                echo $pais->__GET('Nombre_Pais'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
        </select>
      </div>
      <div class="input-field col s12">
        <label style="display: none; margin-top: -40px; margin-left: 45px; font-size: 12px" id="Equipo_idEquipo">Selecciona un Equipo</label>
        <select name="Equipo_idEquipoSelect" id="Equipo_idEquipoSelect" required style="padding: 15px; width: 106.5%; margin-top: 15px; margin-left: 5%; width: 100%; height: 100%">
          <option value="" disabled selected>Seleccione un Equipo</option>
            <?php 
            foreach ($controlEquipo->listar() as $equipo):
            ?>
              <option value="<?php echo $equipo->__GET('idEquipo'); ?>">
              <?php 
                echo $equipo->__GET('Nombre_Equipo'); 
              ?>
              </option>
            <?php 
            endforeach; 
            ?>
        </select>
      </div>
  </div>
  <script>
        document.getElementById("Nombre_Jugador").onclick = function() {ShowEdad()};
        document.getElementById("Edad").onclick = function() {ShowPosicion()};
        document.getElementById("PosicionSelect").onclick = function() {ShowPaises()};
        document.getElementById("Pais_idPaisSelect").onclick = function() {ShowEquipos()};

        function ShowEdad() {
            document.getElementById("Edad").style.display = "block";
        }
        function ShowPosicion() {
            document.getElementById("Posicion").style.display = "block";
            document.getElementById("PosicionSelect").style.display = "block";
        }
        function ShowPaises() {
            document.getElementById("Pais_idPais").style.display = "block";
            document.getElementById("Pais_idPaisSelect").style.display = "block";
        }
        function ShowEquipos() {
            document.getElementById("Equipo_idEquipo").style.display = "block";
            document.getElementById("Equipo_idEquipoSelect").style.display = "block";
        }
        </script>
  <input type="submit" name="Enviar">
</form>
</div>
</body>
</html>
