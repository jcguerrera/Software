<?php 

require_once '../../controller/paises_controller.php';
require_once '../../model/model_Pais.php';
require_once '../../model/conexion.php';
require_once 'headerPaises.php';
//include 'headerCountries.php';

$control = new Paises_Controller();

?>
<!DOCTYPE html>
<html>
<head>
    <title>Listar Paises</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
<div>
    <table class="centered" style="font-family: cursive; border-collapse: separate; border-spacing: 5px 10px;">
        <thead style="font-size: 10px; text-transform: uppercase;">
            <tr>

                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Nombre</th>
                <th style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 20px">Editar</th>

            </tr>
        </thead>


        <tbody>
            <tr>
                <?php
                if (is_array($control->listar()) || is_object($control->listar())){
                    foreach ($control->listar() as $equipo):
                ?>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                    <?php 
                        echo $equipo->__GET('Nombre_Pais'); 
                    ?>
                </td>
                <td style="border-radius: 5px; border: #000 solid 2px; height: 15px; width: 100px; text-align: center; font-size: 15px;">
                <a href="editarInformacion.php?id=<?php echo $equipo->idPais; ?>">Editar </a>
                     <!--<a href="editar.php?id=<?php// echo $r->nombre; ?>"><i class="small material-icons" style="color: black">mode_edit</i></a>-->
                </td>
        </tbody>
        <?php 
            endforeach;
         }
        ?>
    </table>
    <!--<a href="registrar.php"><input type="submit" value="Registrar" id="btn_re"></a>-->
</div>
<!--<a href="../../index.php" title="Ir la página anterior">Volver al menu inicial</a>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>

</html>
