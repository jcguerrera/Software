
<?php
	require_once '../../controller/paises_controller.php';
    require_once '../../model/model_Pais.php';
    require_once 'headerPaises.php';
    $pais = new Paises();
    $control = new Paises_controller();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registrar</title>
    <script src="https://code.jquery.com/jquery-3.4.0.js" integrity="sha256-DYZMCC8HTC+QDr5QNaIcfR7VSPtcISykd+6eSmBW5qo=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="../../css/materialize.css"/>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../../css/materialize.min.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript" src="../../js/materialize.min.js"></script>
    <script src="../../js/sweetalert2.min.js"></script>
    <script src="../../js/sweetalert2.js"></script>
    <link rel="stylesheet" href="../../css/sweetalert2.min.css">
    <link rel="stylesheet" href="../../css/sweetalert2.css">
    <script src="../../js/materialize.js"></script>
    <script src="../../js/materialize.min.js"></script>
    <script scr="funciones.js"></script>
    <script src="validar.js"></script>
</head>
<body>
<form method="POST">
  <div class="row" style="width: 50%">
     <div class="input-field col s12" id="nombre">
        <i class="material-icons prefix">account_circle</i>
        <input id="icon_prefix nombre" type="text" class="validate" name="nombre" required>
        <label for="icon_prefix">Nombre</label>
    </div>

  </div>
  <button class="btn waves-effect waves-light blue" type="submit" name="enviar" style="margin-left: 50%">Enviar
   <i class="material-icons right">send</i>
</form>
 <?php 
    if (isset($_POST['enviar'])) {
    	if($_POST['nombre'] != null){
    		$pais->__SET('Nombre_Pais',$_POST['nombre']);
    		if($control->Insertar($pais) != true){
        		?>
            		<script language="JavaScript" type="text/javascript">
                		alert("Error al ingresar los datos");
            		</script>
            		<meta http-equiv="refresh" content="0; url=listar.php">
        		<?php
    		}else{
        		?>
           	 		<script language="JavaScript" type="text/javascript">
                		alert("Pais agregado correctamente");
            		</script>
            		<meta http-equiv="refresh" content="0; url=listar.php">
        		<?php
    		}
    	}else{
    		?>
           	 	<script language="JavaScript" type="text/javascript">
                		alert("Ingrese un pais");
            		</script>
            		<meta http-equiv="refresh" content="0; url=listar.php">
        	<?php
    	}
    } 
?>
</body>
</html>
