<?php 
require_once '../../controller/paises_controller.php';
//require_once '../../controller/subRegion_controller.php';
require_once '../../model/model_Pais.php';
require_once 'headerPaises.php';
//require_once '../../model/model_subRegion.php';
//include'headerCountries.php';

$control = new Paises_Controller();
$pais = new Paises();
$identificacion = $_GET['id'];
//$identificacion = $_GET['id'];

?>
<!DOCTYPE html>
<html>
<head>
    <title>Update Country</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="../../css/materialize.css"/>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../../css/materialize.min.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript" src="../../js/materialize.min.js"></script>
    <script src="../../js/sweetalert2.min.js"></script>
    <script src="../../js/sweetalert2.js"></script>
    <link rel="stylesheet" href="../../css/sweetalert2.min.css">
    <link rel="stylesheet" href="../../css/sweetalert2.css">
    <script src="../../js/materialize.js"></script>
    <script src="../../js/materialize.min.js"></script>
    <script scr="funciones.js"></script>
    <script src="validar.js"></script>
</head>

<body>
<div class="row" style="width: 90%">
    <form class="col s12" action="#" method="POST">
        <div class="row" style="margin-top: 20px;">
            <?php 
                foreach ($control->buscar($identificacion) as $equipo):
            ?>
                    <div class="input-field col s12">
                        <i class="material-icons prefix">search</i>
                        <label>Id Equipo</label>
                        <input id="icon_prefix" disabled type="number" class="validate" name="id" value="<?php echo $equipo->__GET('idPais');?>"/>
                    </div>
                    <div class="input-field col s12">
                        <i class="material-icons prefix">search</i>
                        <label>Nombre</label>
                        <input id="icon_prefix" type="text" class="validate" name="nombre" value="<?php echo $equipo->__GET('Nombre_Pais');?>"/>
                    </div>
            <?php 
                endforeach; 
            ?>
        </div>
        <input type="submit" value="GUARDAR" id="btn_formulario" name="enviar" style="margin-top:3%">
    </form>
 <?php 
    if (isset($_POST['enviar'])) {
        $pais->__SET('idPais',$identificacion);
        $pais->__SET('Nombre_Pais',$_POST['nombre']);
        if(($control->actualizar($pais)) != true){
            ?>
            <script language="JavaScript" type="text/javascript">
                alert("Error al ingresar los datos");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
        }else{
            ?>
            <script language="JavaScript" type="text/javascript">
                alert("Datos modificados modificado exitosamente");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
        }
    } 
?>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>
