<?php 
if (!isset($_SESSION['usuario'])) {
    session_start();
}   
if (isset($_SESSION['usuario'])) {
    require_once 'registro.php';
} else {
    header('Location: ../../login/login.php');
}
?>
<?php 
    require_once '../../controller/Arbitro_controller.php';
    require_once '../../model/model_Arbitro.php';
    //include 'headerBorders.php';

    $arbitro = new Arbitro();
    $control = new Arbitro_Controller();
    //$border = new Borders();
    //$control = new Borders_Controller();
    $arbitro->__SET('Nombre_Arbitro',$_POST['Nombre_Arbitro']);

    if($control->Insertar($arbitro) != true){
        ?>
            <script language="JavaScript" type="text/javascript">
                alert("Error al registrar un arbitro");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
    }else{
      ?>
            <script language="JavaScript" type="text/javascript">
                alert("Arbitro registrado correctamente");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
    }
    //$nombre = $_POST['nombre'];

?>

