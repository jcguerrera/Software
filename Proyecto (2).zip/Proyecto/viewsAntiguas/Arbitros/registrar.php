<?php 
if (!isset($_SESSION['usuario'])) {
    session_start();
}   
if (isset($_SESSION['usuario'])) {
    require_once 'registrar.php';
} else {
    header('Location: ../../login/login.php');
}
?>
<?php
	require_once 'headerArbitros.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registrar Arbitro</title>
</head>
<body>
<div class="row" style="width: 500px">
<form class="col s12" method="POST" action="registro.php">
  <div class="row">
      <div class="input-field col s12" id="Nombre_Arbitro">
        <i class="material-icons prefix">account_circle</i>
        <input id="icon_prefix nombre" type="text" class="validate" name="Nombre_Arbitro" required>
        <label for="icon_prefix">Nombre Arbitro</label>
      </div>
  </div>
  <input type="submit" name="Enviar">
</form>
</div>
</body>
</html>
