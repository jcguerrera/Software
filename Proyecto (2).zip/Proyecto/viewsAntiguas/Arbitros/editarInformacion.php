<?php 
if (!isset($_SESSION['usuario'])) {
    session_start();
}   
if (isset($_SESSION['usuario'])) {
    require_once 'editarInformacion.php';
} else {
    header('Location: ../../login/login.php');
}
?>
<?php 
require_once '../../controller/Arbitro_controller.php';
require_once '../../model/model_Arbitro.php';
require_once 'headerArbitros.php';

$control = new Arbitro_Controller();
$arbitro = new Arbitro();
$identificacion = $_GET['id'];
//$identificacion = $_GET['id'];

?>
<!DOCTYPE html>
<html>
<head>
    <title>Modificar Arbitro</title>
</head>

<body>
<div class="row" style="width: 90%">
    <form class="col s12" action="#" method="POST">
        <div class="row" style="margin-top: 20px;">
            <?php 
                foreach ($control->buscar($identificacion) as $arbitro):
            ?>
                    <div class="input-field col s12">
                        <i class="material-icons prefix">search</i>
                        <label>Id Arbitro</label>
                        <input id="icon_prefix" disabled type="number" class="validate" name="id" value="<?php echo $arbitro->__GET('idArbitro');?>"/>
                    </div>
                    <div class="input-field col s12">
                        <i class="material-icons prefix">search</i>
                        <label>Nombre Estadio</label>
                        <input id="icon_prefix" type="text" class="validate" name="Nombre_Arbitro" value="<?php echo $arbitro->__GET('Nombre_Arbitro');?>"/>
                    </div>
            <?php 
                endforeach; 
            ?>
        </div>
        <input type="submit" value="GUARDAR" id="btn_formulario" name="enviar" style="margin-top:3%">
    </form>
 <?php 
    if (isset($_POST['enviar'])) {
        $arbitro->__SET('idArbitro',$identificacion);
        $arbitro->__SET('Nombre_Arbitro',$_POST['Nombre_Arbitro']);
        if(($control->actualizar($arbitro)) != true){
            ?>
            <script language="JavaScript" type="text/javascript">
                alert("Error al modificar datos");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
        }else{
            ?>
            <script language="JavaScript" type="text/javascript">
                alert("Datos modificados modificado exitosamente");
            </script>
            <meta http-equiv="refresh" content="0; url=listar.php">
            <?php
        }
    } 
?>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>
