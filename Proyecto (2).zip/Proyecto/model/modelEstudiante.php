<?php 

class Estudiante
{
	private $Carrera_idCarrera;
	private $Usuario_Usuario;


	public function __GET($att)
	{
		return $this->$att;
	}

	public function __SET($att, $v)
	{
		$this->$att=$v;
	}
}
?>