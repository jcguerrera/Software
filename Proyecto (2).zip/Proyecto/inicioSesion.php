<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
<form method="POST" action="verificarInicio.php">
	<label>Usuario</label>
	<input type="text" name="Usuario" required>
	<label>Clave</label>
	<input type="password" name="Clave" required>
	<button type="button" onclick="login.submit()">Iniciar Sesion</button>
</form>

</body>
</html>