<?php
include_once "../../model/conexion.php";
include_once "../../model/modelCarrera.php";

class ControllerEstudiante extends Conexion{
    

    public function Insertar(Estudiante $estudiante){
		$insertar = "INSERT INTO estudiante (Carrera_idCarrera,Usuario_Usuario) VALUES (?,?)";
		try{
			$this->conexion->prepare($insertar)->execute(array(
				$estudiante->__GET('Carrera_idCarrera'),
				$estudiante->__GET('Usuario_Usuario'),
			));
			return true;
		}catch(Exception $e){
			echo "Error ".$e;
		}

    }
    
    public function Listar(){
		$dato = array();
		$listar = "SELECT * FROM estudiante ORDER BY Usuario_Usuario";
		try{
			$resultado = $this->conexion->prepare($listar);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$estudiante = new Estudiante();
				$estudiante->__SET('Carrera_idCarrera',$dato->Carrera_idCarrera);
				$estudiante->__SET('Usuario_Usuario',$dato->Usuario_Usuario);
				$datos[]=$estudiante;
			}
			return $datos;
		}catch(Exception $e){
			echo "Error ".$e;
		}
	}

	public function Buscar($usuario){
		$dato=array();
		$datos=null;
		$consulta="SELECT * FROM estudiante WHERE Usuario_Usuario='$usuario'";
		try {
			$resultado=$this->conexion->prepare($consulta);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$estudiante = new Estudiante();
				$estudiante->__SET('Carrera_idCarrera',$dato->Carrera_idCarrera);
				$estudiante->__SET('Usuario_Usuario',$dato->Usuario_Usuario);
				$datos[]=$carrera;
			}
			return $datos;
		} catch (Exception $exception) {
			die($exception->getMessage());
		}
	}

	public function Actualizar(Estudiante $estudiante){
		$actualizar="UPDATE estudiante SET  Carrera_idCarrera=? where Usuario_Usuario=?";
		try {
			$this->conexion->prepare($actualizar)->execute(array(
				$estudiante->__GET('Carrera_idCarrera'),
			));
			return true;
		} catch (Exception $exception) {
			echo "Error al actualizar datos ".$exception->getMessage();
		}
	}
}
?>