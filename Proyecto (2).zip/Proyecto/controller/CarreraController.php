<?php
include_once '../../model/conexion.php';
include_once '../../model/modelCarrera.php';

class ControllerCarrera extends Conexion{
    

    public function Insertar(Carrera $carrera){
		$insertar = "INSERT INTO carrera (idCarrera,Nombre) VALUES (null,?)";
		try{
			$this->conexion->prepare($insertar)->execute(array(
				$carrera->__GET('Nombre')
			));
			return true;
		}catch(Exception $e){
			echo "Error ".$e;
		}

    }
    
    public function Listar(){
		$dato = array();
		$listar = "SELECT * FROM carrera ORDER BY Nombre";
		try{
			$resultado = $this->conexion->prepare($listar);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$carrera = new Carrera();
				$carrera->__SET('idCarrera',$dato->idCarrera);
				$carrera->__SET('Nombre',$dato->Nombre);
				$datos[]=$carrera;
			}
			return $datos;
		}catch(Exception $e){
			echo "Error ".$e;
		}
	}

	public function Buscar($id){
		$dato=array();
		$datos=null;
		$consulta="SELECT * FROM Carrera WHERE idCarrera='$id'";
		try {
			$resultado=$this->conexion->prepare($consulta);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$carrera = new Carrera();
				$carrera->__SET('idCarrera',$dato->idCarrera);
				$carrera->__SET('Nombre',$dato->Nombre);
				$datos[]=$carrera;
			}
			return $datos;
		} catch (Exception $exception) {
			die($exception->getMessage());
		}
	}

	public function Actualizar(Carrera $carrera){
		$actualizar="UPDATE Carrera SET  Nombre=? where idCarrera=?";
		try {
			$this->conexion->prepare($actualizar)->execute(array(
				$carrera->__GET('Nombre'),
			));
			return true;
		} catch (Exception $exception) {
			echo "Error al actualizar datos ".$exception->getMessage();
		}
	}
}
?>