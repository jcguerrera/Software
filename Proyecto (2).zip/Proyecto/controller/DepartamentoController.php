<?php
include_once '../../model/conexion.php';
include_once '../../model/modelDepartamento.php';

class ControllerDepartamento extends Conexion{
	
    public function Insertar(Departamento $departamento){
		$insertar = "INSERT INTO Departamento (idDepartamento,Nombre) VALUES (null,?)";
		try{
			$this->conexion->prepare($insertar)->execute(array(
				$departamento->__GET('Nombre'),
			));
			return true;
		}catch(Exception $e){
			echo "Error ".$e;
		}
    }
    

	public function Listar(){
		$dato = array();
		$listar = "SELECT * FROM departamento ORDER BY Nombre";
		try{
			$resultado = $this->conexion->prepare($listar);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$departamento = new Departamento();
				$departamento->__SET('idDepartamento',$dato->idDepartamento);
				$departamento->__SET('Nombre',$dato->Nombre);
				$datos[]=$departamento;
			}
			return $datos;
		}catch(Exception $e){
			echo "Error ".$e;
		}
	}



	public function Buscar($id)
	{
		$datos=array();
		$dato=null;
		$consulta="SELECT * FROM departamento WHERE idDepartamento='$id'";
		try {
			$resultado=$this->conexion->prepare($consulta);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $datos) {
				$departamento = new Departamento();
                $departamento->__SET('idDepartamento',$datos->idDepartamento);
				$departamento->__SET('Nombre',$datos->Nombre);
				$dato[]=$departamento;
			}
			return $dato;
			
		} catch (Exception $e) {
			die($e->getMessage());
		}
	}

	public function Actualizar(Departamento $departamento){
		$actualizar="UPDATE Departamento SET  Nombre=? where idDepartamento=?";
		try {
			$this->conexion->prepare($actualizar)->execute(array(
				$departamento ->__GET('Nombre'),
			));
			return true;
		} catch (Exception $exception) {
			echo "Error al actualizar datos ".$exception->getMessage();
		}
	}
	
}
?>