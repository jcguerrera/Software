<?php
include_once "../../model/conexion.php";
include_once "../../model/modelMateria.php";

class ControllerMateria extends Conexion{
    

    public function Insertar(Materia $materia){
		$insertar = "INSERT INTO materia (idMateria,Nombre,Creditos,Departamento_idDepartamento) VALUES (null,?,?,?)";
		try{
			$this->conexion->prepare($insertar)->execute(array(
				$materia->__GET('Nombre'),
				$materia->__GET('Creditos'),
				$materia->__GET('Departamento_idDepartamento'),
			));
			return true;
		}catch(Exception $e){
			echo "Error ".$e;
		}

    }

    public function Listar(){
		$dato = array();
		$listar = "SELECT * FROM materia ORDER BY Nombre";
		try{
			$resultado = $this->conexion->prepare($listar);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$materia = new Materia();
				$materia->__SET('idMateria',$dato->idMateria);
				$materia->__SET('Nombre',$dato->Nombre);
				$materia->__SET('Creditos',$dato->Creditos);
				$materia->__SET('Departamento_idDepartamento',$dato->Departamento_idDepartamento);
				$datos[]=$materia;
			}
			return $datos;
		}catch(Exception $e){
			echo "Error ".$e;
		}
	}

	public function ListarDepartamento(){
		$dato = array();
		$listar = "SELECT materia.idMateria, materia.Nombre, materia.Creditos, departamento.Nombre AS nombreDepartamento FROM materia, departamento WHERE materia.Departamento_idDepartamento = departamento.idDepartamento ORDER BY materia.Nombre";
		try{
			$resultado = $this->conexion->prepare($listar);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$materia = new Materia();
				$materia->__SET('idMateria',$dato->idMateria);
				$materia->__SET('Nombre',$dato->Nombre);
				$materia->__SET('Creditos',$dato->Creditos);
				$materia->__SET('Departamento_idDepartamento',$dato->nombreDepartamento);
				$datos[]=$materia;
			}
			return $datos;
		}catch(Exception $e){
			echo "Error ".$e;
		}
	}
    

	public function Buscar($id){
		$dato=array();
		$datos=null;
		$consulta="SELECT * FROM materia WHERE idMateria='$id'";
		try {
			$resultado=$this->conexion->prepare($consulta);
			$resultado->execute();
			foreach ($resultado->fetchAll(PDO::FETCH_OBJ) as $dato) {
				$materia = new Materia();
				$materia->__SET('idMateria',$dato->idMateria);
				$materia->__SET('Nombre',$dato->Nombre);
				$materia->__SET('Creditos',$dato->Creditos);
				$materia->__SET('Departamento_idDepartamento',$dato->Departamento_idDepartamento);
				$datos[]=$materia;
			}
			return $datos;
		} catch (Exception $exception) {
			die($exception->getMessage());
		}
	}

	public function Actualizar(Materia $materia){
		$actualizar="UPDATE materia SET Nombre=?,Creditos=?,Departamento_idDepartamento=? where idMateria=?";
	    try {
		    	$this->conexion->prepare($actualizar)->execute(array(
                    $materia->__GET('Nombre'),
                    $materia->__GET('Creditos'),
                    $materia->__GET('Departamento_idDepartamento'),
                    $materia->__GET('idMateria'),
                 ));
			    return true;
		    } catch (Exception $exception) {
			    echo "Error al actualizar datos ".$exception->getMessage();
		    }
	}
}
?>