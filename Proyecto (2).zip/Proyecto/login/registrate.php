<?php session_start();

if (isset($_SESSION['usuario'])) {
	header('Location: index.php');
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$usuario = filter_var(strtolower($_POST['usuario']), FILTER_SANITIZE_STRING);
	$nombre = filter_var(strtolower($_POST['nombre']), FILTER_SANITIZE_STRING);
	$password = $_POST['password'];
	$password2 = $_POST['password2'];

	$errores = '';

	if (empty($usuario) or empty($password) or empty($nombre) or empty($password2)) {
		$errores .= '<li>Por favor rellena todos los datos</li>';
	} else {
		try {
			$conexion = new PDO('mysql:host=localhost;dbname=torneo', 'root', '');
		} catch (PDOExeption $e) {
			echo "Error: " . $e->getMessage();
		}
		$statement = $conexion->prepare('SELECT * FROM administrador WHERE Usuario = :usuario LIMIT 1');
		$statement->execute(array(':usuario' => $usuario));
		$resultado = $statement->fetch();
		
		if ($resultado != false) {
			$errores .= '<li>El nombre de usuario ya existe</li>';
		}

		if ($password != $password2) {
			$errores .= '<li>Las contraseñas no son iguales</li>';
		}
		
		//HASH DE LA CONTRASEñA (encriptar)
		$password = password_hash($password, PASSWORD_DEFAULT);
	}
	if ($errores == '') {
		$statement = $conexion->prepare('INSERT INTO administrador (Usuario, Nombre_Apellido, Clave) VALUES (:usuario, :nombre, :pass)');
		$statement->execute(array(':usuario' => $usuario, ':nombre' => $nombre, ':pass' => $password));

		header('Location: login.php');
	}
}
require 'views/registrar.php';
?>