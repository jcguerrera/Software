<?php 
	require_once 'Menu.php'
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Iniciar Sesion</title>
</head>
<body>
	<div style="width: 500px; margin-left: 30%">
		<h1 style="font-family: cursive; font-size: 30px">Iniciar Sesion</h1>

		<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST" class="formulario" name="login">
			<div class="input-field col s12" id="usuario">
        		<i class="material-icons prefix">account_circle</i>
        		<input id="icon_prefix nombre" type="text" name="usuario" class="validate" required>
        		<label for="icon_prefix">Usuario</label>
      		</div>
      		<div class="input-field col s12" id="password">
        		<i class="material-icons prefix">account_circle</i>
        		<input id="icon_prefix nombre" type="password" name="password" class="validate" required>
        		<label for="icon_prefix">Contraseña</label>
      		</div>

			<div>
				<button class="btn waves-effect waves-light blue" type="button" name="enviar" onclick="login.submit()" style="margin-left: 40%">Inicio Sesión
   				<i class="material-icons right">send</i>
			</div>

<!--Mensaje de error -->
			<?php if(!empty($errores)): ?>
				<div>
					<ul>
						<?php echo $errores; ?>
					</ul>
				</div>
			<?php endif; ?>
			
		</form>

		<p style="font-size: 20px; font-family: cursive;">
			¿Aun no tienes cuenta? <br>
			<a href="registrate.php">Registrate</a>
		</p>
	</div>
</body>
</html>