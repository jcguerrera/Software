<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Contenido</title>
</head>
<body>
	<div>
		<h1>Contenido del titulo</h1>
		<a href="cerrar.php">Cerrar sesion</a>

		<div>
			<article>
				<p>Cesar malparido</p>

				<p>Daniel Hijueputa</p>
				
				<p>Camilo perra</p>
			</article>
		</div>
	</div>
</body>
</html>