<?php session_start();
if (isset($_SESSION['usuario'])) {
	require '../Main.php';
} else {
	header('Location: login.php');
}
?>