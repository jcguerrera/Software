<?php session_start();

if (isset($_SESSION['Usuario'])) {
	header('Location: paginaUsuario.php');
}else{
	header('Location: index.php');
}
$errores = '';
$encontrado = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$usuario = filter_var(strtolower($_POST['Usuario']), FILTER_SANITIZE_STRING);
	$password = $_POST['Clave'];


	try {
		$conexion = new PDO('mysql:host=localhost;dbname=proyecto', 'root', '');
	} catch (PDOException $e) {
		echo "Error:" . $e->getMessage();;
	}

	$statement = $conexion->prepare('
		SELECT * FROM usuario WHERE Usuario = :Usuario'
	);
	$statement->execute(array(
		':Usuario' => $Usuario
));     
	
	while($registro = $statement->fetch(PDO::FETCH_ASSOC)){
		if(password_verify($password, $registro['Clave'])){
			$encontrado = true;
		}
	}

	if ($encontrado != false) {
		$_SESSION['Usuario'] = $Usuario;
		header('Location: paginaUsuario.php');
	} else {
		$errores .= '<li>Datos Incorrectos'.$encontrado.'</li>';
	}
}


require 'views/login.view.php';

?>