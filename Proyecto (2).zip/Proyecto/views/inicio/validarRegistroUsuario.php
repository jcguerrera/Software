<?php
require_once '../../model/modelUsuarios.php';
require_once '../../controller/UsuarioController.php';
require_once '../../model/modelEstudiante.php';
require_once '../../controller/EstudianteController.php';

$controlUsuario = new ControllerUsuario();
$controlEstudiante = new ControllerEstudiante();
$estudiante = new Estudiante();
$usuario = new Usuario();
$usuario->__SET('Usuario',$_POST['usuario']);
$usuario->__SET('Clave',$_POST['contraseña']);
$usuario->__SET('Tipo_Usuario','ESTUDIANTE');
$usuario->__SET('Nombre',$_POST['nombre']);
$usuario->__SET('Apellido',$_POST['apellido']);
$usuario->__SET('Correo',$_POST['correo']);

if($controlUsuario->Insertar($usuario) == true){
	$carrera = $_POST['carrera'];
	$estudiante->__SET('Carrera_idCarrera',$carrera);
	$estudiante->__SET('Usuario_Usuario',$_POST['usuario']);
	if($controlEstudiante->Insertar($estudiante) == true){
		?>
            <script language="JavaScript" type="text/javascript">
                alert("Tu registro fue exitoso");
            </script>
            <meta http-equiv="refresh" content="0; url=index.php">
            <?php
	}else{
		?>
            <script language="JavaScript" type="text/javascript">
                alert("Ocurrio un problema con tu registro");
            </script>
            <meta http-equiv="refresh" content="0; url=index.php">
            <?php
	}
}else{
	?>
            <script language="JavaScript" type="text/javascript">
                alert("Ocurrio un problema con tu registro");
            </script>
            <meta http-equiv="refresh" content="0; url=index.php">
            <?php
}

?>