<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title>Registro de Usuario</title>
	<link rel="stylesheet" type="text/css" href="../css/manual.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
</head>
<body>
	<form method="POST" action="validarRegistroUsuario.php">
		<input type="text" name="usuario" required placeholder="Usuario">
		<input type="password" name="contraseña" required placeholder="Contraseña">
		<button type="submit">Registrarce</button>
		
	</form>

</body>
</html>