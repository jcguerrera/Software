<?php
	require_once '../../model/modelDepartamento.php';
	require_once '../../controller/DepartamentoController.php';

	$departamento = new Departamento();
	$control = new ControllerDepartamento();
	$departamento->__SET('Nombre',$_POST['nombreDepartamento']);
	if($control->Insertar($departamento) == true){
		echo "Exito";
	}else{
		echo "Error";
	}
?>