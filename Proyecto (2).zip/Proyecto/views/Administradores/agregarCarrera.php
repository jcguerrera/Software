<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>Agregar Carrera</title>
    <link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
</head>

<body>
    <?php
     include_once 'menuAux.php';
    ?>
    <div class="registroCarrera">
        <div class="modal-header headerModal">
            <h5 class="modal-title" id="titleLabel">Agregar Carrera</h5>​
        </div>
        <br>
        <form method="POST" action="registrarCarrera.php">
            <div class="form-group col-md-12">
                <label for="inputEmail4" style="color: black">Nombre Carrera</label>
                <input type="text" class="form-control" placeholder="Nombre Carrera" required name="nombreCarrera">
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary botonIngresar  contenedorCarrera">Agregar</button>​
            </div>
        </form>
    </div>
    <script src="../js/jquery-3.4.1.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
</body>

</html>