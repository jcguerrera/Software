<?php
require_once '../../model/modelDepartamento.php';
require_once '../../controller/DepartamentoController.php';

$control = new ControllerDepartamento();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Agregar Usuario</title>
	<link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
</head>
<body>
	<div class="registro" >
		<div class="modal-header headerModal">
			<h5 class="modal-title" id="titleLabel">Registro en el sistema</h5>
		</div>
		<br>
		<form method="POST" action="validarRegistroUsuario.php">
			<div class="modal-body">
				<div class="row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">Nombre</label>
						<input type="text" class="form-control" placeholder="Nombre" required name="nombre">
					</div>
					<div class="form-group col-md-6">
						<label for="inputEmail4">Apellido</label>
						<input type="text" class="form-control" placeholder="Apellido" required name="apellido">
					</div>
					<div class="form-group col-md-12">
						<label for="inputEmail4">Correo</label>
						<input type="email" class="form-control" placeholder="Correo" required name="correo">
					</div>
					<div class="form-group col-md-6">
						<label for="inputEmail4">Usuario</label>
						<input type="text" class="form-control" placeholder="Usuario" required name="usuario">
					</div>
					<div class="form-group col-md-6">
						<label for="inputEmail4">Contraseña</label>
						<input type="password" class="form-control" placeholder="Contraseña" required name="contraseña">
					</div>
					<div class="form-group col-md-12">
						<label for="inputEmail4">Selecciona el Tipo de usuario</label>
						<select id="carrera" class="form-control" required name="carrera">
							<option selected disabled>Selecciona una opcion</option>
							<option value="ESTUDIANTE">ESTUDIANTE</option>
							<option value="ADMINISTRADOR">ADMINISTRADOR</option>
							<option value="DOCENTE">DOCENTE</option>
							<option value="MONITOR">MONITOR</option>

						</select>
					</div>
					<div class="form-group col-md-12">
						<label for="inputEmail4" id="textoDepartamento" style="display: none;">Selecciona el Departamento</label>
						<select id="departamento" class="form-control" required name="departamento" style="display: none;">
							<option selected disabled>Selecciona una opcion</option>
							<?php
							foreach ($control->Listar() as $departamento):
								?>
							<option value="<?php echo $departamento->__GET('idDepartamento') ?>"><?php echo $departamento->__GET('Nombre')?></option>
							<?php
							endforeach;
							?>
						</select>
					</div>
				</div>
			</div>
			<div class="modal-footer">	
				<button type="submit" class="btn btn-primary botonIngresar">Sign in</button>
			</div>
		</form>

	</div>
	<script src="../js/jquery-3.4.1.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
</body>
</html>