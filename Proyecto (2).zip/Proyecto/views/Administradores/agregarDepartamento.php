
<!DOCTYPE html>
<html>​

<head>​
    <meta charset="utf-8">​
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">​
    <title>Agregar Departamento</title>​
    <link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">​
    <link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">​
</head>​

<body>​ ​
	<?php
		include_once 'menuAux.php';
	?>
    <div class="registroDepartamento">​
        <div class="modal-header headerModal">​
            <h5 class="modal-title" id="titleLabel">Agregar Departamento</h5>​
        </div>​
        <form method="POST" action="registrarDepartamento.php">​ ​
            <div class="form-group col-md-12 contenedorDepartamento">​
                <label for="inputEmail4" style="color: black">Carrera</label>
                <input type="text" class="form-control" placeholder="Nombre Departamento" name="nombreDepartamento">​
            </div>​
            <div class="modal-footer">​
                <button type="submit" class="btn btn-primary botonIngresar contenedorDepartamento">Agregar</button>​
            </div>​ ​
        </form>​
    </div>​
    <script src="../js/jquery-3.4.1.min.js"></script>​
    <script src="../js/bootstrap.min.js"></script>​
</body>​

</html>
