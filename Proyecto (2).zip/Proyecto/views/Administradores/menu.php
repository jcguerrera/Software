<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title>Menu Administradores</title>
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../../css/manual.css">
</head>
<body style="color: white">
	<div class="menu">
		<div class="contenedorImagen">
			<div class="bloqueImagen" align="middle">
				<img class="imagen" src="../../imagenes/user.png">
			</div>
			<div class="usuario">
				<?php
				$usuario = "cesar";
				?>
				<h1 class="text-white textUsuario">Bienvenido <?php echo $usuario?></h1>
			</div>
		</div>
		<ul class="nav flex-column">
			<li class="nav-item option">
				<a class="nav-link text-white" href="#">Carreras</a>
				<ul class="nav flex-column">
					<li class="nav-item suboption">
						<a class="nav-link text-white" href="agregarCarrera.php">Agregar Carrera</a>
					</li>
					<li class="nav-item suboption">
						<a class="nav-link text-white" href="listarCarrera.php">Eliminar Carrera</a>
					</li>
				</ul>
			</li>
			<li class="nav-item option">
				<a class="nav-link text-white" href="#">Departamento</a>
				<ul class="nav flex-column">
					<li class="nav-item suboption">
						<a class="nav-link text-white" href="agregarDepartamento.php">Agregar Departamento</a>
					</li>
					<li class="nav-item suboption">
						<a class="nav-link text-white" href="listarDepartamento.php">Eliminar Departamento</a>
					</li>
				</ul>
			</li>
			<!--<li class="nav-item option">
				<a class="nav-link text-white" href="agregarMateria.php">Agregar Materia</a>
			</li>-->
			<!--<li class="nav-item option">
				<a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
			</li>-->
		</ul>
	</div>
	<script src="../js/jquery-3.4.1.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
</body>
</html>