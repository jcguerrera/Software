<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title>Menu Administradores</title>
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
</head>

<body style="color: white">

<ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
    <li class="nav-item menuOpcion">
        <a class="nav-link letraBlanca" id="pills-home-tab" data-toggle="pill" href="agregarMateria.php" role="tab" aria-controls="pills-home" aria-selected="true">Agregar Materia</a>
    </li>
    <li class="nav-item menuOpcion ">
        <a class="nav-link letraBlanca" id="pills-profile-tab" data-toggle="pill" href="listarMateria.php" role="tab" aria-controls="pills-profile" aria-selected="false">Modificar Materias</a>
    </li>

	<li class="nav-item menuOpcion">
	    <a class="nav-link letraBlanca" id="pills-contact-tab" data-toggle="pill" href="agregarDepartamento.php" role="tab" aria-controls="pills-contact" aria-selected="false">Agregar Departamento</a>
	</li>

	<li class="nav-item menuOpcion">
	    <a class="nav-link letraBlanca" id="pills-contact-tab" data-toggle="pill" href="agregarCarrera.php" role="tab" aria-controls="pills-contact" aria-selected="false">Agregar Carrera</a>
	</li>
	<li class="nav-item menuOpcion">
	    <a class="nav-link letraBlanca" id="pills-contact-tab" data-toggle="pill" href="agregarUsuario.php" role="tab" aria-controls="pills-contact" aria-selected="false">Agregar Usuario</a>
	</li>
	<li class="nav-item menuOpcion">
	    <a class="nav-link letraBlanca" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Modificar Usuario</a>
	</li>
	<li class="nav-item menuOpcion">
	    <a class="nav-link letraBlanca" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Buscar Usuario</a>
	</li>

</ul>
<div class="tab-content" id="pills-tabContent">
    <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">...</div>
    <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">...</div>
    <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">...</div>
</div>
	<script src="../js/jquery-3.4.1.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
</body>
</html>