<?php
require_once '../../model/modelMateria.php';
require_once '../../controller/MateriaController.php';
require_once '../../model/modelDepartamento.php';
require_once '../../controller/DepartamentoController.php';

$controlMaterias = new ControllerMateria();
$controlDepartamento = new ControllerDepartamento();

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Listar Materia</title>
	<link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
</head>
<body>

	<?php
		include_once 'menuAux.php'
	?>
	<br><br>
	<div class="materiasAgregadas">
		
	
	<table class="table table-striped">
		<thead>
			<tr class="titulosTabla">
				<th scope="col">Nombre</th>
				<th scope="col">Creditos</th>
				<th scope="col">Departamento</th>
				<th scope="col" colspan="2">Opciones</th>

			</tr>
		</thead>
		<tbody>
			<?php
			foreach($controlMaterias->ListarDepartamento() as $materia):
				?>
			<tr>
				<th scope="col"><?php echo $materia->__GET('Nombre'); ?></th>
				<th scope="col"><?php echo $materia->__GET('Creditos'); ?></th>
				<th scope="col"><?php echo $materia->__GET('Departamento_idDepartamento'); ?></th>
				<th scope="col"><a href="editarInformacion.php?id=<?php echo $materia->__GET('idMateria'); ?>"><img src="../../imagenes/editar.png" style="width: 25px; height: 25px"></a></th>
				<th scope="col"><img src="../../imagenes/cerrar.png" style="width: 25px; height: 25px"></th>
			</tr>
			<?php
			endforeach;
			?>
		</tbody>
	</table>
</div>
	<script src="../js/jquery-3.4.1.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
</body>
</html>