<?php
	require_once '../../model/modelMateria.php';
	require_once '../../controller/MateriaController.php';

	$materia = new Materia();
	$control = new ControllerMateria();
	$materia->__SET('Nombre',$_POST['nombreCarrera']);
	$materia->__SET('Creditos',$_POST['creditos']);
	$materia->__SET('Departamento_idDepartamento',$_POST['departamento']);
	if($control->Insertar($materia) == true){
		echo "Exito";
	}else{
		echo "Error";
	}
?>