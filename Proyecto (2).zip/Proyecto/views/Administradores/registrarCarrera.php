<?php
	require_once '../../model/modelCarrera.php';
	require_once '../../controller/CarreraController.php';

	$carrera = new Carrera();
	$control = new ControllerCarrera();
	$carrera->__SET('Nombre',$_POST['nombreCarrera']);
	if($control->Insertar($carrera) == true){
		echo "Exito";
	}else{
		echo "Error";
	}
?>