<?php
	require_once '../../model/modelMateria.php';
require_once '../../controller/MateriaController.php';
require_once '../../model/modelDepartamento.php';
require_once '../../controller/DepartamentoController.php';

$controlMaterias = new ControllerMateria();
$controlDepartamento = new ControllerDepartamento();
$materia = new Materia();
$idMateria = $_GET['id'];
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Editar Informacion</title>
	<link rel="stylesheet" type="text/css" href="../../css/estilosManuales.css">
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
</head>
<body>
   <div class="ingresoMateria">
    <div class="modal-header headerModal">
			<h5 class="modal-title" id="titleLabel">Editar Materia</h5>
		</div>

	<form action="#" method="POST">
		<div class="row tam">
		<?php
		foreach($controlMaterias->Buscar($idMateria) as $resultado):
			?>

			<div class="form-group col-md-6">
			  <label for="inputEmail4">Nombre</label>
			  <br>
			  <input type="text" class="form-control" placeholder="Nombre" required name="nombre" value="<?php echo $resultado->__GET('Nombre');?>">
			</div>

            <div class="form-group col-md-6">
			  <label for="inputEmail4">Creditos</label>
			  <br>
		 	  <input type="text"  class="form-control" placeholder="Creditos" required name="creditos" value="<?php echo $resultado->__GET('Creditos');?>">
		 	</div>

          <div class="form-group col-md-12">
            <label for="inputEmail4">Departamento</label>   
            <br>
			<select id="departamento" class="form-control" required name="departamento">
				<?php
				foreach ($controlDepartamento->Listar() as $departamento):
					if($departamento->__GET('idDepartamento') == $resultado->__GET('Departamento_idDepartamento')){
						?>
						<option selected value="<?php echo $departamento->__GET('idDepartamento') ?>"><?php echo $departamento->__GET('Nombre')?></option>
						<?php
					}else{
						?>
				<option value="<?php echo $departamento->__GET('idDepartamento') ?>"><?php echo $departamento->__GET('Nombre')?></option>
				<?php
					}
					
				endforeach;
				?>
			</select>
		   </div>
			<?php
		endforeach;
		?>

        </div>
         <div class="modal-footer">	
				<button type="submit" class="btn btn-primary botonAgregarMateria" name="enviar">Guardar Cambios</button>
	    </div>
	</form>
	<?php 
    if (isset($_POST['enviar'])) {
    	$materia->__SET('idMateria',$idMateria);
        $materia->__SET('Nombre',$_POST['nombre']);
        $materia->__SET('Creditos',$_POST['creditos']);
        //echo $_POST['departamento'];
        $materia->__SET('Departamento_idDepartamento',$_POST['departamento']);
        if(($controlMaterias->actualizar($materia)) != true){
            echo "Error";
        }else{
        	echo "Exito";
            ?>
            <script language="JavaScript" type="text/javascript">
                alert("La materia fue modificada exitosamente");
            </script>
            <meta http-equiv="refresh" content="0; url=listarMateria.php">
            <?php
        }
    } 
   ?>
   <script src="../js/jquery-3.4.1.min.js"></script>
	  <script src="../js/bootstrap.min.js"></script>
</div>
</body>
</html>