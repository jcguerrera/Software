<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <title>Inicio</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
  <div class="container">
    <form method="POST" action="registro.php">
      <label>Nombre</label>
      <input type="text" name="Nombre" required>
      <label>Usuario</label>
      <input type="text" name="Usuario" required>
      <label>Clave</label>
      <input type="password" name="Clave" required>
      <label>Tipo Usuario</label>
      <select name="TipoUsuario" required>
        <option value="1">Profesor</option>
        <option value="2">Monitor</option>
        <option value="3">Estudiante</option>
        <option value="4">Administrador</option>
      </select>
      <label>Correo</label>
      <input type="text" name="Correo" required>
      <button class="btn btn-primary">Enviar</button>
    </form>
  </div>

  <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>