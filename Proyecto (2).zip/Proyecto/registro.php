<?php 
require_once 'controller/UsuariosController.php';
require_once 'model/modelUsuarios.php';

$usuario = new Usuario();
$control = new UsuariosController();
$usuario->__SET('Nombre',$_POST['Nombre']);
$usuario->__SET('Usuario',$_POST['Usuario']);
$usuario->__SET('Clave',$_POST['Clave']);
$usuario->__SET('TipoUsuario',$_POST['TipoUsuario']);
$usuario->__SET('Correo',$_POST['Correo']);
if($control->Insertar($usuario) != true){
  ?>
  <script language="JavaScript" type="text/javascript">
      alert("Error al ingresar los datos");
  </script>
  <meta http-equiv="refresh" content="0; url=inicio.php">
  <?php
}else{
  ?>
  <script language="JavaScript" type="text/javascript">
      alert("Datos agregados correctamente");
  </script>
  <meta http-equiv="refresh" content="0; url=inicio.php">
  <?php
}

?>

