<?php session_start();
if (isset($_SESSION['usuario'])) {
	?>
	<!DOCTYPE html>
	<html>
	<head>
		<title>paginaUser</title>
	</head>
	<body>
		<h1>Entra</h1>

	</body>
	</html>
	<?php
} else {
	header('Location: index.php');
}
?>